(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Drainer/drain/node_modules/essential-eth/dist/cjs/index.umd.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Desktop/Drainer/drain/node_modules/next/dist/compiled/buffer/index.js [client] (ecmascript)");
!function(t, e) {
    ("TURBOPACK compile-time truthy", 1) ? e(exports) : "TURBOPACK unreachable";
}(/*TURBOPACK member replacement*/ __turbopack_context__.e, function(t) {
    function e() {
        return e = Object.assign || function(t) {
            for(var e = 1; e < arguments.length; e++){
                var r = arguments[e];
                for(var n in r)Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n]);
            }
            return t;
        }, e.apply(this, arguments);
    }
    function r(t, e) {
        t.prototype = Object.create(e.prototype), t.prototype.constructor = t, n(t, e);
    }
    function n(t, e) {
        return n = Object.setPrototypeOf || function(t, e) {
            return t.__proto__ = e, t;
        }, n(t, e);
    }
    function i(t) {
        var e = {
            exports: {}
        };
        return t(e, e.exports), e.exports;
    }
    for(var o = [], s = [], u = "undefined" != typeof Uint8Array ? Uint8Array : Array, f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0, c = f.length; a < c; ++a)o[a] = f[a], s[f.charCodeAt(a)] = a;
    function h(t, e, r) {
        for(var n, i = [], s = e; s < r; s += 3)i.push(o[(n = (t[s] << 16 & 16711680) + (t[s + 1] << 8 & 65280) + (255 & t[s + 2])) >> 18 & 63] + o[n >> 12 & 63] + o[n >> 6 & 63] + o[63 & n]);
        return i.join("");
    }
    s["-".charCodeAt(0)] = 62, s["_".charCodeAt(0)] = 63;
    var l = function(t) {
        var e, r, n = function(t) {
            var e = t.length;
            if (e % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
            var r = t.indexOf("=");
            return -1 === r && (r = e), [
                r,
                r === e ? 0 : 4 - r % 4
            ];
        }(t), i = n[0], o = n[1], f = new u(function(t, e, r) {
            return 3 * (e + r) / 4 - r;
        }(0, i, o)), a = 0, c = o > 0 ? i - 4 : i;
        for(r = 0; r < c; r += 4)e = s[t.charCodeAt(r)] << 18 | s[t.charCodeAt(r + 1)] << 12 | s[t.charCodeAt(r + 2)] << 6 | s[t.charCodeAt(r + 3)], f[a++] = e >> 16 & 255, f[a++] = e >> 8 & 255, f[a++] = 255 & e;
        return 2 === o && (e = s[t.charCodeAt(r)] << 2 | s[t.charCodeAt(r + 1)] >> 4, f[a++] = 255 & e), 1 === o && (e = s[t.charCodeAt(r)] << 10 | s[t.charCodeAt(r + 1)] << 4 | s[t.charCodeAt(r + 2)] >> 2, f[a++] = e >> 8 & 255, f[a++] = 255 & e), f;
    }, p = function(t) {
        for(var e, r = t.length, n = r % 3, i = [], s = 16383, u = 0, f = r - n; u < f; u += s)i.push(h(t, u, u + s > f ? f : u + s));
        return 1 === n ? i.push(o[(e = t[r - 1]) >> 2] + o[e << 4 & 63] + "==") : 2 === n && i.push(o[(e = (t[r - 2] << 8) + t[r - 1]) >> 10] + o[e >> 4 & 63] + o[e << 2 & 63] + "="), i.join("");
    }, g = function(t, e, r, n, i) {
        var o, s, u = 8 * i - n - 1, f = (1 << u) - 1, a = f >> 1, c = -7, h = r ? i - 1 : 0, l = r ? -1 : 1, p = t[e + h];
        for(h += l, o = p & (1 << -c) - 1, p >>= -c, c += u; c > 0; o = 256 * o + t[e + h], h += l, c -= 8);
        for(s = o & (1 << -c) - 1, o >>= -c, c += n; c > 0; s = 256 * s + t[e + h], h += l, c -= 8);
        if (0 === o) o = 1 - a;
        else {
            if (o === f) return s ? NaN : Infinity * (p ? -1 : 1);
            s += Math.pow(2, n), o -= a;
        }
        return (p ? -1 : 1) * s * Math.pow(2, o - n);
    }, y = function(t, e, r, n, i, o) {
        var s, u, f, a = 8 * o - i - 1, c = (1 << a) - 1, h = c >> 1, l = 23 === i ? Math.pow(2, -24) - Math.pow(2, -77) : 0, p = n ? 0 : o - 1, g = n ? 1 : -1, y = e < 0 || 0 === e && 1 / e < 0 ? 1 : 0;
        for(e = Math.abs(e), isNaN(e) || Infinity === e ? (u = isNaN(e) ? 1 : 0, s = c) : (s = Math.floor(Math.log(e) / Math.LN2), e * (f = Math.pow(2, -s)) < 1 && (s--, f *= 2), (e += s + h >= 1 ? l / f : l * Math.pow(2, 1 - h)) * f >= 2 && (s++, f /= 2), s + h >= c ? (u = 0, s = c) : s + h >= 1 ? (u = (e * f - 1) * Math.pow(2, i), s += h) : (u = e * Math.pow(2, h - 1) * Math.pow(2, i), s = 0)); i >= 8; t[r + p] = 255 & u, p += g, u /= 256, i -= 8);
        for(s = s << i | u, a += i; a > 0; t[r + p] = 255 & s, p += g, s /= 256, a -= 8);
        t[r + p - g] |= 128 * y;
    }, d = i(function(t, e) {
        const r = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;
        e.Buffer = o, e.SlowBuffer = function(t) {
            return +t != t && (t = 0), o.alloc(+t);
        }, e.INSPECT_MAX_BYTES = 50;
        const n = 2147483647;
        function i(t) {
            if (t > n) throw new RangeError('The value "' + t + '" is invalid for option "size"');
            const e = new Uint8Array(t);
            return Object.setPrototypeOf(e, o.prototype), e;
        }
        function o(t, e, r) {
            if ("number" == typeof t) {
                if ("string" == typeof e) throw new TypeError('The "string" argument must be of type string. Received type number');
                return f(t);
            }
            return s(t, e, r);
        }
        function s(t, e, r) {
            if ("string" == typeof t) return function(t, e) {
                if ("string" == typeof e && "" !== e || (e = "utf8"), !o.isEncoding(e)) throw new TypeError("Unknown encoding: " + e);
                const r = 0 | d(t, e);
                let n = i(r);
                const s = n.write(t, e);
                return s !== r && (n = n.slice(0, s)), n;
            }(t, e);
            if (ArrayBuffer.isView(t)) return function(t) {
                if (J(t, Uint8Array)) {
                    const e = new Uint8Array(t);
                    return c(e.buffer, e.byteOffset, e.byteLength);
                }
                return a(t);
            }(t);
            if (null == t) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
            if (J(t, ArrayBuffer) || t && J(t.buffer, ArrayBuffer)) return c(t, e, r);
            if ("undefined" != typeof SharedArrayBuffer && (J(t, SharedArrayBuffer) || t && J(t.buffer, SharedArrayBuffer))) return c(t, e, r);
            if ("number" == typeof t) throw new TypeError('The "value" argument must not be of type number. Received type number');
            const n = t.valueOf && t.valueOf();
            if (null != n && n !== t) return o.from(n, e, r);
            const s = function(t) {
                if (o.isBuffer(t)) {
                    const e = 0 | h(t.length), r = i(e);
                    return 0 === r.length || t.copy(r, 0, 0, e), r;
                }
                return void 0 !== t.length ? "number" != typeof t.length || Y(t.length) ? i(0) : a(t) : "Buffer" === t.type && Array.isArray(t.data) ? a(t.data) : void 0;
            }(t);
            if (s) return s;
            if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof t[Symbol.toPrimitive]) return o.from(t[Symbol.toPrimitive]("string"), e, r);
            throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
        }
        function u(t) {
            if ("number" != typeof t) throw new TypeError('"size" argument must be of type number');
            if (t < 0) throw new RangeError('The value "' + t + '" is invalid for option "size"');
        }
        function f(t) {
            return u(t), i(t < 0 ? 0 : 0 | h(t));
        }
        function a(t) {
            const e = t.length < 0 ? 0 : 0 | h(t.length), r = i(e);
            for(let n = 0; n < e; n += 1)r[n] = 255 & t[n];
            return r;
        }
        function c(t, e, r) {
            if (e < 0 || t.byteLength < e) throw new RangeError('"offset" is outside of buffer bounds');
            if (t.byteLength < e + (r || 0)) throw new RangeError('"length" is outside of buffer bounds');
            let n;
            return n = void 0 === e && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, e) : new Uint8Array(t, e, r), Object.setPrototypeOf(n, o.prototype), n;
        }
        function h(t) {
            if (t >= n) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + n.toString(16) + " bytes");
            return 0 | t;
        }
        function d(t, e) {
            if (o.isBuffer(t)) return t.length;
            if (ArrayBuffer.isView(t) || J(t, ArrayBuffer)) return t.byteLength;
            if ("string" != typeof t) throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof t);
            const r = t.length, n = arguments.length > 2 && !0 === arguments[2];
            if (!n && 0 === r) return 0;
            let i = !1;
            for(;;)switch(e){
                case "ascii":
                case "latin1":
                case "binary":
                    return r;
                case "utf8":
                case "utf-8":
                    return K(t).length;
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return 2 * r;
                case "hex":
                    return r >>> 1;
                case "base64":
                    return V(t).length;
                default:
                    if (i) return n ? -1 : K(t).length;
                    e = ("" + e).toLowerCase(), i = !0;
            }
        }
        function m(t, e, r) {
            let n = !1;
            if ((void 0 === e || e < 0) && (e = 0), e > this.length) return "";
            if ((void 0 === r || r > this.length) && (r = this.length), r <= 0) return "";
            if ((r >>>= 0) <= (e >>>= 0)) return "";
            for(t || (t = "utf8");;)switch(t){
                case "hex":
                    return R(this, e, r);
                case "utf8":
                case "utf-8":
                    return U(this, e, r);
                case "ascii":
                    return k(this, e, r);
                case "latin1":
                case "binary":
                    return T(this, e, r);
                case "base64":
                    return P(this, e, r);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return _(this, e, r);
                default:
                    if (n) throw new TypeError("Unknown encoding: " + t);
                    t = (t + "").toLowerCase(), n = !0;
            }
        }
        function w(t, e, r) {
            const n = t[e];
            t[e] = t[r], t[r] = n;
        }
        function v(t, e, r, n, i) {
            if (0 === t.length) return -1;
            if ("string" == typeof r ? (n = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), Y(r = +r) && (r = i ? 0 : t.length - 1), r < 0 && (r = t.length + r), r >= t.length) {
                if (i) return -1;
                r = t.length - 1;
            } else if (r < 0) {
                if (!i) return -1;
                r = 0;
            }
            if ("string" == typeof e && (e = o.from(e, n)), o.isBuffer(e)) return 0 === e.length ? -1 : b(t, e, r, n, i);
            if ("number" == typeof e) return e &= 255, "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(t, e, r) : Uint8Array.prototype.lastIndexOf.call(t, e, r) : b(t, [
                e
            ], r, n, i);
            throw new TypeError("val must be string, number or Buffer");
        }
        function b(t, e, r, n, i) {
            let o, s = 1, u = t.length, f = e.length;
            if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
                if (t.length < 2 || e.length < 2) return -1;
                s = 2, u /= 2, f /= 2, r /= 2;
            }
            function a(t, e) {
                return 1 === s ? t[e] : t.readUInt16BE(e * s);
            }
            if (i) {
                let n = -1;
                for(o = r; o < u; o++)if (a(t, o) === a(e, -1 === n ? 0 : o - n)) {
                    if (-1 === n && (n = o), o - n + 1 === f) return n * s;
                } else -1 !== n && (o -= o - n), n = -1;
            } else for(r + f > u && (r = u - f), o = r; o >= 0; o--){
                let r = !0;
                for(let n = 0; n < f; n++)if (a(t, o + n) !== a(e, n)) {
                    r = !1;
                    break;
                }
                if (r) return o;
            }
            return -1;
        }
        function E(t, e, r, n) {
            r = Number(r) || 0;
            const i = t.length - r;
            n ? (n = Number(n)) > i && (n = i) : n = i;
            const o = e.length;
            let s;
            for(n > o / 2 && (n = o / 2), s = 0; s < n; ++s){
                const n = parseInt(e.substr(2 * s, 2), 16);
                if (Y(n)) return s;
                t[r + s] = n;
            }
            return s;
        }
        function B(t, e, r, n) {
            return Z(K(e, t.length - r), t, r, n);
        }
        function A(t, e, r, n) {
            return Z(function(t) {
                const e = [];
                for(let r = 0; r < t.length; ++r)e.push(255 & t.charCodeAt(r));
                return e;
            }(e), t, r, n);
        }
        function x(t, e, r, n) {
            return Z(V(e), t, r, n);
        }
        function I(t, e, r, n) {
            return Z(function(t, e) {
                let r, n, i;
                const o = [];
                for(let s = 0; s < t.length && !((e -= 2) < 0); ++s)r = t.charCodeAt(s), n = r >> 8, i = r % 256, o.push(i), o.push(n);
                return o;
            }(e, t.length - r), t, r, n);
        }
        function P(t, e, r) {
            return p(0 === e && r === t.length ? t : t.slice(e, r));
        }
        function U(t, e, r) {
            r = Math.min(t.length, r);
            const n = [];
            let i = e;
            for(; i < r;){
                const e = t[i];
                let o = null, s = e > 239 ? 4 : e > 223 ? 3 : e > 191 ? 2 : 1;
                if (i + s <= r) {
                    let r, n, u, f;
                    switch(s){
                        case 1:
                            e < 128 && (o = e);
                            break;
                        case 2:
                            r = t[i + 1], 128 == (192 & r) && (f = (31 & e) << 6 | 63 & r, f > 127 && (o = f));
                            break;
                        case 3:
                            r = t[i + 1], n = t[i + 2], 128 == (192 & r) && 128 == (192 & n) && (f = (15 & e) << 12 | (63 & r) << 6 | 63 & n, f > 2047 && (f < 55296 || f > 57343) && (o = f));
                            break;
                        case 4:
                            r = t[i + 1], n = t[i + 2], u = t[i + 3], 128 == (192 & r) && 128 == (192 & n) && 128 == (192 & u) && (f = (15 & e) << 18 | (63 & r) << 12 | (63 & n) << 6 | 63 & u, f > 65535 && f < 1114112 && (o = f));
                    }
                }
                null === o ? (o = 65533, s = 1) : o > 65535 && (o -= 65536, n.push(o >>> 10 & 1023 | 55296), o = 56320 | 1023 & o), n.push(o), i += s;
            }
            return function(t) {
                const e = t.length;
                if (e <= S) return String.fromCharCode.apply(String, t);
                let r = "", n = 0;
                for(; n < e;)r += String.fromCharCode.apply(String, t.slice(n, n += S));
                return r;
            }(n);
        }
        e.kMaxLength = n, (o.TYPED_ARRAY_SUPPORT = function() {
            try {
                const t = new Uint8Array(1), e = {
                    foo: function() {
                        return 42;
                    }
                };
                return Object.setPrototypeOf(e, Uint8Array.prototype), Object.setPrototypeOf(t, e), 42 === t.foo();
            } catch (t) {
                return !1;
            }
        }()) || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(o.prototype, "parent", {
            enumerable: !0,
            get: function() {
                if (o.isBuffer(this)) return this.buffer;
            }
        }), Object.defineProperty(o.prototype, "offset", {
            enumerable: !0,
            get: function() {
                if (o.isBuffer(this)) return this.byteOffset;
            }
        }), o.poolSize = 8192, o.from = function(t, e, r) {
            return s(t, e, r);
        }, Object.setPrototypeOf(o.prototype, Uint8Array.prototype), Object.setPrototypeOf(o, Uint8Array), o.alloc = function(t, e, r) {
            return function(t, e, r) {
                return u(t), t <= 0 ? i(t) : void 0 !== e ? "string" == typeof r ? i(t).fill(e, r) : i(t).fill(e) : i(t);
            }(t, e, r);
        }, o.allocUnsafe = function(t) {
            return f(t);
        }, o.allocUnsafeSlow = function(t) {
            return f(t);
        }, o.isBuffer = function(t) {
            return null != t && !0 === t._isBuffer && t !== o.prototype;
        }, o.compare = function(t, e) {
            if (J(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), J(e, Uint8Array) && (e = o.from(e, e.offset, e.byteLength)), !o.isBuffer(t) || !o.isBuffer(e)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
            if (t === e) return 0;
            let r = t.length, n = e.length;
            for(let i = 0, o = Math.min(r, n); i < o; ++i)if (t[i] !== e[i]) {
                r = t[i], n = e[i];
                break;
            }
            return r < n ? -1 : n < r ? 1 : 0;
        }, o.isEncoding = function(t) {
            switch(String(t).toLowerCase()){
                case "hex":
                case "utf8":
                case "utf-8":
                case "ascii":
                case "latin1":
                case "binary":
                case "base64":
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return !0;
                default:
                    return !1;
            }
        }, o.concat = function(t, e) {
            if (!Array.isArray(t)) throw new TypeError('"list" argument must be an Array of Buffers');
            if (0 === t.length) return o.alloc(0);
            let r;
            if (void 0 === e) for(e = 0, r = 0; r < t.length; ++r)e += t[r].length;
            const n = o.allocUnsafe(e);
            let i = 0;
            for(r = 0; r < t.length; ++r){
                let e = t[r];
                if (J(e, Uint8Array)) i + e.length > n.length ? (o.isBuffer(e) || (e = o.from(e)), e.copy(n, i)) : Uint8Array.prototype.set.call(n, e, i);
                else {
                    if (!o.isBuffer(e)) throw new TypeError('"list" argument must be an Array of Buffers');
                    e.copy(n, i);
                }
                i += e.length;
            }
            return n;
        }, o.byteLength = d, o.prototype._isBuffer = !0, o.prototype.swap16 = function() {
            const t = this.length;
            if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
            for(let e = 0; e < t; e += 2)w(this, e, e + 1);
            return this;
        }, o.prototype.swap32 = function() {
            const t = this.length;
            if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
            for(let e = 0; e < t; e += 4)w(this, e, e + 3), w(this, e + 1, e + 2);
            return this;
        }, o.prototype.swap64 = function() {
            const t = this.length;
            if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
            for(let e = 0; e < t; e += 8)w(this, e, e + 7), w(this, e + 1, e + 6), w(this, e + 2, e + 5), w(this, e + 3, e + 4);
            return this;
        }, o.prototype.toLocaleString = o.prototype.toString = function() {
            const t = this.length;
            return 0 === t ? "" : 0 === arguments.length ? U(this, 0, t) : m.apply(this, arguments);
        }, o.prototype.equals = function(t) {
            if (!o.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
            return this === t || 0 === o.compare(this, t);
        }, o.prototype.inspect = function() {
            let t = "";
            const r = e.INSPECT_MAX_BYTES;
            return t = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (t += " ... "), "<Buffer " + t + ">";
        }, r && (o.prototype[r] = o.prototype.inspect), o.prototype.compare = function(t, e, r, n, i) {
            if (J(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), !o.isBuffer(t)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof t);
            if (void 0 === e && (e = 0), void 0 === r && (r = t ? t.length : 0), void 0 === n && (n = 0), void 0 === i && (i = this.length), e < 0 || r > t.length || n < 0 || i > this.length) throw new RangeError("out of range index");
            if (n >= i && e >= r) return 0;
            if (n >= i) return -1;
            if (e >= r) return 1;
            if (this === t) return 0;
            let s = (i >>>= 0) - (n >>>= 0), u = (r >>>= 0) - (e >>>= 0);
            const f = Math.min(s, u), a = this.slice(n, i), c = t.slice(e, r);
            for(let t = 0; t < f; ++t)if (a[t] !== c[t]) {
                s = a[t], u = c[t];
                break;
            }
            return s < u ? -1 : u < s ? 1 : 0;
        }, o.prototype.includes = function(t, e, r) {
            return -1 !== this.indexOf(t, e, r);
        }, o.prototype.indexOf = function(t, e, r) {
            return v(this, t, e, r, !0);
        }, o.prototype.lastIndexOf = function(t, e, r) {
            return v(this, t, e, r, !1);
        }, o.prototype.write = function(t, e, r, n) {
            if (void 0 === e) n = "utf8", r = this.length, e = 0;
            else if (void 0 === r && "string" == typeof e) n = e, r = this.length, e = 0;
            else {
                if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                e >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
            }
            const i = this.length - e;
            if ((void 0 === r || r > i) && (r = i), t.length > 0 && (r < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
            n || (n = "utf8");
            let o = !1;
            for(;;)switch(n){
                case "hex":
                    return E(this, t, e, r);
                case "utf8":
                case "utf-8":
                    return B(this, t, e, r);
                case "ascii":
                case "latin1":
                case "binary":
                    return A(this, t, e, r);
                case "base64":
                    return x(this, t, e, r);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return I(this, t, e, r);
                default:
                    if (o) throw new TypeError("Unknown encoding: " + n);
                    n = ("" + n).toLowerCase(), o = !0;
            }
        }, o.prototype.toJSON = function() {
            return {
                type: "Buffer",
                data: Array.prototype.slice.call(this._arr || this, 0)
            };
        };
        const S = 4096;
        function k(t, e, r) {
            let n = "";
            r = Math.min(t.length, r);
            for(let i = e; i < r; ++i)n += String.fromCharCode(127 & t[i]);
            return n;
        }
        function T(t, e, r) {
            let n = "";
            r = Math.min(t.length, r);
            for(let i = e; i < r; ++i)n += String.fromCharCode(t[i]);
            return n;
        }
        function R(t, e, r) {
            const n = t.length;
            (!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n);
            let i = "";
            for(let n = e; n < r; ++n)i += X[t[n]];
            return i;
        }
        function _(t, e, r) {
            const n = t.slice(e, r);
            let i = "";
            for(let t = 0; t < n.length - 1; t += 2)i += String.fromCharCode(n[t] + 256 * n[t + 1]);
            return i;
        }
        function O(t, e, r) {
            if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
            if (t + e > r) throw new RangeError("Trying to access beyond buffer length");
        }
        function C(t, e, r, n, i, s) {
            if (!o.isBuffer(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
            if (e > i || e < s) throw new RangeError('"value" argument is out of bounds');
            if (r + n > t.length) throw new RangeError("Index out of range");
        }
        function L(t, e, r, n, i) {
            D(e, n, i, t, r, 7);
            let o = Number(e & BigInt(4294967295));
            t[r++] = o, o >>= 8, t[r++] = o, o >>= 8, t[r++] = o, o >>= 8, t[r++] = o;
            let s = Number(e >> BigInt(32) & BigInt(4294967295));
            return t[r++] = s, s >>= 8, t[r++] = s, s >>= 8, t[r++] = s, s >>= 8, t[r++] = s, r;
        }
        function M(t, e, r, n, i) {
            D(e, n, i, t, r, 7);
            let o = Number(e & BigInt(4294967295));
            t[r + 7] = o, o >>= 8, t[r + 6] = o, o >>= 8, t[r + 5] = o, o >>= 8, t[r + 4] = o;
            let s = Number(e >> BigInt(32) & BigInt(4294967295));
            return t[r + 3] = s, s >>= 8, t[r + 2] = s, s >>= 8, t[r + 1] = s, s >>= 8, t[r] = s, r + 8;
        }
        function N(t, e, r, n, i, o) {
            if (r + n > t.length) throw new RangeError("Index out of range");
            if (r < 0) throw new RangeError("Index out of range");
        }
        function j(t, e, r, n, i) {
            return e = +e, r >>>= 0, i || N(t, 0, r, 4), y(t, e, r, n, 23, 4), r + 4;
        }
        function F(t, e, r, n, i) {
            return e = +e, r >>>= 0, i || N(t, 0, r, 8), y(t, e, r, n, 52, 8), r + 8;
        }
        o.prototype.slice = function(t, e) {
            const r = this.length;
            (t = ~~t) < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), (e = void 0 === e ? r : ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), e < t && (e = t);
            const n = this.subarray(t, e);
            return Object.setPrototypeOf(n, o.prototype), n;
        }, o.prototype.readUintLE = o.prototype.readUIntLE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            let n = this[t], i = 1, o = 0;
            for(; ++o < e && (i *= 256);)n += this[t + o] * i;
            return n;
        }, o.prototype.readUintBE = o.prototype.readUIntBE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            let n = this[t + --e], i = 1;
            for(; e > 0 && (i *= 256);)n += this[t + --e] * i;
            return n;
        }, o.prototype.readUint8 = o.prototype.readUInt8 = function(t, e) {
            return t >>>= 0, e || O(t, 1, this.length), this[t];
        }, o.prototype.readUint16LE = o.prototype.readUInt16LE = function(t, e) {
            return t >>>= 0, e || O(t, 2, this.length), this[t] | this[t + 1] << 8;
        }, o.prototype.readUint16BE = o.prototype.readUInt16BE = function(t, e) {
            return t >>>= 0, e || O(t, 2, this.length), this[t] << 8 | this[t + 1];
        }, o.prototype.readUint32LE = o.prototype.readUInt32LE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
        }, o.prototype.readUint32BE = o.prototype.readUInt32BE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
        }, o.prototype.readBigUInt64LE = Q(function(t) {
            H(t >>>= 0, "offset");
            const e = this[t], r = this[t + 7];
            void 0 !== e && void 0 !== r || G(t, this.length - 8);
            const n = e + 256 * this[++t] + 65536 * this[++t] + this[++t] * 2 ** 24, i = this[++t] + 256 * this[++t] + 65536 * this[++t] + r * 2 ** 24;
            return BigInt(n) + (BigInt(i) << BigInt(32));
        }), o.prototype.readBigUInt64BE = Q(function(t) {
            H(t >>>= 0, "offset");
            const e = this[t], r = this[t + 7];
            void 0 !== e && void 0 !== r || G(t, this.length - 8);
            const n = e * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + this[++t], i = this[++t] * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + r;
            return (BigInt(n) << BigInt(32)) + BigInt(i);
        }), o.prototype.readIntLE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            let n = this[t], i = 1, o = 0;
            for(; ++o < e && (i *= 256);)n += this[t + o] * i;
            return i *= 128, n >= i && (n -= Math.pow(2, 8 * e)), n;
        }, o.prototype.readIntBE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            let n = e, i = 1, o = this[t + --n];
            for(; n > 0 && (i *= 256);)o += this[t + --n] * i;
            return i *= 128, o >= i && (o -= Math.pow(2, 8 * e)), o;
        }, o.prototype.readInt8 = function(t, e) {
            return t >>>= 0, e || O(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
        }, o.prototype.readInt16LE = function(t, e) {
            t >>>= 0, e || O(t, 2, this.length);
            const r = this[t] | this[t + 1] << 8;
            return 32768 & r ? 4294901760 | r : r;
        }, o.prototype.readInt16BE = function(t, e) {
            t >>>= 0, e || O(t, 2, this.length);
            const r = this[t + 1] | this[t] << 8;
            return 32768 & r ? 4294901760 | r : r;
        }, o.prototype.readInt32LE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
        }, o.prototype.readInt32BE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
        }, o.prototype.readBigInt64LE = Q(function(t) {
            H(t >>>= 0, "offset");
            const e = this[t], r = this[t + 7];
            return void 0 !== e && void 0 !== r || G(t, this.length - 8), (BigInt(this[t + 4] + 256 * this[t + 5] + 65536 * this[t + 6] + (r << 24)) << BigInt(32)) + BigInt(e + 256 * this[++t] + 65536 * this[++t] + this[++t] * 2 ** 24);
        }), o.prototype.readBigInt64BE = Q(function(t) {
            H(t >>>= 0, "offset");
            const e = this[t], r = this[t + 7];
            void 0 !== e && void 0 !== r || G(t, this.length - 8);
            const n = (e << 24) + 65536 * this[++t] + 256 * this[++t] + this[++t];
            return (BigInt(n) << BigInt(32)) + BigInt(this[++t] * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + r);
        }), o.prototype.readFloatLE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), g(this, t, !0, 23, 4);
        }, o.prototype.readFloatBE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), g(this, t, !1, 23, 4);
        }, o.prototype.readDoubleLE = function(t, e) {
            return t >>>= 0, e || O(t, 8, this.length), g(this, t, !0, 52, 8);
        }, o.prototype.readDoubleBE = function(t, e) {
            return t >>>= 0, e || O(t, 8, this.length), g(this, t, !1, 52, 8);
        }, o.prototype.writeUintLE = o.prototype.writeUIntLE = function(t, e, r, n) {
            t = +t, e >>>= 0, r >>>= 0, n || C(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
            let i = 1, o = 0;
            for(this[e] = 255 & t; ++o < r && (i *= 256);)this[e + o] = t / i & 255;
            return e + r;
        }, o.prototype.writeUintBE = o.prototype.writeUIntBE = function(t, e, r, n) {
            t = +t, e >>>= 0, r >>>= 0, n || C(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
            let i = r - 1, o = 1;
            for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)this[e + i] = t / o & 255;
            return e + r;
        }, o.prototype.writeUint8 = o.prototype.writeUInt8 = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 1, 255, 0), this[e] = 255 & t, e + 1;
        }, o.prototype.writeUint16LE = o.prototype.writeUInt16LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 65535, 0), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
        }, o.prototype.writeUint16BE = o.prototype.writeUInt16BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 65535, 0), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
        }, o.prototype.writeUint32LE = o.prototype.writeUInt32LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 4294967295, 0), this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t, e + 4;
        }, o.prototype.writeUint32BE = o.prototype.writeUInt32BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 4294967295, 0), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
        }, o.prototype.writeBigUInt64LE = Q(function(t, e = 0) {
            return L(this, t, e, BigInt(0), BigInt("0xffffffffffffffff"));
        }), o.prototype.writeBigUInt64BE = Q(function(t, e = 0) {
            return M(this, t, e, BigInt(0), BigInt("0xffffffffffffffff"));
        }), o.prototype.writeIntLE = function(t, e, r, n) {
            if (t = +t, e >>>= 0, !n) {
                const n = Math.pow(2, 8 * r - 1);
                C(this, t, e, r, n - 1, -n);
            }
            let i = 0, o = 1, s = 0;
            for(this[e] = 255 & t; ++i < r && (o *= 256);)t < 0 && 0 === s && 0 !== this[e + i - 1] && (s = 1), this[e + i] = (t / o >> 0) - s & 255;
            return e + r;
        }, o.prototype.writeIntBE = function(t, e, r, n) {
            if (t = +t, e >>>= 0, !n) {
                const n = Math.pow(2, 8 * r - 1);
                C(this, t, e, r, n - 1, -n);
            }
            let i = r - 1, o = 1, s = 0;
            for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)t < 0 && 0 === s && 0 !== this[e + i + 1] && (s = 1), this[e + i] = (t / o >> 0) - s & 255;
            return e + r;
        }, o.prototype.writeInt8 = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 1, 127, -128), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
        }, o.prototype.writeInt16LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 32767, -32768), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
        }, o.prototype.writeInt16BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 32767, -32768), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
        }, o.prototype.writeInt32LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 2147483647, -2147483648), this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24, e + 4;
        }, o.prototype.writeInt32BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
        }, o.prototype.writeBigInt64LE = Q(function(t, e = 0) {
            return L(this, t, e, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
        }), o.prototype.writeBigInt64BE = Q(function(t, e = 0) {
            return M(this, t, e, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
        }), o.prototype.writeFloatLE = function(t, e, r) {
            return j(this, t, e, !0, r);
        }, o.prototype.writeFloatBE = function(t, e, r) {
            return j(this, t, e, !1, r);
        }, o.prototype.writeDoubleLE = function(t, e, r) {
            return F(this, t, e, !0, r);
        }, o.prototype.writeDoubleBE = function(t, e, r) {
            return F(this, t, e, !1, r);
        }, o.prototype.copy = function(t, e, r, n) {
            if (!o.isBuffer(t)) throw new TypeError("argument should be a Buffer");
            if (r || (r = 0), n || 0 === n || (n = this.length), e >= t.length && (e = t.length), e || (e = 0), n > 0 && n < r && (n = r), n === r) return 0;
            if (0 === t.length || 0 === this.length) return 0;
            if (e < 0) throw new RangeError("targetStart out of bounds");
            if (r < 0 || r >= this.length) throw new RangeError("Index out of range");
            if (n < 0) throw new RangeError("sourceEnd out of bounds");
            n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r);
            const i = n - r;
            return this === t && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(e, r, n) : Uint8Array.prototype.set.call(t, this.subarray(r, n), e), i;
        }, o.prototype.fill = function(t, e, r, n) {
            if ("string" == typeof t) {
                if ("string" == typeof e ? (n = e, e = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw new TypeError("encoding must be a string");
                if ("string" == typeof n && !o.isEncoding(n)) throw new TypeError("Unknown encoding: " + n);
                if (1 === t.length) {
                    const e = t.charCodeAt(0);
                    ("utf8" === n && e < 128 || "latin1" === n) && (t = e);
                }
            } else "number" == typeof t ? t &= 255 : "boolean" == typeof t && (t = Number(t));
            if (e < 0 || this.length < e || this.length < r) throw new RangeError("Out of range index");
            if (r <= e) return this;
            let i;
            if (e >>>= 0, r = void 0 === r ? this.length : r >>> 0, t || (t = 0), "number" == typeof t) for(i = e; i < r; ++i)this[i] = t;
            else {
                const s = o.isBuffer(t) ? t : o.from(t, n), u = s.length;
                if (0 === u) throw new TypeError('The value "' + t + '" is invalid for argument "value"');
                for(i = 0; i < r - e; ++i)this[i + e] = s[i % u];
            }
            return this;
        };
        const $ = {};
        function q(t, e, r) {
            $[t] = class extends r {
                constructor(){
                    super(), Object.defineProperty(this, "message", {
                        value: e.apply(this, arguments),
                        writable: !0,
                        configurable: !0
                    }), this.name = `${this.name} [${t}]`, delete this.name;
                }
                get code() {
                    return t;
                }
                set code(t) {
                    Object.defineProperty(this, "code", {
                        configurable: !0,
                        enumerable: !0,
                        value: t,
                        writable: !0
                    });
                }
                toString() {
                    return `${this.name} [${t}]: ${this.message}`;
                }
            };
        }
        function z(t) {
            let e = "", r = t.length;
            const n = "-" === t[0] ? 1 : 0;
            for(; r >= n + 4; r -= 3)e = `_${t.slice(r - 3, r)}${e}`;
            return `${t.slice(0, r)}${e}`;
        }
        function D(t, e, r, n, i, o) {
            if (t > r || t < e) {
                const n = "bigint" == typeof e ? "n" : "";
                let i;
                throw i = o > 3 ? 0 === e || e === BigInt(0) ? `>= 0${n} and < 2${n} ** ${8 * (o + 1)}${n}` : `>= -(2${n} ** ${8 * (o + 1) - 1}${n}) and < 2 ** ${8 * (o + 1) - 1}${n}` : `>= ${e}${n} and <= ${r}${n}`, new $.ERR_OUT_OF_RANGE("value", i, t);
            }
            !function(t, e, r) {
                H(e, "offset"), void 0 !== t[e] && void 0 !== t[e + r] || G(e, t.length - (r + 1));
            }(n, i, o);
        }
        function H(t, e) {
            if ("number" != typeof t) throw new $.ERR_INVALID_ARG_TYPE(e, "number", t);
        }
        function G(t, e, r) {
            if (Math.floor(t) !== t) throw H(t, r), new $.ERR_OUT_OF_RANGE(r || "offset", "an integer", t);
            if (e < 0) throw new $.ERR_BUFFER_OUT_OF_BOUNDS;
            throw new $.ERR_OUT_OF_RANGE(r || "offset", `>= ${r ? 1 : 0} and <= ${e}`, t);
        }
        q("ERR_BUFFER_OUT_OF_BOUNDS", function(t) {
            return t ? `${t} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
        }, RangeError), q("ERR_INVALID_ARG_TYPE", function(t, e) {
            return `The "${t}" argument must be of type number. Received type ${typeof e}`;
        }, TypeError), q("ERR_OUT_OF_RANGE", function(t, e, r) {
            let n = `The value of "${t}" is out of range.`, i = r;
            return Number.isInteger(r) && Math.abs(r) > 2 ** 32 ? i = z(String(r)) : "bigint" == typeof r && (i = String(r), (r > BigInt(2) ** BigInt(32) || r < -(BigInt(2) ** BigInt(32))) && (i = z(i)), i += "n"), n += ` It must be ${e}. Received ${i}`, n;
        }, RangeError);
        const W = /[^+/0-9A-Za-z-_]/g;
        function K(t, e) {
            let r;
            e = e || Infinity;
            const n = t.length;
            let i = null;
            const o = [];
            for(let s = 0; s < n; ++s){
                if (r = t.charCodeAt(s), r > 55295 && r < 57344) {
                    if (!i) {
                        if (r > 56319) {
                            (e -= 3) > -1 && o.push(239, 191, 189);
                            continue;
                        }
                        if (s + 1 === n) {
                            (e -= 3) > -1 && o.push(239, 191, 189);
                            continue;
                        }
                        i = r;
                        continue;
                    }
                    if (r < 56320) {
                        (e -= 3) > -1 && o.push(239, 191, 189), i = r;
                        continue;
                    }
                    r = 65536 + (i - 55296 << 10 | r - 56320);
                } else i && (e -= 3) > -1 && o.push(239, 191, 189);
                if (i = null, r < 128) {
                    if ((e -= 1) < 0) break;
                    o.push(r);
                } else if (r < 2048) {
                    if ((e -= 2) < 0) break;
                    o.push(r >> 6 | 192, 63 & r | 128);
                } else if (r < 65536) {
                    if ((e -= 3) < 0) break;
                    o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
                } else {
                    if (!(r < 1114112)) throw new Error("Invalid code point");
                    if ((e -= 4) < 0) break;
                    o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
                }
            }
            return o;
        }
        function V(t) {
            return l(function(t) {
                if ((t = (t = t.split("=")[0]).trim().replace(W, "")).length < 2) return "";
                for(; t.length % 4 != 0;)t += "=";
                return t;
            }(t));
        }
        function Z(t, e, r, n) {
            let i;
            for(i = 0; i < n && !(i + r >= e.length || i >= t.length); ++i)e[i + r] = t[i];
            return i;
        }
        function J(t, e) {
            return t instanceof e || null != t && null != t.constructor && null != t.constructor.name && t.constructor.name === e.name;
        }
        function Y(t) {
            return t != t;
        }
        const X = function() {
            const t = "0123456789abcdef", e = new Array(256);
            for(let r = 0; r < 16; ++r){
                const n = 16 * r;
                for(let i = 0; i < 16; ++i)e[n + i] = t[r] + t[i];
            }
            return e;
        }();
        function Q(t) {
            return "undefined" == typeof BigInt ? tt : t;
        }
        function tt() {
            throw new Error("BigInt not supported");
        }
    }), m = function(t, e) {
        return function(r, n) {
            var i = 2 * n, o = 2 * e;
            r[i] = t[o], r[i + 1] = t[o + 1];
        };
    }, w = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r, n = (r = m) && r.__esModule ? r : {
            default: r
        };
        e.default = function(t) {
            for(var e = t.A, r = t.C, i = 0; i < 25; i += 5){
                for(var o = 0; o < 5; o++)(0, n.default)(e, i + o)(r, o);
                for(var s = 0; s < 5; s++){
                    var u = 2 * (i + s), f = (s + 1) % 5 * 2, a = (s + 2) % 5 * 2;
                    e[u] ^= ~r[f] & r[a], e[u + 1] ^= ~r[f + 1] & r[a + 1];
                }
            }
        };
    }), v = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = new Uint32Array([
            0,
            1,
            0,
            32898,
            2147483648,
            32906,
            2147483648,
            2147516416,
            0,
            32907,
            0,
            2147483649,
            2147483648,
            2147516545,
            2147483648,
            32777,
            0,
            138,
            0,
            136,
            0,
            2147516425,
            0,
            2147483658,
            0,
            2147516555,
            2147483648,
            139,
            2147483648,
            32905,
            2147483648,
            32771,
            2147483648,
            32770,
            2147483648,
            128,
            0,
            32778,
            2147483648,
            2147483658,
            2147483648,
            2147516545,
            2147483648,
            32896,
            0,
            2147483649,
            2147483648,
            2147516424
        ]);
        e.default = r;
    }), b = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r, n = (r = v) && r.__esModule ? r : {
            default: r
        };
        e.default = function(t) {
            var e = t.A, r = 2 * t.roundIndex;
            e[0] ^= n.default[r], e[1] ^= n.default[r + 1];
        };
    }), E = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, e.default = [
            10,
            7,
            11,
            17,
            18,
            3,
            5,
            16,
            8,
            21,
            24,
            4,
            15,
            23,
            19,
            13,
            12,
            2,
            20,
            14,
            22,
            9,
            6,
            1
        ];
    }), B = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, e.default = [
            1,
            3,
            6,
            10,
            15,
            21,
            28,
            36,
            45,
            55,
            2,
            14,
            27,
            41,
            56,
            8,
            25,
            43,
            62,
            18,
            39,
            61,
            20,
            44
        ];
    }), A = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = o(E), n = o(B), i = o(m);
        function o(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        e.default = function(t) {
            var e = t.A, o = t.C, s = t.W;
            (0, i.default)(e, 1)(s, 0);
            for(var u = 0, f = 0, a = 0, c = 32, h = 0; h < 24; h++){
                var l = r.default[h], p = n.default[h];
                (0, i.default)(e, l)(o, 0), s[a = p < 32 ? 0 : 1] = (u = s[0]) << p | (f = s[1]) >>> (c = 32 - p), s[(a + 1) % 2] = f << p | u >>> c, (0, i.default)(s, 0)(e, l), (0, i.default)(o, 0)(s, 0);
            }
        };
    }), x = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r, n = (r = m) && r.__esModule ? r : {
            default: r
        };
        e.default = function(t) {
            for(var e = t.A, r = t.C, i = t.D, o = t.W, s = 0, u = 0, f = 0; f < 5; f++){
                var a = 2 * f, c = 2 * (f + 5), h = 2 * (f + 10), l = 2 * (f + 15), p = 2 * (f + 20);
                r[a] = e[a] ^ e[c] ^ e[h] ^ e[l] ^ e[p], r[a + 1] = e[a + 1] ^ e[c + 1] ^ e[h + 1] ^ e[l + 1] ^ e[p + 1];
            }
            for(var g = 0; g < 5; g++){
                (0, n.default)(r, (g + 1) % 5)(o, 0), o[0] = (s = o[0]) << 1 | (u = o[1]) >>> 31, o[1] = u << 1 | s >>> 31, i[2 * g] = r[(g + 4) % 5 * 2] ^ o[0], i[2 * g + 1] = r[(g + 4) % 5 * 2 + 1] ^ o[1];
                for(var y = 0; y < 25; y += 5)e[2 * (y + g)] ^= i[2 * g], e[2 * (y + g) + 1] ^= i[2 * g + 1];
            }
        };
    }), I = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = s(w), n = s(b), i = s(A), o = s(x);
        function s(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        e.default = function() {
            var t = new Uint32Array(10), e = new Uint32Array(10), s = new Uint32Array(2);
            return function(u) {
                for(var f = 0; f < 24; f++)(0, o.default)({
                    A: u,
                    C: t,
                    D: e,
                    W: s
                }), (0, i.default)({
                    A: u,
                    C: t,
                    W: s
                }), (0, r.default)({
                    A: u,
                    C: t
                }), (0, n.default)({
                    A: u,
                    roundIndex: f
                });
                t.fill(0), e.fill(0), s.fill(0);
            };
        };
    }), P = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r, n = (r = I) && r.__esModule ? r : {
            default: r
        }, i = function(t, e) {
            for(var r = 0; r < t.length; r += 8){
                var n = r / 4;
                e[n] ^= t[r + 7] << 24 | t[r + 6] << 16 | t[r + 5] << 8 | t[r + 4], e[n + 1] ^= t[r + 3] << 24 | t[r + 2] << 16 | t[r + 1] << 8 | t[r];
            }
            return e;
        }, o = function(t, e) {
            for(var r = 0; r < e.length; r += 8){
                var n = r / 4;
                e[r] = t[n + 1], e[r + 1] = t[n + 1] >>> 8, e[r + 2] = t[n + 1] >>> 16, e[r + 3] = t[n + 1] >>> 24, e[r + 4] = t[n], e[r + 5] = t[n] >>> 8, e[r + 6] = t[n] >>> 16, e[r + 7] = t[n] >>> 24;
            }
            return e;
        };
        e.default = function(t) {
            var e = this, r = t.capacity, s = t.padding, u = (0, n.default)(), f = r / 8, a = 200 - r / 4, c = 0, h = new Uint32Array(50), l = d.Buffer.allocUnsafe(a);
            return this.absorb = function(t) {
                for(var r = 0; r < t.length; r++)l[c] = t[r], (c += 1) >= a && (i(l, h), u(h), c = 0);
                return e;
            }, this.squeeze = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = {
                    buffer: t.buffer || d.Buffer.allocUnsafe(f),
                    padding: t.padding || s,
                    queue: d.Buffer.allocUnsafe(l.length),
                    state: new Uint32Array(h.length)
                };
                l.copy(e.queue);
                for(var r = 0; r < h.length; r++)e.state[r] = h[r];
                e.queue.fill(0, c), e.queue[c] |= e.padding, e.queue[a - 1] |= 128, i(e.queue, e.state);
                for(var n = 0; n < e.buffer.length; n += a)u(e.state), o(e.state, e.buffer.slice(n, n + a));
                return e.buffer;
            }, this.reset = function() {
                return l.fill(0), h.fill(0), c = 0, e;
            }, this;
        };
    }), U = i(function(t, e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = e.SHAKE = e.SHA3Hash = e.SHA3 = e.Keccak = void 0;
        var r, n = (r = P) && r.__esModule ? r : {
            default: r
        }, i = function(t) {
            var e = t.allowedSizes, r = t.defaultSize, i = t.padding;
            return function t() {
                var o = this, s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r;
                if (!this || this.constructor !== t) return new t(s);
                if (e && !e.includes(s)) throw new Error("Unsupported hash length");
                var u = new n.default({
                    capacity: s
                });
                return this.update = function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "utf8";
                    if (d.Buffer.isBuffer(t)) return u.absorb(t), o;
                    if ("string" == typeof t) return o.update(d.Buffer.from(t, e));
                    throw new TypeError("Not a string or buffer");
                }, this.digest = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "binary", e = "string" == typeof t ? {
                        format: t
                    } : t, r = u.squeeze({
                        buffer: e.buffer,
                        padding: e.padding || i
                    });
                    return e.format && "binary" !== e.format ? r.toString(e.format) : r;
                }, this.reset = function() {
                    return u.reset(), o;
                }, this;
            };
        }, o = i({
            allowedSizes: [
                224,
                256,
                384,
                512
            ],
            defaultSize: 512,
            padding: 1
        });
        e.Keccak = o;
        var s = i({
            allowedSizes: [
                224,
                256,
                384,
                512
            ],
            defaultSize: 512,
            padding: 6
        });
        e.SHA3 = s;
        var u = i({
            allowedSizes: [
                128,
                256
            ],
            defaultSize: 256,
            padding: 31
        });
        e.SHAKE = u;
        var f = o;
        e.SHA3Hash = f, s.SHA3Hash = f, e.default = s;
    });
    function S(t) {
        return BigInt(t).toString();
    }
    var k = "0".repeat(64), T = "0".repeat(63) + "1";
    function R(t, e) {
        var r = new U.Keccak(256), n = t.name + "(" + t.inputs.map(function(t) {
            return "uint[]" === (e = t.type) ? "uint256[]" : "int[]" === e ? "int256[]" : e;
            //TURBOPACK unreachable
            ;
            var e;
        }) + ")", i = r.update(n).digest("hex"), o = t.inputs.length, s = !0;
        if (t.inputs.find(function(t) {
            return t.type.includes("[");
        }) && (s = !1), s && e.length !== o) throw new Error('args inputs  of "' + e.length + '" does not match expected length of "' + t.inputs.length + '"');
        var u = (t.inputs || []).reduce(function(t, r, n) {
            if (r.type.includes("[")) {
                var i, o = null == (i = /([^[]*)\[.*$/g.exec(r.type)) ? void 0 : i[1];
                return e.forEach(function(e) {
                    t = t.concat([
                        [
                            e,
                            o
                        ]
                    ]);
                }), t;
            }
            return t.concat([
                [
                    e[n],
                    r.type
                ]
            ]);
        }, []), f = u.map(function(t) {
            var e = t[0], r = t[1], n = e;
            switch(r){
                case "bool":
                    return e ? T : k;
                case "address":
                    n = e.replace(/^0x/g, "").toLowerCase();
                    break;
                default:
                    if (r.startsWith("bytes")) return n.split("").map(function(t) {
                        return t.charCodeAt(0).toString(16);
                    }).join("").padEnd(64, "0");
                    if ("uint256" === r) return BigInt(e).toString(16).padStart(64, "0");
                    if (r.startsWith("uint")) break;
                    throw new Error('essential-eth does not yet support "' + r + '" inputs. Make a PR today!"');
            }
            return n.toString(16).padStart(64, "0");
        });
        return "0x" + i.slice(0, 8) + f.join("");
    }
    function _(t, e) {
        var r = t.outputs, n = (e.slice(2).match(/.{1,64}/g) || []).map(function(t, e) {
            var n = (r || [])[e].type;
            switch(n){
                case "bool":
                    return t === T;
                case "address":
                    return tt("0x" + t.slice(24));
                case "uint256":
                case "uint120":
                    return Y(S("0x" + t));
                case "bytes32":
                    return "0x" + t;
                case "uint8":
                    return Number(S("0x" + t));
                default:
                    throw new Error('essential-eth does not yet support "' + n + '" outputs. Make a PR today!"');
            }
        });
        return 1 === n.length ? n[0] : n;
    }
    function O(t) {
        t.split("").reduce(function(t, e) {
            return t + ("0" === e ? 4 : 68);
        }, 0);
    }
    var C = function(t, r, n) {
        var i = this, o = this;
        this._address = void 0, this._provider = void 0, this._address = t, this._provider = n, r.filter(function(t) {
            return "function" === t.type;
        }).forEach(function(t) {
            var r;
            "name" in t && "string" == typeof t.name && (r = function() {
                try {
                    var r = arguments, n = [].slice.call(r), i = n, s = {}, u = n[n.length - 1];
                    Array.isArray(u) || "object" != typeof u || (s = u, i = n.slice(0, n.length - 1));
                    var f = R(t, i), a = "number" == typeof s.gasLimit ? s.gasLimit : "number" == typeof (null == t ? void 0 : t.gas) ? O(f) : null, c = function() {
                        try {
                            return Promise.resolve(o._provider.call(e({
                                to: o._address.toLowerCase(),
                                data: f
                            }, a ? {
                                gas: "0x" + a.toString(16)
                            } : {}), "latest"));
                        } catch (t) {
                            return Promise.reject(t);
                        }
                    };
                    return Promise.resolve(c()).then(function(e) {
                        return _(t, e);
                    });
                } catch (t) {
                    return Promise.reject(t);
                }
            }, Object.defineProperty(i, t.name, {
                enumerable: !0,
                value: r,
                writable: !1
            }));
        });
    }, L = /*#__PURE__*/ function(t) {
        function e() {
            return t.apply(this, arguments) || this;
        }
        return r(e, t), e;
    }(C), M = new (/*#__PURE__*/ function() {
        function t() {
            this.packageVersion = void 0, this.packageVersion = "0.6.2";
        }
        var e = t.prototype;
        return e.throwError = function(t, e) {
            var r = Object.keys(e).length;
            throw new Error(t + " (" + Object.entries(e).map(function(t, e) {
                return t[0] + "=" + t[1] + (e < r - 1 && ", ");
            }) + ", version=essential-eth@" + this.packageVersion + ")");
        }, e.throwArgumentError = function(t, e, r) {
            throw new Error(t + ' (argument="' + e + '" value=' + r + ", version=essential-eth@" + this.packageVersion + ")");
        }, e.checkSafeUint53 = function(t, e) {
            void 0 === e && (e = "value not safe"), "number" == typeof t && ((t < 0 || t >= 9007199254740991) && this.throwError(e, {
                operation: "checkSafeInteger",
                fault: "out-of-safe-range",
                value: t
            }), t % 1 && this.throwError(e, {
                operation: "checkSafeInteger",
                fault: "non-integer",
                value: t
            }));
        }, t;
    }()), N = 1e6, j = "[big.js] ", F = j + "Invalid ", $ = F + "decimal places", q = j + "Division by zero", z = {}, D = void 0, H = /^-?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
    function G(t, e, r, n) {
        var i = t.c;
        if (r === D && (r = t.constructor.RM), 0 !== r && 1 !== r && 2 !== r && 3 !== r) throw Error("[big.js] Invalid rounding mode");
        if (e < 1) n = 3 === r && (n || !!i[0]) || 0 === e && (1 === r && i[0] >= 5 || 2 === r && (i[0] > 5 || 5 === i[0] && (n || i[1] !== D))), i.length = 1, n ? (t.e = t.e - e + 1, i[0] = 1) : i[0] = t.e = 0;
        else if (e < i.length) {
            if (n = 1 === r && i[e] >= 5 || 2 === r && (i[e] > 5 || 5 === i[e] && (n || i[e + 1] !== D || 1 & i[e - 1])) || 3 === r && (n || !!i[0]), i.length = e, n) {
                for(; ++i[--e] > 9;)if (i[e] = 0, 0 === e) {
                    ++t.e, i.unshift(1);
                    break;
                }
            }
            for(e = i.length; !i[--e];)i.pop();
        }
        return t;
    }
    function W(t, e, r) {
        var n = t.e, i = t.c.join(""), o = i.length;
        if (e) i = i.charAt(0) + (o > 1 ? "." + i.slice(1) : "") + (n < 0 ? "e" : "e+") + n;
        else if (n < 0) {
            for(; ++n;)i = "0" + i;
            i = "0." + i;
        } else if (n > 0) if (++n > o) for(n -= o; n--;)i += "0";
        else n < o && (i = i.slice(0, n) + "." + i.slice(n));
        else o > 1 && (i = i.charAt(0) + "." + i.slice(1));
        return t.s < 0 && r ? "-" + i : i;
    }
    z.abs = function() {
        var t = new this.constructor(this);
        return t.s = 1, t;
    }, z.cmp = function(t) {
        var e, r = this, n = r.c, i = (t = new r.constructor(t)).c, o = r.s, s = t.s, u = r.e, f = t.e;
        if (!n[0] || !i[0]) return n[0] ? o : i[0] ? -s : 0;
        if (o != s) return o;
        if (e = o < 0, u != f) return u > f ^ e ? 1 : -1;
        for(s = (u = n.length) < (f = i.length) ? u : f, o = -1; ++o < s;)if (n[o] != i[o]) return n[o] > i[o] ^ e ? 1 : -1;
        return u == f ? 0 : u > f ^ e ? 1 : -1;
    }, z.div = function(t) {
        var e = this, r = e.constructor, n = e.c, i = (t = new r(t)).c, o = e.s == t.s ? 1 : -1, s = r.DP;
        if (s !== ~~s || s < 0 || s > N) throw Error($);
        if (!i[0]) throw Error(q);
        if (!n[0]) return t.s = o, t.c = [
            t.e = 0
        ], t;
        var u, f, a, c, h, l = i.slice(), p = u = i.length, g = n.length, y = n.slice(0, u), d = y.length, m = t, w = m.c = [], v = 0, b = s + (m.e = e.e - t.e) + 1;
        for(m.s = o, o = b < 0 ? 0 : b, l.unshift(0); d++ < u;)y.push(0);
        do {
            for(a = 0; a < 10; a++){
                if (u != (d = y.length)) c = u > d ? 1 : -1;
                else for(h = -1, c = 0; ++h < u;)if (i[h] != y[h]) {
                    c = i[h] > y[h] ? 1 : -1;
                    break;
                }
                if (!(c < 0)) break;
                for(f = d == u ? i : l; d;){
                    if (y[--d] < f[d]) {
                        for(h = d; h && !y[--h];)y[h] = 9;
                        --y[h], y[d] += 10;
                    }
                    y[d] -= f[d];
                }
                for(; !y[0];)y.shift();
            }
            w[v++] = c ? a : ++a, y[0] && c ? y[d] = n[p] || 0 : y = [
                n[p]
            ];
        }while ((p++ < g || y[0] !== D) && o--)
        return w[0] || 1 == v || (w.shift(), m.e--, b--), v > b && G(m, b, r.RM, y[0] !== D), m;
    }, z.eq = function(t) {
        return 0 === this.cmp(t);
    }, z.gt = function(t) {
        return this.cmp(t) > 0;
    }, z.gte = function(t) {
        return this.cmp(t) > -1;
    }, z.lt = function(t) {
        return this.cmp(t) < 0;
    }, z.lte = function(t) {
        return this.cmp(t) < 1;
    }, z.minus = z.sub = function(t) {
        var e, r, n, i, o = this, s = o.constructor, u = o.s, f = (t = new s(t)).s;
        if (u != f) return t.s = -f, o.plus(t);
        var a = o.c.slice(), c = o.e, h = t.c, l = t.e;
        if (!a[0] || !h[0]) return h[0] ? t.s = -f : a[0] ? t = new s(o) : t.s = 1, t;
        if (u = c - l) {
            for((i = u < 0) ? (u = -u, n = a) : (l = c, n = h), n.reverse(), f = u; f--;)n.push(0);
            n.reverse();
        } else for(r = ((i = a.length < h.length) ? a : h).length, u = f = 0; f < r; f++)if (a[f] != h[f]) {
            i = a[f] < h[f];
            break;
        }
        if (i && (n = a, a = h, h = n, t.s = -t.s), (f = (r = h.length) - (e = a.length)) > 0) for(; f--;)a[e++] = 0;
        for(f = e; r > u;){
            if (a[--r] < h[r]) {
                for(e = r; e && !a[--e];)a[e] = 9;
                --a[e], a[r] += 10;
            }
            a[r] -= h[r];
        }
        for(; 0 === a[--f];)a.pop();
        for(; 0 === a[0];)a.shift(), --l;
        return a[0] || (t.s = 1, a = [
            l = 0
        ]), t.c = a, t.e = l, t;
    }, z.mod = function(t) {
        var e, r = this, n = r.constructor, i = r.s, o = (t = new n(t)).s;
        if (!t.c[0]) throw Error(q);
        return r.s = t.s = 1, e = 1 == t.cmp(r), r.s = i, t.s = o, e ? new n(r) : (i = n.DP, o = n.RM, n.DP = n.RM = 0, r = r.div(t), n.DP = i, n.RM = o, this.minus(r.times(t)));
    }, z.neg = function() {
        var t = new this.constructor(this);
        return t.s = -t.s, t;
    }, z.plus = z.add = function(t) {
        var e, r, n, i = this, o = i.constructor;
        if (t = new o(t), i.s != t.s) return t.s = -t.s, i.minus(t);
        var s = i.e, u = i.c, f = t.e, a = t.c;
        if (!u[0] || !a[0]) return a[0] || (u[0] ? t = new o(i) : t.s = i.s), t;
        if (u = u.slice(), e = s - f) {
            for(e > 0 ? (f = s, n = a) : (e = -e, n = u), n.reverse(); e--;)n.push(0);
            n.reverse();
        }
        for(u.length - a.length < 0 && (n = a, a = u, u = n), e = a.length, r = 0; e; u[e] %= 10)r = (u[--e] = u[e] + a[e] + r) / 10 | 0;
        for(r && (u.unshift(r), ++f), e = u.length; 0 === u[--e];)u.pop();
        return t.c = u, t.e = f, t;
    }, z.pow = function(t) {
        var e = this, r = new e.constructor("1"), n = r, i = t < 0;
        if (t !== ~~t || t < -1e6 || t > 1e6) throw Error(F + "exponent");
        for(i && (t = -t); 1 & t && (n = n.times(e)), t >>= 1;)e = e.times(e);
        return i ? r.div(n) : n;
    }, z.prec = function(t, e) {
        if (t !== ~~t || t < 1 || t > N) throw Error(F + "precision");
        return G(new this.constructor(this), t, e);
    }, z.round = function(t, e) {
        if (t === D) t = 0;
        else if (t !== ~~t || t < -N || t > N) throw Error($);
        return G(new this.constructor(this), t + this.e + 1, e);
    }, z.sqrt = function() {
        var t, e, r, n = this, i = n.constructor, o = n.s, s = n.e, u = new i("0.5");
        if (!n.c[0]) return new i(n);
        if (o < 0) throw Error(j + "No square root");
        0 === (o = Math.sqrt(n + "")) || o === 1 / 0 ? ((e = n.c.join("")).length + s & 1 || (e += "0"), s = ((s + 1) / 2 | 0) - (s < 0 || 1 & s), t = new i(((o = Math.sqrt(e)) == 1 / 0 ? "5e" : (o = o.toExponential()).slice(0, o.indexOf("e") + 1)) + s)) : t = new i(o + ""), s = t.e + (i.DP += 4);
        do {
            t = u.times((r = t).plus(n.div(r)));
        }while (r.c.slice(0, s).join("") !== t.c.slice(0, s).join(""))
        return G(t, (i.DP -= 4) + t.e + 1, i.RM);
    }, z.times = z.mul = function(t) {
        var e, r = this, n = r.c, i = (t = new (0, r.constructor)(t)).c, o = n.length, s = i.length, u = r.e, f = t.e;
        if (t.s = r.s == t.s ? 1 : -1, !n[0] || !i[0]) return t.c = [
            t.e = 0
        ], t;
        for(t.e = u + f, o < s && (e = n, n = i, i = e, f = o, o = s, s = f), e = new Array(f = o + s); f--;)e[f] = 0;
        for(u = s; u--;){
            for(s = 0, f = o + u; f > u;)s = e[f] + i[u] * n[f - u - 1] + s, e[f--] = s % 10, s = s / 10 | 0;
            e[f] = s;
        }
        for(s ? ++t.e : e.shift(), u = e.length; !e[--u];)e.pop();
        return t.c = e, t;
    }, z.toExponential = function(t, e) {
        var r = this, n = r.c[0];
        if (t !== D) {
            if (t !== ~~t || t < 0 || t > N) throw Error($);
            for(r = G(new r.constructor(r), ++t, e); r.c.length < t;)r.c.push(0);
        }
        return W(r, !0, !!n);
    }, z.toFixed = function(t, e) {
        var r = this, n = r.c[0];
        if (t !== D) {
            if (t !== ~~t || t < 0 || t > N) throw Error($);
            for(t = t + (r = G(new r.constructor(r), t + r.e + 1, e)).e + 1; r.c.length < t;)r.c.push(0);
        }
        return W(r, !1, !!n);
    }, z[Symbol.for("nodejs.util.inspect.custom")] = z.toJSON = z.toString = function() {
        var t = this, e = t.constructor;
        return W(t, t.e <= e.NE || t.e >= e.PE, !!t.c[0]);
    }, z.toNumber = function() {
        var t = Number(W(this, !0, !0));
        if (!0 === this.constructor.strict && !this.eq(t.toString())) throw Error(j + "Imprecise conversion");
        return t;
    }, z.toPrecision = function(t, e) {
        var r = this, n = r.constructor, i = r.c[0];
        if (t !== D) {
            if (t !== ~~t || t < 1 || t > N) throw Error(F + "precision");
            for(r = G(new n(r), t, e); r.c.length < t;)r.c.push(0);
        }
        return W(r, t <= r.e || r.e <= n.NE || r.e >= n.PE, !!i);
    }, z.valueOf = function() {
        var t = this, e = t.constructor;
        if (!0 === e.strict) throw Error(j + "valueOf disallowed");
        return W(t, t.e <= e.NE || t.e >= e.PE, !0);
    };
    var K = function t() {
        function e(r) {
            var n = this;
            if (!(n instanceof e)) return r === D ? t() : new e(r);
            if (r instanceof e) n.s = r.s, n.e = r.e, n.c = r.c.slice();
            else {
                if ("string" != typeof r) {
                    if (!0 === e.strict && "bigint" != typeof r) throw TypeError(F + "value");
                    r = 0 === r && 1 / r < 0 ? "-0" : String(r);
                }
                !function(t, e) {
                    var r, n, i;
                    if (!H.test(e)) throw Error(F + "number");
                    for(t.s = "-" == e.charAt(0) ? (e = e.slice(1), -1) : 1, (r = e.indexOf(".")) > -1 && (e = e.replace(".", "")), (n = e.search(/e/i)) > 0 ? (r < 0 && (r = n), r += +e.slice(n + 1), e = e.substring(0, n)) : r < 0 && (r = e.length), i = e.length, n = 0; n < i && "0" == e.charAt(n);)++n;
                    if (n == i) t.c = [
                        t.e = 0
                    ];
                    else {
                        for(; i > 0 && "0" == e.charAt(--i););
                        for(t.e = r - n - 1, t.c = [], r = 0; n <= i;)t.c[r++] = +e.charAt(n++);
                    }
                }(n, r);
            }
            n.constructor = e;
        }
        return e.prototype = z, e.DP = 20, e.RM = 1, e.NE = -7, e.PE = 21, e.strict = !1, e.roundDown = 0, e.roundHalfUp = 1, e.roundHalfEven = 2, e.roundUp = 3, e;
    }();
    function V(t) {
        var e = t.startsWith("-");
        return (t = (t = (t = t.replace("-", "")).replace(/\.0*$/g, "")).replace(/^0+/, "")).includes(".") && (t = t.replace(/0+$/, "")), t.startsWith(".") && (t = "0" + t), (e ? "-" : "") + t;
    }
    function Z(t) {
        if (!t.match(/e/i)) return V(t);
        var e = t.split(/e/i), r = e[0], n = e[1], i = Number(r) < 0, o = (r = V(r = r.replace("-", ""))).split("."), s = o[0], u = o[1], f = void 0 === u ? "" : u;
        if (0 === Number(n)) return (i ? "-" : "") + V(r);
        r.includes(".") || (r += ".");
        var a, c = (r = r.replace(".", "")).length;
        return Number(n) < 0 ? (s.length < Math.abs(Number(n)) && (r = r.padStart(c + Math.abs(Number(n)) - s.length, "0")), a = r.split(""), s.length < Math.abs(Number(n)) ? a = [
            "."
        ].concat(a) : a.splice(a.length - Math.abs(Number(n)), 0, ".")) : (f.length < Math.abs(Number(n)) && (r = r.padEnd(c + Math.abs(Number(n)) - f.length, "0")), a = r.split(""), f.length > Math.abs(Number(n)) && a.splice(a.length - Math.abs(Number(n)), 0, ".")), (i ? "-" : "") + V(a.join(""));
    }
    var J = /*#__PURE__*/ function(t) {
        function e(e) {
            var r;
            return "string" == typeof e && e.startsWith("0x") && (e = S(e)), (r = t.call(this, e) || this).padAndChop = function(t, e, r) {
                return (Array(r).fill(e).join("") + t).slice(-1 * r);
            }, r;
        }
        r(e, t);
        var n = e.prototype;
        return n.toHexString = function() {
            return "0x" + BigInt(this.toString()).toString(16);
        }, n.toNumber = function() {
            return Number(Z(t.prototype.toString.call(this)));
        }, n.toString = function() {
            return 0 === this.toNumber() ? "0" : Z(t.prototype.toString.call(this));
        }, n.toTwos = function(t) {
            var e;
            if (this.gte(0)) {
                var r = this.toNumber().toString(2);
                e = this.padAndChop(r, "0", t || r.length);
            } else if (e = this.plus(Math.pow(2, t)).toNumber().toString(2), Number(e) < 0) throw new Error("Cannot calculate twos complement");
            return Y(Number("0b" + e));
        }, e;
    }(K);
    function Y(t) {
        return new J(t);
    }
    function X(t) {
        var r = e({}, t);
        return Object.keys(t).forEach(function(e) {
            if (t[e]) switch(e){
                case "blockNumber":
                case "chainId":
                case "transactionIndex":
                case "type":
                case "v":
                    r[e] = Number(S(t[e]));
                    break;
                case "from":
                case "to":
                    t[e] && (r[e] = tt(t[e]));
                    break;
                case "value":
                case "gas":
                case "gasPrice":
                case "maxFeePerGas":
                case "maxPriorityFeePerGas":
                case "nonce":
                    r[e] = Y(S(t[e]));
            }
        }), r;
    }
    var Q = function(t, e) {
        if (!e.includes(typeof t)) throw new Error(e.join(" or ") + " required. Received " + typeof t);
    };
    function tt(t) {
        if (Q(t, [
            "string"
        ]), !/^(0x)?[0-9a-f]{40}$/i.test(t)) throw new Error('Invalid Ethereum address "' + t + '"');
        for(var e = t.toLowerCase().replace(/^0x/i, ""), r = new U.Keccak(256).update(e).digest("hex").replace(/^0x/i, ""), n = "0x", i = 0; i < e.length; i++)parseInt(r[i], 16) > 7 ? n += e[i].toUpperCase() : n += e[i];
        if (t.match(/([A-F].*[a-f])|([a-f].*[A-F])/) && n !== t) throw new Error('Invalid Checksum address for "' + t + '"');
        return n;
    }
    function et(t, r) {
        var n = e({}, t);
        return Object.keys(t).forEach(function(e) {
            switch(e){
                case "address":
                    n[e] = tt(t[e]);
                    break;
                case "blockNumber":
                case "logIndex":
                case "transactionIndex":
                    n[e] = Number(S(t[e]));
                    break;
                case "removed":
                    r && delete n[e];
            }
        }), n;
    }
    var rt = {
        __proto__: null,
        default: function(t, e) {
            return e = e || {}, new Promise(function(r, n) {
                var i = new XMLHttpRequest, o = [], s = [], u = {}, f = function() {
                    return {
                        ok: 2 == (i.status / 100 | 0),
                        statusText: i.statusText,
                        status: i.status,
                        url: i.responseURL,
                        text: function() {
                            return Promise.resolve(i.responseText);
                        },
                        json: function() {
                            return Promise.resolve(i.responseText).then(JSON.parse);
                        },
                        blob: function() {
                            return Promise.resolve(new Blob([
                                i.response
                            ]));
                        },
                        clone: f,
                        headers: {
                            keys: function() {
                                return o;
                            },
                            entries: function() {
                                return s;
                            },
                            get: function(t) {
                                return u[t.toLowerCase()];
                            },
                            has: function(t) {
                                return t.toLowerCase() in u;
                            }
                        }
                    };
                };
                for(var a in i.open(e.method || "get", t, !0), i.onload = function() {
                    i.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function(t, e, r) {
                        o.push(e = e.toLowerCase()), s.push([
                            e,
                            r
                        ]), u[e] = u[e] ? u[e] + "," + r : r;
                    }), r(f());
                }, i.onerror = n, i.withCredentials = "include" == e.credentials, e.headers)i.setRequestHeader(a, e.headers[a]);
                i.send(e.body || null);
            });
        }
    }, nt = self.fetch || (self.fetch = rt.default || rt);
    function it(t, e) {
        return {
            jsonrpc: "2.0",
            id: 1,
            method: t,
            params: e
        };
    }
    function ot(t) {
        return !!t.toHexString;
    }
    function st(t) {
        return lt(t) && !(t.length % 2) || ft(t);
    }
    function ut(t) {
        return "number" == typeof t && t == t && t % 1 == 0;
    }
    function ft(t) {
        if (null == t) return !1;
        if (t.constructor === Uint8Array) return !0;
        if ("string" == typeof t) return !1;
        if (!ut(t.length) || t.length < 0) return !1;
        for(var e = 0; e < t.length; e++){
            var r = t[e];
            if (!ut(r) || r < 0 || r >= 256) return !1;
        }
        return !0;
    }
    function at(t, e) {
        if (e || (e = {}), "number" == typeof t) {
            M.checkSafeUint53(t, "invalid arrayify value");
            for(var r = []; t;)r.unshift(255 & t), t = parseInt(String(t / 256));
            return 0 === r.length && r.push(0), new Uint8Array(r);
        }
        if (e.allowMissingPrefix && "string" == typeof t && "0x" !== t.substring(0, 2) && (t = "0x" + t), ot(t) && (t = t.toHexString()), lt(t)) {
            var n = t.substring(2);
            n.length % 2 && ("left" === e.hexPad ? n = "0" + n : "right" === e.hexPad ? n += "0" : M.throwArgumentError("hex data is odd-length", "value", t));
            for(var i = [], o = 0; o < n.length; o += 2)i.push(parseInt(n.substring(o, o + 2), 16));
            return new Uint8Array(i);
        }
        return ft(t) ? new Uint8Array(t) : M.throwArgumentError("invalid arrayify value", "value", t);
    }
    function ct(t) {
        var e = t.map(function(t) {
            return at(t);
        }), r = e.reduce(function(t, e) {
            return t + e.length;
        }, 0), n = new Uint8Array(r);
        return e.reduce(function(t, e) {
            return n.set(e, t), t + e.length;
        }, 0), n;
    }
    function ht(t, e) {
        (t = at(t)).length > e && M.throwArgumentError("value out of range", "value", t);
        var r = new Uint8Array(e);
        return r.set(t, e - t.length), r;
    }
    function lt(t, e) {
        return !("string" != typeof t || !t.match(/^0x[0-9A-Fa-f]*$/) || e && t.length !== 2 + 2 * e);
    }
    var pt = "0123456789abcdef";
    function gt(t, e) {
        if (e || (e = {}), "number" == typeof t) {
            M.checkSafeUint53(t, "invalid hexlify value");
            for(var r = ""; t;)r = pt[15 & t] + r, t = Math.floor(t / 16);
            return r.length ? (r.length % 2 && (r = "0" + r), "0x" + r) : "0x00";
        }
        if ("bigint" == typeof t) return (t = t.toString(16)).length % 2 ? "0x0" + t : "0x" + t;
        if (e.allowMissingPrefix && "string" == typeof t && "0x" !== t.substring(0, 2) && (t = "0x" + t), ot(t)) return t.toHexString();
        if (lt(t)) return t.length % 2 && ("left" === e.hexPad ? t = "0x0" + t.substring(2) : "right" === e.hexPad ? t += "0" : M.throwArgumentError("hex data is odd-length", "value", t)), t.toLowerCase();
        if (ft(t)) {
            for(var n = "0x", i = 0; i < t.length; i++){
                var o = t[i];
                n += pt[(240 & o) >> 4] + pt[15 & o];
            }
            return n;
        }
        return M.throwArgumentError("invalid hexlify value", "value", t);
    }
    function yt(t, e, r) {
        return "string" != typeof t ? t = gt(t) : (!lt(t) || t.length % 2) && M.throwArgumentError("invalid hexData", "value", t), e = 2 + 2 * e, null != r ? "0x" + t.substring(e, 2 + 2 * r) : "0x" + t.substring(e);
    }
    function dt(t) {
        "string" != typeof t && (t = gt(t)), lt(t) || M.throwArgumentError("invalid hex string", "value", t), t = t.substring(2);
        for(var e = 0; e < t.length && "0" === t[e];)e++;
        return "0x" + t.substring(e);
    }
    function mt(t, e) {
        for("string" != typeof t ? t = gt(t) : lt(t) || M.throwArgumentError("invalid hex string", "value", t), t.length > 2 * e + 2 && M.throwError("value out of range", {
            value: t,
            length: e
        }); t.length < 2 * e + 2;)t = "0x0" + t.substring(2);
        return t;
    }
    function wt(t) {
        var r = e({}, t);
        return Object.keys(t).forEach(function(e) {
            switch(e){
                case "gas":
                case "gasPrice":
                case "nonce":
                case "maxFeePerGas":
                case "maxPriorityFeePerGas":
                case "value":
                    var n = t[e];
                    r[e] = n instanceof J ? n.toHexString() : n instanceof K ? "0x" + BigInt(n.toString()).toString(16) : "number" == typeof t[e] ? "0x" + t[e].toString(16) : t[e].toString();
                    break;
                case "data":
                    r[e] = gt(t[e]);
            }
        }), r;
    }
    var vt = {
        1: [
            "eth",
            "0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e"
        ],
        2: [
            "exp"
        ],
        3: [
            "rop",
            "0x112234455c3a32fd11230c42e7bccd4a84e02010"
        ],
        4: [
            "rin",
            "0xe7410170f87102df0055eb195163a03b7f2bff4a"
        ],
        5: [
            "gor",
            "0x112234455c3a32fd11230c42e7bccd4a84e02010"
        ],
        6: [
            "kot"
        ],
        7: [
            "tch"
        ],
        8: [
            "ubq"
        ],
        9: [
            "tubq"
        ],
        10: [
            "oeth"
        ],
        11: [
            "meta"
        ],
        12: [
            "kal"
        ],
        13: [
            "dstg"
        ],
        14: [
            "flr"
        ],
        15: [
            "diode"
        ],
        16: [
            "cflr"
        ],
        17: [
            "tfi"
        ],
        18: [
            "TST"
        ],
        19: [
            "sgb"
        ],
        20: [
            "elaeth"
        ],
        21: [
            "elaetht"
        ],
        22: [
            "eladid"
        ],
        23: [
            "eladidt"
        ],
        24: [
            "dthmainnet"
        ],
        25: [
            "cro"
        ],
        26: [
            "L1test"
        ],
        27: [
            "shib"
        ],
        28: [
            "Boba Rinkeby"
        ],
        29: [
            "L1"
        ],
        30: [
            "rsk"
        ],
        31: [
            "trsk"
        ],
        32: [
            "GooDT"
        ],
        33: [
            "GooD"
        ],
        34: [
            "dth"
        ],
        35: [
            "tbwg"
        ],
        36: [
            "dx"
        ],
        38: [
            "val"
        ],
        40: [
            "Telos EVM"
        ],
        41: [
            "Telos EVM Testnet"
        ],
        42: [
            "kov"
        ],
        43: [
            "pangolin"
        ],
        44: [
            "crab"
        ],
        45: [
            "pangoro"
        ],
        46: [
            "darwinia"
        ],
        50: [
            "xdc"
        ],
        51: [
            "TXDC"
        ],
        52: [
            "cet"
        ],
        53: [
            "tcet"
        ],
        54: [
            "OP"
        ],
        55: [
            "ZYX"
        ],
        56: [
            "bnb"
        ],
        57: [
            "sys"
        ],
        58: [
            "Ontology Mainnet"
        ],
        59: [
            "EOS Mainnet"
        ],
        60: [
            "go"
        ],
        61: [
            "etc"
        ],
        62: [
            "tetc"
        ],
        63: [
            "metc"
        ],
        64: [
            "ellaism"
        ],
        65: [
            "tokt"
        ],
        66: [
            "okt"
        ],
        67: [
            "dbm"
        ],
        68: [
            "SO1"
        ],
        69: [
            "okov"
        ],
        70: [
            "hsc"
        ],
        71: [
            "cfxtest"
        ],
        72: [
            "dxc"
        ],
        74: [
            "idchain"
        ],
        76: [
            "mix"
        ],
        77: [
            "spoa"
        ],
        78: [
            "primuschain"
        ],
        79: [
            "zenith"
        ],
        80: [
            "GeneChain"
        ],
        81: [
            "VIL"
        ],
        82: [
            "Meter"
        ],
        83: [
            "MeterTest"
        ],
        85: [
            "gttest"
        ],
        86: [
            "gt"
        ],
        87: [
            "nnw"
        ],
        88: [
            "tomo"
        ],
        89: [
            "tomot"
        ],
        90: [
            "gar-s0"
        ],
        91: [
            "gar-s1"
        ],
        92: [
            "gar-s2"
        ],
        93: [
            "gar-s3"
        ],
        95: [
            "Kylin Testnet"
        ],
        96: [
            "nsc"
        ],
        97: [
            "bnbt"
        ],
        99: [
            "poa"
        ],
        100: [
            "gno"
        ],
        101: [
            "eti"
        ],
        102: [
            "tw3g"
        ],
        104: [
            "tklc"
        ],
        105: [
            "dw3g"
        ],
        106: [
            "vlx"
        ],
        107: [
            "ntn"
        ],
        108: [
            "TT"
        ],
        110: [
            "xpr"
        ],
        111: [
            "ETL"
        ],
        122: [
            "fuse"
        ],
        123: [
            "spark"
        ],
        124: [
            "dwu"
        ],
        125: [
            "oychain testnet"
        ],
        126: [
            "oychain mainnet"
        ],
        127: [
            "feth"
        ],
        128: [
            "heco"
        ],
        137: [
            "MATIC"
        ],
        141: [
            "OPtest"
        ],
        142: [
            "dax"
        ],
        162: [
            "tpht"
        ],
        163: [
            "pht"
        ],
        168: [
            "aioz"
        ],
        170: [
            "hoosmartchain"
        ],
        172: [
            "resil"
        ],
        180: [
            "ame"
        ],
        186: [
            "Seele"
        ],
        188: [
            "BMC"
        ],
        189: [
            "BMCT"
        ],
        193: [
            "cem"
        ],
        199: [
            "BTT"
        ],
        200: [
            "aox"
        ],
        211: [
            "EDI"
        ],
        218: [
            "SO1-old"
        ],
        222: [
            "ASK"
        ],
        225: [
            "LA"
        ],
        226: [
            "TLA"
        ],
        246: [
            "ewt"
        ],
        250: [
            "ftm"
        ],
        256: [
            "hecot"
        ],
        258: [
            "setm"
        ],
        262: [
            "SUR"
        ],
        269: [
            "hpb"
        ],
        280: [
            "zksync-goerli"
        ],
        288: [
            "Boba"
        ],
        300: [
            "ogc"
        ],
        321: [
            "kcs"
        ],
        322: [
            "kcst"
        ],
        333: [
            "w3q"
        ],
        335: [
            "DFKTEST"
        ],
        336: [
            "sdn"
        ],
        338: [
            "tcro"
        ],
        361: [
            "theta-mainnet"
        ],
        363: [
            "theta-sapphire"
        ],
        364: [
            "theta-amber"
        ],
        365: [
            "theta-testnet"
        ],
        369: [
            "pls"
        ],
        385: [
            "lisinski"
        ],
        416: [
            "SX"
        ],
        420: [
            "ogor"
        ],
        499: [
            "rupx"
        ],
        512: [
            "aac"
        ],
        513: [
            "aact"
        ],
        520: [
            "xt"
        ],
        530: [
            "f(x)Core"
        ],
        534: [
            "CNDL"
        ],
        555: [
            "CLASS"
        ],
        558: [
            "tao"
        ],
        588: [
            "metis-stardust"
        ],
        592: [
            "astr"
        ],
        595: [
            "maca"
        ],
        596: [
            "tkar"
        ],
        597: [
            "taca"
        ],
        600: [
            "mesh-chain-testnet"
        ],
        647: [
            "SX-Testnet"
        ],
        666: [
            "pixie-chain-testnet"
        ],
        686: [
            "kar"
        ],
        700: [
            "SNS"
        ],
        707: [
            "bcs"
        ],
        708: [
            "tbcs"
        ],
        721: [
            "tfeth"
        ],
        776: [
            "opc"
        ],
        777: [
            "cth"
        ],
        787: [
            "aca"
        ],
        788: [
            "taero"
        ],
        803: [
            "haic"
        ],
        808: [
            "PFTEST"
        ],
        820: [
            "clo"
        ],
        821: [
            "tclo"
        ],
        880: [
            "ambros"
        ],
        888: [
            "wan"
        ],
        900: [
            "gar-test-s0"
        ],
        901: [
            "gar-test-s1"
        ],
        902: [
            "gar-test-s2"
        ],
        903: [
            "gar-test-s3"
        ],
        909: [
            "PF"
        ],
        940: [
            "tpls"
        ],
        941: [
            "t2bpls"
        ],
        942: [
            "t3pls"
        ],
        977: [
            "yeti"
        ],
        980: [
            "top_evm"
        ],
        989: [
            "top"
        ],
        998: [
            "ln"
        ],
        999: [
            "twan"
        ],
        1e3: [
            "gton"
        ],
        1001: [
            "Baobab"
        ],
        1007: [
            "tnew"
        ],
        1008: [
            "eun"
        ],
        1010: [
            "EVC"
        ],
        1012: [
            "new"
        ],
        1022: [
            "sku"
        ],
        1023: [
            "tclv"
        ],
        1024: [
            "clv"
        ],
        1028: [
            "tbtt"
        ],
        1030: [
            "cfx"
        ],
        1088: [
            "metis-andromeda"
        ],
        1139: [
            "MATH"
        ],
        1140: [
            "tMATH"
        ],
        1197: [
            "iora"
        ],
        1201: [
            "avis"
        ],
        1202: [
            "wtt"
        ],
        1213: [
            "popcat"
        ],
        1214: [
            "enter"
        ],
        1246: [
            "om"
        ],
        1280: [
            "HO"
        ],
        1284: [
            "mbeam"
        ],
        1285: [
            "mriver"
        ],
        1286: [
            "mrock-old"
        ],
        1287: [
            "mbase"
        ],
        1288: [
            "mrock"
        ],
        1297: [
            "Bobabase"
        ],
        1319: [
            "aitd"
        ],
        1320: [
            "aitdtestnet"
        ],
        1337: [
            "cennz-old"
        ],
        1506: [
            "Sherpax"
        ],
        1507: [
            "Sherpax Testnet"
        ],
        1618: [
            "cate"
        ],
        1620: [
            "ath"
        ],
        1657: [
            "bta"
        ],
        1688: [
            "LUDAN"
        ],
        1818: [
            "cube"
        ],
        1819: [
            "cubet"
        ],
        1856: [
            "tsf"
        ],
        1898: [
            "boya"
        ],
        1984: [
            "euntest"
        ],
        1987: [
            "egem"
        ],
        2001: [
            "milkAda"
        ],
        2008: [
            "cloudwalk_testnet"
        ],
        2009: [
            "cloudwalk_mainnet"
        ],
        2020: [
            "420"
        ],
        2021: [
            "edg"
        ],
        2022: [
            "edgt"
        ],
        2023: [
            "taycan-testnet"
        ],
        2025: [
            "rpg"
        ],
        2100: [
            "eco"
        ],
        2101: [
            "esp"
        ],
        2152: [
            "fra"
        ],
        2153: [
            "findora-testnet"
        ],
        2213: [
            "evanesco"
        ],
        2221: [
            "tkava"
        ],
        2222: [
            "kava"
        ],
        2223: [
            "VChain"
        ],
        2559: [
            "ktoc"
        ],
        2569: [
            "tpc"
        ],
        2612: [
            "EZChain"
        ],
        2613: [
            "Fuji-EZChain"
        ],
        3e3: [
            "cennz-r"
        ],
        3001: [
            "cennz-n"
        ],
        3331: [
            "zcrbeach"
        ],
        3333: [
            "w3q-t"
        ],
        3334: [
            "w3q-g"
        ],
        3400: [
            "prb"
        ],
        3500: [
            "prbtestnet"
        ],
        3501: [
            "jfin"
        ],
        3690: [
            "btx"
        ],
        3737: [
            "csb"
        ],
        3966: [
            "dyno"
        ],
        3967: [
            "tdyno"
        ],
        3999: [
            "ycc"
        ],
        4002: [
            "tftm"
        ],
        4051: [
            "Bobaopera Testnet"
        ],
        4102: [
            "aioz-testnet"
        ],
        4181: [
            "PHI"
        ],
        4689: [
            "iotex-mainnet"
        ],
        4690: [
            "iotex-testnet"
        ],
        4918: [
            "txvm"
        ],
        4919: [
            "xvm"
        ],
        5177: [
            "tlc"
        ],
        5197: [
            "es"
        ],
        5315: [
            "UZMI"
        ],
        5551: [
            "Nahmii"
        ],
        5553: [
            "Nahmii testnet"
        ],
        5700: [
            "tsys"
        ],
        5777: [
            "dgcc"
        ],
        5851: [
            "Ontology Testnet"
        ],
        5869: [
            "rbd"
        ],
        6626: [
            "pixie-chain"
        ],
        6969: [
            "tombchain"
        ],
        7027: [
            "ELLA"
        ],
        7341: [
            "shyft"
        ],
        7777: [
            "Rise of the Warbots Testnet"
        ],
        7878: [
            "tscas"
        ],
        8e3: [
            "teleport"
        ],
        8001: [
            "teleport-testnet"
        ],
        8029: [
            "mdgl"
        ],
        8080: [
            "GeneChainAdn"
        ],
        8217: [
            "Cypress"
        ],
        8285: [
            "Kortho"
        ],
        8723: [
            "olo"
        ],
        8724: [
            "tolo"
        ],
        8888: [
            "ambrostestnet"
        ],
        8898: [
            "mmt"
        ],
        8995: [
            "berg"
        ],
        9e3: [
            "evmos-testnet"
        ],
        9001: [
            "evmos"
        ],
        9012: [
            "brb"
        ],
        9100: [
            "GENEC"
        ],
        9527: [
            "trpg"
        ],
        9999: [
            "myn"
        ],
        1e4: [
            "smartbch"
        ],
        10001: [
            "smartbchtest"
        ],
        10101: [
            "GEN"
        ],
        10823: [
            "CCP"
        ],
        10946: [
            "quadrans"
        ],
        10947: [
            "quadranstestnet"
        ],
        11111: [
            "WAGMI"
        ],
        11437: [
            "shyftt"
        ],
        12051: [
            "tZERO"
        ],
        12052: [
            "ZERO"
        ],
        13381: [
            "Phoenix"
        ],
        16e3: [
            "mtt"
        ],
        16001: [
            "mtttest"
        ],
        16888: [
            "tivar"
        ],
        19845: [
            "btcix"
        ],
        21337: [
            "cennz-a"
        ],
        21816: [
            "omc"
        ],
        22023: [
            "SFL"
        ],
        24484: [
            "web"
        ],
        24734: [
            "mintme"
        ],
        26863: [
            "OAC"
        ],
        30067: [
            "Piece"
        ],
        31102: [
            "esn"
        ],
        31337: [
            "got"
        ],
        32520: [
            "Brise"
        ],
        32659: [
            "fsn"
        ],
        35441: [
            "q"
        ],
        35443: [
            "q-testnet"
        ],
        39797: [
            "nrg"
        ],
        42069: [
            "PC"
        ],
        42161: [
            "arb1"
        ],
        42170: [
            "arb-nova"
        ],
        42220: [
            "CELO"
        ],
        42261: [
            "emerald"
        ],
        42262: [
            "oasis"
        ],
        43110: [
            "avaeth"
        ],
        43113: [
            "Fuji"
        ],
        43114: [
            "avax"
        ],
        44787: [
            "ALFA"
        ],
        45e3: [
            "Autobahn Network"
        ],
        47805: [
            "REI"
        ],
        49797: [
            "tnrg"
        ],
        50021: [
            "tgton"
        ],
        53935: [
            "DFK"
        ],
        55555: [
            "reichain"
        ],
        55556: [
            "trei"
        ],
        6e4: [
            "TKM-test0"
        ],
        60001: [
            "TKM-test1"
        ],
        60002: [
            "TKM-test2"
        ],
        60103: [
            "TKM-test103"
        ],
        62320: [
            "BKLV"
        ],
        62621: [
            "mtv"
        ],
        63e3: [
            "ecs"
        ],
        63001: [
            "ecs-testnet"
        ],
        69420: [
            "cndr"
        ],
        7e4: [
            "TKM0"
        ],
        70001: [
            "TKM1"
        ],
        70002: [
            "TKM2"
        ],
        70103: [
            "TKM103"
        ],
        71393: [
            "ckb"
        ],
        71401: [
            "gw-testnet-v1"
        ],
        71402: [
            "gw-mainnet-v1"
        ],
        73799: [
            "vt"
        ],
        73927: [
            "mvm"
        ],
        75e3: [
            "resin"
        ],
        78110: [
            "firenze"
        ],
        80001: [
            "maticmum"
        ],
        88888: [
            "ivar"
        ],
        99998: [
            "usctest"
        ],
        99999: [
            "usc"
        ],
        1e5: [
            "qkc-r"
        ],
        100001: [
            "qkc-s0"
        ],
        100002: [
            "qkc-s1"
        ],
        100003: [
            "qkc-s2"
        ],
        100004: [
            "qkc-s3"
        ],
        100005: [
            "qkc-s4"
        ],
        100006: [
            "qkc-s5"
        ],
        100007: [
            "qkc-s6"
        ],
        100008: [
            "qkc-s7"
        ],
        103090: [
            "CRFI"
        ],
        108801: [
            "bro"
        ],
        11e4: [
            "qkc-d-r"
        ],
        110001: [
            "qkc-d-s0"
        ],
        110002: [
            "qkc-d-s1"
        ],
        110003: [
            "qkc-d-s2"
        ],
        110004: [
            "qkc-d-s3"
        ],
        110005: [
            "qkc-d-s4"
        ],
        110006: [
            "qkc-d-s5"
        ],
        110007: [
            "qkc-d-s6"
        ],
        110008: [
            "qkc-d-s7"
        ],
        131419: [
            "ETND"
        ],
        200101: [
            "milkTAda"
        ],
        200625: [
            "aka"
        ],
        201018: [
            "alaya"
        ],
        201030: [
            "alayadev"
        ],
        210425: [
            "platon"
        ],
        234666: [
            "hym"
        ],
        246529: [
            "ats"
        ],
        246785: [
            "atstau"
        ],
        281121: [
            "SoChain"
        ],
        333888: [
            "sparta"
        ],
        333999: [
            "olympus"
        ],
        421611: [
            "arb-rinkeby"
        ],
        421613: [
            "arb-goerli"
        ],
        432201: [
            "Dexalot"
        ],
        444900: [
            "wlkt"
        ],
        474142: [
            "oc"
        ],
        512512: [
            "cmp"
        ],
        666666: [
            "vpioneer"
        ],
        846e3: [
            "bloqs4good"
        ],
        888888: [
            "vision"
        ],
        955305: [
            "elv"
        ],
        1313114: [
            "etho"
        ],
        1313500: [
            "xero"
        ],
        1337702: [
            "kintsugi"
        ],
        1337802: [
            "kiln"
        ],
        2203181: [
            "platondev"
        ],
        2206132: [
            "platondev2"
        ],
        7762959: [
            "music"
        ],
        11155111: [
            "sep"
        ],
        13371337: [
            "tpep"
        ],
        18289463: [
            "ilt"
        ],
        20180430: [
            "spectrum"
        ],
        20181205: [
            "qki"
        ],
        28945486: [
            "auxi"
        ],
        35855456: [
            "JOYS"
        ],
        61717561: [
            "aqua"
        ],
        99415706: [
            "TOYS"
        ],
        192837465: [
            "GTH"
        ],
        245022926: [
            "neonevm-devnet"
        ],
        245022934: [
            "neonevm-mainnet"
        ],
        245022940: [
            "neonevm-testnet"
        ],
        311752642: [
            "oneledger"
        ],
        356256156: [
            "tGTH"
        ],
        486217935: [
            "dGTH"
        ],
        1122334455: [
            "ipos"
        ],
        1313161554: [
            "aurora"
        ],
        1313161555: [
            "aurora-testnet"
        ],
        1313161556: [
            "aurora-betanet"
        ],
        16666e5: [
            "hmy-s0"
        ],
        1666600001: [
            "hmy-s1"
        ],
        1666600002: [
            "hmy-s2"
        ],
        1666600003: [
            "hmy-s3"
        ],
        16667e5: [
            "hmy-b-s0"
        ],
        1666700001: [
            "hmy-b-s1"
        ],
        1666700002: [
            "hmy-b-s2"
        ],
        1666700003: [
            "hmy-b-s3"
        ],
        2021121117: [
            "hop"
        ],
        3125659152: [
            "pirl"
        ],
        4216137055: [
            "frankenstein"
        ],
        11297108099: [
            "tpalm"
        ],
        11297108109: [
            "palm"
        ],
        197710212030: [
            "ntt"
        ],
        197710212031: [
            "ntt-haradev"
        ],
        6022140761023: [
            "mole"
        ],
        868455272153094: [
            "gw-testnet-v1-deprecated"
        ]
    };
    function bt(t) {
        return "number" == typeof t ? Y(t).toHexString() : t;
    }
    var Et = /*#__PURE__*/ function() {
        function t(t) {
            var e = this;
            this._rpcUrls = [], this._post = function(t) {
                return function(t, e) {
                    return nt(t, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(e)
                    }).then(function(t) {
                        try {
                            return Promise.resolve(t.text()).then(function(t) {
                                try {
                                    return JSON.parse(t);
                                } catch (e) {
                                    throw new Error('Invalid JSON RPC response: "' + t + '"');
                                }
                            });
                        } catch (t) {
                            return Promise.reject(t);
                        }
                    }).then(function(t) {
                        if (!(null == t ? void 0 : t.result)) throw new Error("Invalid JSON RPC response: " + JSON.stringify(t));
                        return t.result;
                    });
                }(e.selectRpcUrl(), t);
            }, this._rpcUrls = t;
        }
        var r = t.prototype;
        return r.getNetwork = function() {
            try {
                return Promise.resolve(this.post(it("eth_chainId", []))).then(function(t) {
                    var e = S(t), r = vt[e];
                    return {
                        chainId: Number(e),
                        name: r[0] || "unknown",
                        ensAddress: r[1] || null
                    };
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getBlockNumber = function() {
            try {
                return Promise.resolve(this.post(it("eth_blockNumber", []))).then(function(t) {
                    return Number(S(t));
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getTransaction = function(t) {
            try {
                return Promise.resolve(Promise.all([
                    this.post(it("eth_getTransactionByHash", [
                        t
                    ])),
                    this.getBlock("latest")
                ])).then(function(t) {
                    var e = t[1], r = X(t[0]);
                    return r.confirmations = e.number - r.blockNumber + 1, r;
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getTransactionReceipt = function(t) {
            try {
                return Promise.resolve(Promise.all([
                    this.post(it("eth_getTransactionReceipt", [
                        t
                    ])),
                    this.getBlock("latest")
                ])).then(function(t) {
                    var r = t[1], n = function(t) {
                        var r = e({}, X(t));
                        return Object.keys(t).forEach(function(e) {
                            if (t[e]) switch(e){
                                case "status":
                                    r[e] = Number(S(t[e]));
                                    break;
                                case "contractAddress":
                                    t[e] && (r[e] = tt(t[e]));
                                    break;
                                case "cumulativeGasUsed":
                                case "effectiveGasPrice":
                                case "gasUsed":
                                    r[e] = Y(S(t[e]));
                                    break;
                                case "logs":
                                    t[e].forEach(function(t, n) {
                                        r[e][n] = et(t, !0);
                                    });
                            }
                        }), r.byzantium = r.blockNumber >= 437e4, r;
                    }(t[0]);
                    return n.confirmations = r.number - n.blockNumber + 1, n;
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getTransactionCount = function(t, e) {
            void 0 === e && (e = "latest");
            try {
                return e = bt(e), Promise.resolve(this.post(it("eth_getTransactionCount", [
                    t,
                    e
                ]))).then(function(t) {
                    return Number(S(t));
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getBlock = function(t, r) {
            void 0 === t && (t = "latest"), void 0 === r && (r = !1);
            try {
                var n = "Number";
                return "string" == typeof t && 66 === t.length ? n = "Hash" : t = bt(t), Promise.resolve(this.post(it("eth_getBlockBy" + n, [
                    t,
                    r
                ]))).then(function(t) {
                    return function(t, r) {
                        var n = e({}, t);
                        return Object.keys(t).forEach(function(e) {
                            if (t[e]) switch(e){
                                case "difficulty":
                                case "totalDifficulty":
                                case "gasLimit":
                                case "gasUsed":
                                case "size":
                                case "timestamp":
                                case "baseFeePerGas":
                                    n[e] = Y(S(t[e]));
                                    break;
                                case "number":
                                    n[e] = Number(S(t[e]));
                                    break;
                                case "miner":
                                    n[e] = tt(t[e]);
                            }
                        }), r && t.transactions.forEach(function(t, e) {
                            n.transactions[e] = X(t);
                        }), n;
                    }(t, r);
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getGasPrice = function() {
            try {
                return Promise.resolve(this.post(it("eth_gasPrice", []))).then(function(t) {
                    return Y(S(t));
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getBalance = function(t, e) {
            void 0 === e && (e = "latest");
            try {
                return e = bt(e), Promise.resolve(this.post(it("eth_getBalance", [
                    t,
                    e
                ]))).then(function(t) {
                    return Y(S(t));
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getCode = function(t, e) {
            void 0 === e && (e = "latest");
            try {
                return e = bt(e), Promise.resolve(this.post(it("eth_getCode", [
                    t,
                    e
                ])));
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.estimateGas = function(t) {
            try {
                var e = wt(t);
                return Promise.resolve(this.post(it("eth_estimateGas", [
                    e
                ]))).then(function(t) {
                    return Y(S(t));
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.getLogs = function(t) {
            try {
                var e = t;
                return e.fromBlock && (e.fromBlock = bt(e.fromBlock)), e.toBlock && (e.toBlock = bt(e.toBlock)), Promise.resolve(this.post(it("eth_getLogs", [
                    t
                ]))).then(function(t) {
                    return t.map(function(t) {
                        return et(t, !1);
                    });
                });
            } catch (t) {
                return Promise.reject(t);
            }
        }, r.call = function(t, e) {
            void 0 === e && (e = "latest");
            try {
                t.gasPrice && (t.maxPriorityFeePerGas || t.maxFeePerGas) && M.throwError('Cannot specify both "gasPrice" and ("maxPriorityFeePerGas" or "maxFeePerGas")', {
                    gasPrice: t.gasPrice,
                    maxFeePerGas: t.maxFeePerGas,
                    maxPriorityFeePerGas: t.maxPriorityFeePerGas
                }), t.maxFeePerGas && t.maxPriorityFeePerGas && M.throwError('Cannot specify both "maxFeePerGas" and "maxPriorityFeePerGas"', {
                    maxFeePerGas: t.maxFeePerGas,
                    maxPriorityFeePerGas: t.maxPriorityFeePerGas
                }), e = bt(e);
                var r = wt(t);
                return Promise.resolve(this.post(it("eth_call", [
                    r,
                    e
                ])));
            } catch (t) {
                return Promise.reject(t);
            }
        }, t;
    }(), Bt = /*#__PURE__*/ function(t) {
        function e(e, r) {
            var n;
            return void 0 === r && (r = {}), Array.isArray(e) || M.throwError("Array required", {
                rpcUrls: e
            }), e.length <= 1 && M.throwError("More than one rpcUrl is required", {
                rpcUrls: e
            }), (n = t.call(this, e) || this).rpcUrlCounter = 0, n.timeoutDuration = void 0, n.post = function(t) {
                var e = n.rpcUrlCounter;
                return function r() {
                    var i, o, s = n.selectRpcUrl();
                    return (i = n._post(t), o = n.timeoutDuration, Promise.race([
                        i,
                        new Promise(function(t, e) {
                            return setTimeout(function() {
                                return e("Promise timed out");
                            }, o);
                        })
                    ])).catch(function(t) {
                        if (s === n.selectRpcUrl() && (n.rpcUrlCounter = (n.rpcUrlCounter + 1) % n._rpcUrls.length), n.rpcUrlCounter === e) throw t;
                        return r();
                    });
                }();
            }, n.timeoutDuration = r.timeoutDuration || 8e3, n;
        }
        return r(e, t), e.prototype.selectRpcUrl = function() {
            return this._rpcUrls[this.rpcUrlCounter];
        }, e;
    }(Et), At = /*#__PURE__*/ function(t) {
        r(n, t);
        var e = n.prototype;
        function n(e) {
            return void 0 === e && (e = "https://free-eth-node.com/api/eth"), t.call(this, [
                e
            ]) || this;
        }
        return e.selectRpcUrl = function() {
            return this._rpcUrls[0];
        }, e.post = function(t) {
            return this._post(t);
        }, n;
    }(Et);
    function xt(t) {
        var e;
        return e = "string" == typeof t ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.replace(/^0x/, ""), "hex") : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Buffer"].from(t), "0x" + new U.Keccak(256).update(e).digest("hex");
    }
    const It = BigInt(0), Pt = BigInt(1), Ut = BigInt(2), St = BigInt(3), kt = BigInt(8), Tt = Ut ** BigInt(256), Rt = {
        a: It,
        b: BigInt(7),
        P: Tt - Ut ** BigInt(32) - BigInt(977),
        n: Tt - BigInt("432420386565659656852420866394968145599"),
        h: Pt,
        Gx: BigInt("55066263022277343669578718895168534326250603453777594175500187360389116729240"),
        Gy: BigInt("32670510020758816978083085130507043184471273380659243275938904335757337482424"),
        beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee")
    };
    function _t(t) {
        const { a: e, b: r } = Rt, n = Jt(t * t), i = Jt(n * t);
        return Jt(i + e * t + r);
    }
    const Ot = Rt.a === It;
    class Ct {
        constructor(t, e, r){
            this.x = t, this.y = e, this.z = r;
        }
        static fromAffine(t) {
            if (!(t instanceof Mt)) throw new TypeError("JacobianPoint#fromAffine: expected Point");
            return new Ct(t.x, t.y, Pt);
        }
        static toAffineBatch(t) {
            const e = function(t, e = Rt.P) {
                const r = new Array(t.length), n = t.reduce((t, n, i)=>n === It ? t : (r[i] = t, Jt(t * n, e)), Pt), i = Xt(n, e);
                return t.reduceRight((t, n, i)=>n === It ? t : (r[i] = Jt(t * r[i], e), Jt(t * n, e)), i), r;
            }(t.map((t)=>t.z));
            return t.map((t, r)=>t.toAffine(e[r]));
        }
        static normalizeZ(t) {
            return Ct.toAffineBatch(t).map(Ct.fromAffine);
        }
        equals(t) {
            if (!(t instanceof Ct)) throw new TypeError("JacobianPoint expected");
            const { x: e, y: r, z: n } = this, { x: i, y: o, z: s } = t, u = Jt(n ** Ut), f = Jt(s ** Ut), a = Jt(e * f), c = Jt(i * u), h = Jt(Jt(r * s) * f), l = Jt(Jt(o * n) * u);
            return a === c && h === l;
        }
        negate() {
            return new Ct(this.x, Jt(-this.y), this.z);
        }
        double() {
            const { x: t, y: e, z: r } = this, n = Jt(t ** Ut), i = Jt(e ** Ut), o = Jt(i ** Ut), s = Jt(Ut * (Jt((t + i) ** Ut) - n - o)), u = Jt(St * n), f = Jt(u ** Ut), a = Jt(f - Ut * s), c = Jt(u * (s - a) - kt * o), h = Jt(Ut * e * r);
            return new Ct(a, c, h);
        }
        add(t) {
            if (!(t instanceof Ct)) throw new TypeError("JacobianPoint expected");
            const { x: e, y: r, z: n } = this, { x: i, y: o, z: s } = t;
            if (i === It || o === It) return this;
            if (e === It || r === It) return t;
            const u = Jt(n ** Ut), f = Jt(s ** Ut), a = Jt(e * f), c = Jt(i * u), h = Jt(Jt(r * s) * f), l = Jt(Jt(o * n) * u), p = Jt(c - a), g = Jt(l - h);
            if (p === It) return g === It ? this.double() : Ct.ZERO;
            const y = Jt(p ** Ut), d = Jt(p * y), m = Jt(a * y), w = Jt(g ** Ut - d - Ut * m), v = Jt(g * (m - w) - h * d), b = Jt(n * s * p);
            return new Ct(w, v, b);
        }
        subtract(t) {
            return this.add(t.negate());
        }
        multiplyUnsafe(t) {
            let e = Zt(t);
            const r = Ct.ZERO;
            if (e === It) return r;
            if (e === Pt) return this;
            if (!Ot) {
                let t = r, n = this;
                for(; e > It;)e & Pt && (t = t.add(n)), n = n.double(), e >>= Pt;
                return t;
            }
            let { k1neg: n, k1: i, k2neg: o, k2: s } = ee(e), u = r, f = r, a = this;
            for(; i > It || s > It;)i & Pt && (u = u.add(a)), s & Pt && (f = f.add(a)), a = a.double(), i >>= Pt, s >>= Pt;
            return n && (u = u.negate()), o && (f = f.negate()), f = new Ct(Jt(f.x * Rt.beta), f.y, f.z), u.add(f);
        }
        precomputeWindow(t) {
            const e = Ot ? 128 / t + 1 : 256 / t + 1, r = [];
            let n = this, i = n;
            for(let o = 0; o < e; o++){
                i = n, r.push(i);
                for(let e = 1; e < 2 ** (t - 1); e++)i = i.add(n), r.push(i);
                n = i.double();
            }
            return r;
        }
        wNAF(t, e) {
            !e && this.equals(Ct.BASE) && (e = Mt.BASE);
            const r = e && e._WINDOW_SIZE || 1;
            if (256 % r) throw new Error("Point#wNAF: Invalid precomputation window, must be power of 2");
            let n = e && Lt.get(e);
            n || (n = this.precomputeWindow(r), e && 1 !== r && (n = Ct.normalizeZ(n), Lt.set(e, n)));
            let i = Ct.ZERO, o = Ct.ZERO;
            const s = 1 + (Ot ? 128 / r : 256 / r), u = 2 ** (r - 1), f = BigInt(2 ** r - 1), a = 2 ** r, c = BigInt(r);
            for(let e = 0; e < s; e++){
                const r = e * u;
                let s = Number(t & f);
                if (t >>= c, s > u && (s -= a, t += Pt), 0 === s) {
                    let t = n[r];
                    e % 2 && (t = t.negate()), o = o.add(t);
                } else {
                    let t = n[r + Math.abs(s) - 1];
                    s < 0 && (t = t.negate()), i = i.add(t);
                }
            }
            return {
                p: i,
                f: o
            };
        }
        multiply(t, e) {
            let r, n, i = Zt(t);
            if (Ot) {
                const { k1neg: t, k1: o, k2neg: s, k2: u } = ee(i);
                let { p: f, f: a } = this.wNAF(o, e), { p: c, f: h } = this.wNAF(u, e);
                t && (f = f.negate()), s && (c = c.negate()), c = new Ct(Jt(c.x * Rt.beta), c.y, c.z), r = f.add(c), n = a.add(h);
            } else {
                const { p: t, f: o } = this.wNAF(i, e);
                r = t, n = o;
            }
            return Ct.normalizeZ([
                r,
                n
            ])[0];
        }
        toAffine(t = Xt(this.z)) {
            const { x: e, y: r, z: n } = this, i = t, o = Jt(i * i), s = Jt(o * i), u = Jt(e * o), f = Jt(r * s);
            if (Jt(n * i) !== Pt) throw new Error("invZ was invalid");
            return new Mt(u, f);
        }
    }
    Ct.BASE = new Ct(Rt.Gx, Rt.Gy, Pt), Ct.ZERO = new Ct(It, Pt, It);
    const Lt = new WeakMap;
    class Mt {
        constructor(t, e){
            this.x = t, this.y = e;
        }
        _setWindowSize(t) {
            this._WINDOW_SIZE = t, Lt.delete(this);
        }
        static fromCompressedHex(t) {
            const e = 32 === t.length, r = Kt(e ? t : t.subarray(1));
            if (!ne(r)) throw new Error("Point is not on curve");
            let n = function(t) {
                const { P: e } = Rt, r = BigInt(6), n = BigInt(11), i = BigInt(22), o = BigInt(23), s = BigInt(44), u = BigInt(88), f = t * t * t % e, a = f * f * t % e, c = Yt(a, St) * a % e, h = Yt(c, St) * a % e, l = Yt(h, Ut) * f % e, p = Yt(l, n) * l % e, g = Yt(p, i) * p % e, y = Yt(g, s) * g % e, d = Yt(y, u) * y % e, m = Yt(d, s) * g % e, w = Yt(m, St) * a % e, v = Yt(w, o) * p % e, b = Yt(v, r) * f % e;
                return Yt(b, Ut);
            }(_t(r));
            const i = (n & Pt) === Pt;
            e ? i && (n = Jt(-n)) : 1 == (1 & t[0]) !== i && (n = Jt(-n));
            const o = new Mt(r, n);
            return o.assertValidity(), o;
        }
        static fromUncompressedHex(t) {
            const e = Kt(t.subarray(1, 33)), r = Kt(t.subarray(33, 65)), n = new Mt(e, r);
            return n.assertValidity(), n;
        }
        static fromHex(t) {
            const e = Vt(t), r = e.length, n = e[0];
            if (32 === r || 33 === r && (2 === n || 3 === n)) return this.fromCompressedHex(e);
            if (65 === r && 4 === n) return this.fromUncompressedHex(e);
            throw new Error(`Point.fromHex: received invalid point. Expected 32-33 compressed bytes or 65 uncompressed bytes, not ${r}`);
        }
        static fromPrivateKey(t) {
            return Mt.BASE.multiply(function(t) {
                let e;
                if ("bigint" == typeof t) e = t;
                else if ("number" == typeof t && Number.isSafeInteger(t) && t > 0) e = BigInt(t);
                else if ("string" == typeof t) {
                    if (64 !== t.length) throw new Error("Expected 32 bytes of private key");
                    e = Gt(t);
                } else {
                    if (!$t(t)) throw new TypeError("Expected valid private key");
                    if (32 !== t.length) throw new Error("Expected 32 bytes of private key");
                    e = Kt(t);
                }
                if (!re(e)) throw new Error("Expected private key: 0 < key < n");
                return e;
            }(t));
        }
        static fromSignature(t, e, r) {
            const n = function(t) {
                const { n: e } = Rt, r = 8 * t.length - 256;
                let n = Kt(t);
                return r > 0 && (n >>= BigInt(r)), n >= e && (n -= e), n;
            }(t = Vt(t)), { r: i, s: o } = function(t) {
                if (t instanceof Ft) return t.assertValidity(), t;
                try {
                    return Ft.fromDER(t);
                } catch (e) {
                    return Ft.fromCompact(t);
                }
            }(e);
            if (0 !== r && 1 !== r) throw new Error("Cannot recover signature: invalid recovery bit");
            if (n === It) throw new Error("Cannot recover signature: msgHash cannot be 0");
            const s = Mt.fromHex((1 & r ? "03" : "02") + Dt(i)), { n: u } = Rt, f = Xt(i, u), a = Jt(-n * f, u), c = Jt(o * f, u), h = Mt.BASE.multiplyAndAddUnsafe(s, a, c);
            if (!h) throw new Error("Cannot recover signature: point at infinify");
            return h.assertValidity(), h;
        }
        toRawBytes(t = !1) {
            return Wt(this.toHex(t));
        }
        toHex(t = !1) {
            const e = Dt(this.x);
            return t ? `${this.y & Pt ? "03" : "02"}${e}` : `04${e}${Dt(this.y)}`;
        }
        toHexX() {
            return this.toHex(!0).slice(2);
        }
        toRawX() {
            return this.toRawBytes(!0).slice(1);
        }
        assertValidity() {
            const t = "Point is not on elliptic curve", { x: e, y: r } = this;
            if (!ne(e) || !ne(r)) throw new Error(t);
            const n = Jt(r * r);
            if (Jt(n - _t(e)) !== It) throw new Error(t);
        }
        equals(t) {
            return this.x === t.x && this.y === t.y;
        }
        negate() {
            return new Mt(this.x, Jt(-this.y));
        }
        double() {
            return Ct.fromAffine(this).double().toAffine();
        }
        add(t) {
            return Ct.fromAffine(this).add(Ct.fromAffine(t)).toAffine();
        }
        subtract(t) {
            return this.add(t.negate());
        }
        multiply(t) {
            return Ct.fromAffine(this).multiply(t, this).toAffine();
        }
        multiplyAndAddUnsafe(t, e, r) {
            const n = Ct.fromAffine(this).multiply(e), i = Ct.fromAffine(t).multiplyUnsafe(r), o = n.add(i);
            return o.equals(Ct.ZERO) ? void 0 : o.toAffine();
        }
    }
    function Nt(t) {
        return Number.parseInt(t[0], 16) >= 8 ? "00" + t : t;
    }
    function jt(t) {
        if (t.length < 2 || 2 !== t[0]) throw new Error(`Invalid signature integer tag: ${zt(t)}`);
        const e = t[1], r = t.subarray(2, e + 2);
        if (!e || r.length !== e) throw new Error("Invalid signature integer: wrong length");
        if (0 === r[0] && r[1] <= 127) throw new Error("Invalid signature integer: trailing length");
        return {
            data: Kt(r),
            left: t.subarray(e + 2)
        };
    }
    Mt.BASE = new Mt(Rt.Gx, Rt.Gy), Mt.ZERO = new Mt(It, It);
    class Ft {
        constructor(t, e){
            this.r = t, this.s = e, this.assertValidity();
        }
        static fromCompact(t) {
            const e = $t(t), r = "Signature.fromCompact";
            if ("string" != typeof t && !e) throw new TypeError(`${r}: Expected string or Uint8Array`);
            const n = e ? zt(t) : t;
            if (128 !== n.length) throw new Error(`${r}: Expected 64-byte hex`);
            return new Ft(Gt(n.slice(0, 64)), Gt(n.slice(64, 128)));
        }
        static fromDER(t) {
            const e = $t(t);
            if ("string" != typeof t && !e) throw new TypeError("Signature.fromDER: Expected string or Uint8Array");
            const { r: r, s: n } = function(t) {
                if (t.length < 2 || 48 != t[0]) throw new Error(`Invalid signature tag: ${zt(t)}`);
                if (t[1] !== t.length - 2) throw new Error("Invalid signature: incorrect length");
                const { data: e, left: r } = jt(t.subarray(2)), { data: n, left: i } = jt(r);
                if (i.length) throw new Error(`Invalid signature: left bytes after parsing: ${zt(i)}`);
                return {
                    r: e,
                    s: n
                };
            }(e ? t : Wt(t));
            return new Ft(r, n);
        }
        static fromHex(t) {
            return this.fromDER(t);
        }
        assertValidity() {
            const { r: t, s: e } = this;
            if (!re(t)) throw new Error("Invalid Signature: r must be 0 < r < n");
            if (!re(e)) throw new Error("Invalid Signature: s must be 0 < s < n");
        }
        hasHighS() {
            return this.s > Rt.n >> Pt;
        }
        normalizeS() {
            return this.hasHighS() ? new Ft(this.r, Rt.n - this.s) : this;
        }
        toDERRawBytes(t = !1) {
            return Wt(this.toDERHex(t));
        }
        toDERHex(t = !1) {
            const e = Nt(Ht(this.s));
            if (t) return e;
            const r = Nt(Ht(this.r)), n = Ht(r.length / 2), i = Ht(e.length / 2);
            return `30${Ht(r.length / 2 + e.length / 2 + 4)}02${n}${r}02${i}${e}`;
        }
        toRawBytes() {
            return this.toDERRawBytes();
        }
        toHex() {
            return this.toDERHex();
        }
        toCompactRawBytes() {
            return Wt(this.toCompactHex());
        }
        toCompactHex() {
            return Dt(this.r) + Dt(this.s);
        }
    }
    function $t(t) {
        return t instanceof Uint8Array;
    }
    const qt = Array.from({
        length: 256
    }, (t, e)=>e.toString(16).padStart(2, "0"));
    function zt(t) {
        if (!(t instanceof Uint8Array)) throw new Error("Expected Uint8Array");
        let e = "";
        for(let r = 0; r < t.length; r++)e += qt[t[r]];
        return e;
    }
    function Dt(t) {
        if (t > Tt) throw new Error("Expected number < 2^256");
        return t.toString(16).padStart(64, "0");
    }
    function Ht(t) {
        const e = t.toString(16);
        return 1 & e.length ? `0${e}` : e;
    }
    function Gt(t) {
        if ("string" != typeof t) throw new TypeError("hexToNumber: expected string, got " + typeof t);
        return BigInt(`0x${t}`);
    }
    function Wt(t) {
        if ("string" != typeof t) throw new TypeError("hexToBytes: expected string, got " + typeof t);
        if (t.length % 2) throw new Error("hexToBytes: received invalid unpadded hex" + t.length);
        const e = new Uint8Array(t.length / 2);
        for(let r = 0; r < e.length; r++){
            const n = 2 * r, i = t.slice(n, n + 2), o = Number.parseInt(i, 16);
            if (Number.isNaN(o) || o < 0) throw new Error("Invalid byte sequence");
            e[r] = o;
        }
        return e;
    }
    function Kt(t) {
        return Gt(zt(t));
    }
    function Vt(t) {
        return t instanceof Uint8Array ? Uint8Array.from(t) : Wt(t);
    }
    function Zt(t) {
        if ("number" == typeof t && Number.isSafeInteger(t) && t > 0) return BigInt(t);
        if ("bigint" == typeof t && re(t)) return t;
        throw new TypeError("Expected valid private scalar: 0 < scalar < curve.n");
    }
    function Jt(t, e = Rt.P) {
        const r = t % e;
        return r >= It ? r : e + r;
    }
    function Yt(t, e) {
        const { P: r } = Rt;
        let n = t;
        for(; e-- > It;)n *= n, n %= r;
        return n;
    }
    function Xt(t, e = Rt.P) {
        if (t === It || e <= It) throw new Error(`invert: expected positive integers, got n=${t} mod=${e}`);
        let r = Jt(t, e), n = e, i = It, o = Pt;
        for(; r !== It;){
            const t = n % r, e = i - o * (n / r);
            n = r, r = t, i = o, o = e;
        }
        if (n !== Pt) throw new Error("invert: does not exist");
        return Jt(i, e);
    }
    const Qt = (t, e)=>(t + e / Ut) / e, te = Ut ** BigInt(128);
    function ee(t) {
        const { n: e } = Rt, r = BigInt("0x3086d221a7d46bcde86c90e49284eb15"), n = -Pt * BigInt("0xe4437ed6010e88286f547fa90abfe4c3"), i = BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8"), o = r, s = Qt(o * t, e), u = Qt(-n * t, e);
        let f = Jt(t - s * r - u * i, e), a = Jt(-s * n - u * o, e);
        const c = f > te, h = a > te;
        if (c && (f = e - f), h && (a = e - a), f > te || a > te) throw new Error("splitScalarEndo: Endomorphism failed, k=" + t);
        return {
            k1neg: c,
            k1: f,
            k2neg: h,
            k2: a
        };
    }
    function re(t) {
        return It < t && t < Rt.n;
    }
    function ne(t) {
        return It < t && t < Rt.P;
    }
    function ie(t) {
        return t = gt(t).slice(2), "0x" + Mt.fromPrivateKey(t).toHex();
    }
    function oe(t) {
        return new Uint8Array(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Buffer"].from(t));
    }
    Mt.BASE._setWindowSize(8);
    var se = i(function(t, e) {
        var r = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;
        e.Buffer = o, e.SlowBuffer = function(t) {
            return +t != t && (t = 0), o.alloc(+t);
        }, e.INSPECT_MAX_BYTES = 50;
        var n = 2147483647;
        function i(t) {
            if (t > n) throw new RangeError('The value "' + t + '" is invalid for option "size"');
            var e = new Uint8Array(t);
            return Object.setPrototypeOf(e, o.prototype), e;
        }
        function o(t, e, r) {
            if ("number" == typeof t) {
                if ("string" == typeof e) throw new TypeError('The "string" argument must be of type string. Received type number');
                return f(t);
            }
            return s(t, e, r);
        }
        function s(t, e, r) {
            if ("string" == typeof t) return function(t, e) {
                if ("string" == typeof e && "" !== e || (e = "utf8"), !o.isEncoding(e)) throw new TypeError("Unknown encoding: " + e);
                var r = 0 | d(t, e), n = i(r), s = n.write(t, e);
                return s !== r && (n = n.slice(0, s)), n;
            }(t, e);
            if (ArrayBuffer.isView(t)) return function(t) {
                if (z(t, Uint8Array)) {
                    var e = new Uint8Array(t);
                    return c(e.buffer, e.byteOffset, e.byteLength);
                }
                return a(t);
            }(t);
            if (null == t) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
            if (z(t, ArrayBuffer) || t && z(t.buffer, ArrayBuffer)) return c(t, e, r);
            if ("undefined" != typeof SharedArrayBuffer && (z(t, SharedArrayBuffer) || t && z(t.buffer, SharedArrayBuffer))) return c(t, e, r);
            if ("number" == typeof t) throw new TypeError('The "value" argument must not be of type number. Received type number');
            var n = t.valueOf && t.valueOf();
            if (null != n && n !== t) return o.from(n, e, r);
            var s = function(t) {
                if (o.isBuffer(t)) {
                    var e = 0 | h(t.length), r = i(e);
                    return 0 === r.length || t.copy(r, 0, 0, e), r;
                }
                return void 0 !== t.length ? "number" != typeof t.length || D(t.length) ? i(0) : a(t) : "Buffer" === t.type && Array.isArray(t.data) ? a(t.data) : void 0;
            }(t);
            if (s) return s;
            if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof t[Symbol.toPrimitive]) return o.from(t[Symbol.toPrimitive]("string"), e, r);
            throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
        }
        function u(t) {
            if ("number" != typeof t) throw new TypeError('"size" argument must be of type number');
            if (t < 0) throw new RangeError('The value "' + t + '" is invalid for option "size"');
        }
        function f(t) {
            return u(t), i(t < 0 ? 0 : 0 | h(t));
        }
        function a(t) {
            for(var e = t.length < 0 ? 0 : 0 | h(t.length), r = i(e), n = 0; n < e; n += 1)r[n] = 255 & t[n];
            return r;
        }
        function c(t, e, r) {
            if (e < 0 || t.byteLength < e) throw new RangeError('"offset" is outside of buffer bounds');
            if (t.byteLength < e + (r || 0)) throw new RangeError('"length" is outside of buffer bounds');
            var n;
            return n = void 0 === e && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, e) : new Uint8Array(t, e, r), Object.setPrototypeOf(n, o.prototype), n;
        }
        function h(t) {
            if (t >= n) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + n.toString(16) + " bytes");
            return 0 | t;
        }
        function d(t, e) {
            if (o.isBuffer(t)) return t.length;
            if (ArrayBuffer.isView(t) || z(t, ArrayBuffer)) return t.byteLength;
            if ("string" != typeof t) throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof t);
            var r = t.length, n = arguments.length > 2 && !0 === arguments[2];
            if (!n && 0 === r) return 0;
            for(var i = !1;;)switch(e){
                case "ascii":
                case "latin1":
                case "binary":
                    return r;
                case "utf8":
                case "utf-8":
                    return F(t).length;
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return 2 * r;
                case "hex":
                    return r >>> 1;
                case "base64":
                    return $(t).length;
                default:
                    if (i) return n ? -1 : F(t).length;
                    e = ("" + e).toLowerCase(), i = !0;
            }
        }
        function m(t, e, r) {
            var n = !1;
            if ((void 0 === e || e < 0) && (e = 0), e > this.length) return "";
            if ((void 0 === r || r > this.length) && (r = this.length), r <= 0) return "";
            if ((r >>>= 0) <= (e >>>= 0)) return "";
            for(t || (t = "utf8");;)switch(t){
                case "hex":
                    return R(this, e, r);
                case "utf8":
                case "utf-8":
                    return U(this, e, r);
                case "ascii":
                    return k(this, e, r);
                case "latin1":
                case "binary":
                    return T(this, e, r);
                case "base64":
                    return P(this, e, r);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return _(this, e, r);
                default:
                    if (n) throw new TypeError("Unknown encoding: " + t);
                    t = (t + "").toLowerCase(), n = !0;
            }
        }
        function w(t, e, r) {
            var n = t[e];
            t[e] = t[r], t[r] = n;
        }
        function v(t, e, r, n, i) {
            if (0 === t.length) return -1;
            if ("string" == typeof r ? (n = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), D(r = +r) && (r = i ? 0 : t.length - 1), r < 0 && (r = t.length + r), r >= t.length) {
                if (i) return -1;
                r = t.length - 1;
            } else if (r < 0) {
                if (!i) return -1;
                r = 0;
            }
            if ("string" == typeof e && (e = o.from(e, n)), o.isBuffer(e)) return 0 === e.length ? -1 : b(t, e, r, n, i);
            if ("number" == typeof e) return e &= 255, "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(t, e, r) : Uint8Array.prototype.lastIndexOf.call(t, e, r) : b(t, [
                e
            ], r, n, i);
            throw new TypeError("val must be string, number or Buffer");
        }
        function b(t, e, r, n, i) {
            var o, s = 1, u = t.length, f = e.length;
            if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
                if (t.length < 2 || e.length < 2) return -1;
                s = 2, u /= 2, f /= 2, r /= 2;
            }
            function a(t, e) {
                return 1 === s ? t[e] : t.readUInt16BE(e * s);
            }
            if (i) {
                var c = -1;
                for(o = r; o < u; o++)if (a(t, o) === a(e, -1 === c ? 0 : o - c)) {
                    if (-1 === c && (c = o), o - c + 1 === f) return c * s;
                } else -1 !== c && (o -= o - c), c = -1;
            } else for(r + f > u && (r = u - f), o = r; o >= 0; o--){
                for(var h = !0, l = 0; l < f; l++)if (a(t, o + l) !== a(e, l)) {
                    h = !1;
                    break;
                }
                if (h) return o;
            }
            return -1;
        }
        function E(t, e, r, n) {
            r = Number(r) || 0;
            var i = t.length - r;
            n ? (n = Number(n)) > i && (n = i) : n = i;
            var o = e.length;
            n > o / 2 && (n = o / 2);
            for(var s = 0; s < n; ++s){
                var u = parseInt(e.substr(2 * s, 2), 16);
                if (D(u)) return s;
                t[r + s] = u;
            }
            return s;
        }
        function B(t, e, r, n) {
            return q(F(e, t.length - r), t, r, n);
        }
        function A(t, e, r, n) {
            return q(function(t) {
                for(var e = [], r = 0; r < t.length; ++r)e.push(255 & t.charCodeAt(r));
                return e;
            }(e), t, r, n);
        }
        function x(t, e, r, n) {
            return q($(e), t, r, n);
        }
        function I(t, e, r, n) {
            return q(function(t, e) {
                for(var r, n, i = [], o = 0; o < t.length && !((e -= 2) < 0); ++o)n = (r = t.charCodeAt(o)) >> 8, i.push(r % 256), i.push(n);
                return i;
            }(e, t.length - r), t, r, n);
        }
        function P(t, e, r) {
            return p(0 === e && r === t.length ? t : t.slice(e, r));
        }
        function U(t, e, r) {
            r = Math.min(t.length, r);
            for(var n = [], i = e; i < r;){
                var o, s, u, f, a = t[i], c = null, h = a > 239 ? 4 : a > 223 ? 3 : a > 191 ? 2 : 1;
                if (i + h <= r) switch(h){
                    case 1:
                        a < 128 && (c = a);
                        break;
                    case 2:
                        128 == (192 & (o = t[i + 1])) && (f = (31 & a) << 6 | 63 & o) > 127 && (c = f);
                        break;
                    case 3:
                        s = t[i + 2], 128 == (192 & (o = t[i + 1])) && 128 == (192 & s) && (f = (15 & a) << 12 | (63 & o) << 6 | 63 & s) > 2047 && (f < 55296 || f > 57343) && (c = f);
                        break;
                    case 4:
                        s = t[i + 2], u = t[i + 3], 128 == (192 & (o = t[i + 1])) && 128 == (192 & s) && 128 == (192 & u) && (f = (15 & a) << 18 | (63 & o) << 12 | (63 & s) << 6 | 63 & u) > 65535 && f < 1114112 && (c = f);
                }
                null === c ? (c = 65533, h = 1) : c > 65535 && (n.push((c -= 65536) >>> 10 & 1023 | 55296), c = 56320 | 1023 & c), n.push(c), i += h;
            }
            return function(t) {
                var e = t.length;
                if (e <= S) return String.fromCharCode.apply(String, t);
                for(var r = "", n = 0; n < e;)r += String.fromCharCode.apply(String, t.slice(n, n += S));
                return r;
            }(n);
        }
        e.kMaxLength = n, (o.TYPED_ARRAY_SUPPORT = function() {
            try {
                var t = new Uint8Array(1), e = {
                    foo: function() {
                        return 42;
                    }
                };
                return Object.setPrototypeOf(e, Uint8Array.prototype), Object.setPrototypeOf(t, e), 42 === t.foo();
            } catch (t) {
                return !1;
            }
        }()) || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(o.prototype, "parent", {
            enumerable: !0,
            get: function() {
                if (o.isBuffer(this)) return this.buffer;
            }
        }), Object.defineProperty(o.prototype, "offset", {
            enumerable: !0,
            get: function() {
                if (o.isBuffer(this)) return this.byteOffset;
            }
        }), o.poolSize = 8192, o.from = function(t, e, r) {
            return s(t, e, r);
        }, Object.setPrototypeOf(o.prototype, Uint8Array.prototype), Object.setPrototypeOf(o, Uint8Array), o.alloc = function(t, e, r) {
            return function(t, e, r) {
                return u(t), t <= 0 ? i(t) : void 0 !== e ? "string" == typeof r ? i(t).fill(e, r) : i(t).fill(e) : i(t);
            }(t, e, r);
        }, o.allocUnsafe = function(t) {
            return f(t);
        }, o.allocUnsafeSlow = function(t) {
            return f(t);
        }, o.isBuffer = function(t) {
            return null != t && !0 === t._isBuffer && t !== o.prototype;
        }, o.compare = function(t, e) {
            if (z(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), z(e, Uint8Array) && (e = o.from(e, e.offset, e.byteLength)), !o.isBuffer(t) || !o.isBuffer(e)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
            if (t === e) return 0;
            for(var r = t.length, n = e.length, i = 0, s = Math.min(r, n); i < s; ++i)if (t[i] !== e[i]) {
                r = t[i], n = e[i];
                break;
            }
            return r < n ? -1 : n < r ? 1 : 0;
        }, o.isEncoding = function(t) {
            switch(String(t).toLowerCase()){
                case "hex":
                case "utf8":
                case "utf-8":
                case "ascii":
                case "latin1":
                case "binary":
                case "base64":
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return !0;
                default:
                    return !1;
            }
        }, o.concat = function(t, e) {
            if (!Array.isArray(t)) throw new TypeError('"list" argument must be an Array of Buffers');
            if (0 === t.length) return o.alloc(0);
            var r;
            if (void 0 === e) for(e = 0, r = 0; r < t.length; ++r)e += t[r].length;
            var n = o.allocUnsafe(e), i = 0;
            for(r = 0; r < t.length; ++r){
                var s = t[r];
                if (z(s, Uint8Array)) i + s.length > n.length ? o.from(s).copy(n, i) : Uint8Array.prototype.set.call(n, s, i);
                else {
                    if (!o.isBuffer(s)) throw new TypeError('"list" argument must be an Array of Buffers');
                    s.copy(n, i);
                }
                i += s.length;
            }
            return n;
        }, o.byteLength = d, o.prototype._isBuffer = !0, o.prototype.swap16 = function() {
            var t = this.length;
            if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
            for(var e = 0; e < t; e += 2)w(this, e, e + 1);
            return this;
        }, o.prototype.swap32 = function() {
            var t = this.length;
            if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
            for(var e = 0; e < t; e += 4)w(this, e, e + 3), w(this, e + 1, e + 2);
            return this;
        }, o.prototype.swap64 = function() {
            var t = this.length;
            if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
            for(var e = 0; e < t; e += 8)w(this, e, e + 7), w(this, e + 1, e + 6), w(this, e + 2, e + 5), w(this, e + 3, e + 4);
            return this;
        }, o.prototype.toLocaleString = o.prototype.toString = function() {
            var t = this.length;
            return 0 === t ? "" : 0 === arguments.length ? U(this, 0, t) : m.apply(this, arguments);
        }, o.prototype.equals = function(t) {
            if (!o.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
            return this === t || 0 === o.compare(this, t);
        }, o.prototype.inspect = function() {
            var t = "", r = e.INSPECT_MAX_BYTES;
            return t = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (t += " ... "), "<Buffer " + t + ">";
        }, r && (o.prototype[r] = o.prototype.inspect), o.prototype.compare = function(t, e, r, n, i) {
            if (z(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), !o.isBuffer(t)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof t);
            if (void 0 === e && (e = 0), void 0 === r && (r = t ? t.length : 0), void 0 === n && (n = 0), void 0 === i && (i = this.length), e < 0 || r > t.length || n < 0 || i > this.length) throw new RangeError("out of range index");
            if (n >= i && e >= r) return 0;
            if (n >= i) return -1;
            if (e >= r) return 1;
            if (this === t) return 0;
            for(var s = (i >>>= 0) - (n >>>= 0), u = (r >>>= 0) - (e >>>= 0), f = Math.min(s, u), a = this.slice(n, i), c = t.slice(e, r), h = 0; h < f; ++h)if (a[h] !== c[h]) {
                s = a[h], u = c[h];
                break;
            }
            return s < u ? -1 : u < s ? 1 : 0;
        }, o.prototype.includes = function(t, e, r) {
            return -1 !== this.indexOf(t, e, r);
        }, o.prototype.indexOf = function(t, e, r) {
            return v(this, t, e, r, !0);
        }, o.prototype.lastIndexOf = function(t, e, r) {
            return v(this, t, e, r, !1);
        }, o.prototype.write = function(t, e, r, n) {
            if (void 0 === e) n = "utf8", r = this.length, e = 0;
            else if (void 0 === r && "string" == typeof e) n = e, r = this.length, e = 0;
            else {
                if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                e >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
            }
            var i = this.length - e;
            if ((void 0 === r || r > i) && (r = i), t.length > 0 && (r < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
            n || (n = "utf8");
            for(var o = !1;;)switch(n){
                case "hex":
                    return E(this, t, e, r);
                case "utf8":
                case "utf-8":
                    return B(this, t, e, r);
                case "ascii":
                case "latin1":
                case "binary":
                    return A(this, t, e, r);
                case "base64":
                    return x(this, t, e, r);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return I(this, t, e, r);
                default:
                    if (o) throw new TypeError("Unknown encoding: " + n);
                    n = ("" + n).toLowerCase(), o = !0;
            }
        }, o.prototype.toJSON = function() {
            return {
                type: "Buffer",
                data: Array.prototype.slice.call(this._arr || this, 0)
            };
        };
        var S = 4096;
        function k(t, e, r) {
            var n = "";
            r = Math.min(t.length, r);
            for(var i = e; i < r; ++i)n += String.fromCharCode(127 & t[i]);
            return n;
        }
        function T(t, e, r) {
            var n = "";
            r = Math.min(t.length, r);
            for(var i = e; i < r; ++i)n += String.fromCharCode(t[i]);
            return n;
        }
        function R(t, e, r) {
            var n = t.length;
            (!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n);
            for(var i = "", o = e; o < r; ++o)i += H[t[o]];
            return i;
        }
        function _(t, e, r) {
            for(var n = t.slice(e, r), i = "", o = 0; o < n.length - 1; o += 2)i += String.fromCharCode(n[o] + 256 * n[o + 1]);
            return i;
        }
        function O(t, e, r) {
            if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
            if (t + e > r) throw new RangeError("Trying to access beyond buffer length");
        }
        function C(t, e, r, n, i, s) {
            if (!o.isBuffer(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
            if (e > i || e < s) throw new RangeError('"value" argument is out of bounds');
            if (r + n > t.length) throw new RangeError("Index out of range");
        }
        function L(t, e, r, n, i, o) {
            if (r + n > t.length) throw new RangeError("Index out of range");
            if (r < 0) throw new RangeError("Index out of range");
        }
        function M(t, e, r, n, i) {
            return e = +e, r >>>= 0, i || L(t, 0, r, 4), y(t, e, r, n, 23, 4), r + 4;
        }
        function N(t, e, r, n, i) {
            return e = +e, r >>>= 0, i || L(t, 0, r, 8), y(t, e, r, n, 52, 8), r + 8;
        }
        o.prototype.slice = function(t, e) {
            var r = this.length;
            (t = ~~t) < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), (e = void 0 === e ? r : ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), e < t && (e = t);
            var n = this.subarray(t, e);
            return Object.setPrototypeOf(n, o.prototype), n;
        }, o.prototype.readUintLE = o.prototype.readUIntLE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            for(var n = this[t], i = 1, o = 0; ++o < e && (i *= 256);)n += this[t + o] * i;
            return n;
        }, o.prototype.readUintBE = o.prototype.readUIntBE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            for(var n = this[t + --e], i = 1; e > 0 && (i *= 256);)n += this[t + --e] * i;
            return n;
        }, o.prototype.readUint8 = o.prototype.readUInt8 = function(t, e) {
            return t >>>= 0, e || O(t, 1, this.length), this[t];
        }, o.prototype.readUint16LE = o.prototype.readUInt16LE = function(t, e) {
            return t >>>= 0, e || O(t, 2, this.length), this[t] | this[t + 1] << 8;
        }, o.prototype.readUint16BE = o.prototype.readUInt16BE = function(t, e) {
            return t >>>= 0, e || O(t, 2, this.length), this[t] << 8 | this[t + 1];
        }, o.prototype.readUint32LE = o.prototype.readUInt32LE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
        }, o.prototype.readUint32BE = o.prototype.readUInt32BE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
        }, o.prototype.readIntLE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            for(var n = this[t], i = 1, o = 0; ++o < e && (i *= 256);)n += this[t + o] * i;
            return n >= (i *= 128) && (n -= Math.pow(2, 8 * e)), n;
        }, o.prototype.readIntBE = function(t, e, r) {
            t >>>= 0, e >>>= 0, r || O(t, e, this.length);
            for(var n = e, i = 1, o = this[t + --n]; n > 0 && (i *= 256);)o += this[t + --n] * i;
            return o >= (i *= 128) && (o -= Math.pow(2, 8 * e)), o;
        }, o.prototype.readInt8 = function(t, e) {
            return t >>>= 0, e || O(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
        }, o.prototype.readInt16LE = function(t, e) {
            t >>>= 0, e || O(t, 2, this.length);
            var r = this[t] | this[t + 1] << 8;
            return 32768 & r ? 4294901760 | r : r;
        }, o.prototype.readInt16BE = function(t, e) {
            t >>>= 0, e || O(t, 2, this.length);
            var r = this[t + 1] | this[t] << 8;
            return 32768 & r ? 4294901760 | r : r;
        }, o.prototype.readInt32LE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
        }, o.prototype.readInt32BE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
        }, o.prototype.readFloatLE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), g(this, t, !0, 23, 4);
        }, o.prototype.readFloatBE = function(t, e) {
            return t >>>= 0, e || O(t, 4, this.length), g(this, t, !1, 23, 4);
        }, o.prototype.readDoubleLE = function(t, e) {
            return t >>>= 0, e || O(t, 8, this.length), g(this, t, !0, 52, 8);
        }, o.prototype.readDoubleBE = function(t, e) {
            return t >>>= 0, e || O(t, 8, this.length), g(this, t, !1, 52, 8);
        }, o.prototype.writeUintLE = o.prototype.writeUIntLE = function(t, e, r, n) {
            t = +t, e >>>= 0, r >>>= 0, n || C(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
            var i = 1, o = 0;
            for(this[e] = 255 & t; ++o < r && (i *= 256);)this[e + o] = t / i & 255;
            return e + r;
        }, o.prototype.writeUintBE = o.prototype.writeUIntBE = function(t, e, r, n) {
            t = +t, e >>>= 0, r >>>= 0, n || C(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
            var i = r - 1, o = 1;
            for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)this[e + i] = t / o & 255;
            return e + r;
        }, o.prototype.writeUint8 = o.prototype.writeUInt8 = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 1, 255, 0), this[e] = 255 & t, e + 1;
        }, o.prototype.writeUint16LE = o.prototype.writeUInt16LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 65535, 0), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
        }, o.prototype.writeUint16BE = o.prototype.writeUInt16BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 65535, 0), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
        }, o.prototype.writeUint32LE = o.prototype.writeUInt32LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 4294967295, 0), this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t, e + 4;
        }, o.prototype.writeUint32BE = o.prototype.writeUInt32BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 4294967295, 0), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
        }, o.prototype.writeIntLE = function(t, e, r, n) {
            if (t = +t, e >>>= 0, !n) {
                var i = Math.pow(2, 8 * r - 1);
                C(this, t, e, r, i - 1, -i);
            }
            var o = 0, s = 1, u = 0;
            for(this[e] = 255 & t; ++o < r && (s *= 256);)t < 0 && 0 === u && 0 !== this[e + o - 1] && (u = 1), this[e + o] = (t / s >> 0) - u & 255;
            return e + r;
        }, o.prototype.writeIntBE = function(t, e, r, n) {
            if (t = +t, e >>>= 0, !n) {
                var i = Math.pow(2, 8 * r - 1);
                C(this, t, e, r, i - 1, -i);
            }
            var o = r - 1, s = 1, u = 0;
            for(this[e + o] = 255 & t; --o >= 0 && (s *= 256);)t < 0 && 0 === u && 0 !== this[e + o + 1] && (u = 1), this[e + o] = (t / s >> 0) - u & 255;
            return e + r;
        }, o.prototype.writeInt8 = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 1, 127, -128), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
        }, o.prototype.writeInt16LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 32767, -32768), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
        }, o.prototype.writeInt16BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 32767, -32768), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
        }, o.prototype.writeInt32LE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 2147483647, -2147483648), this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24, e + 4;
        }, o.prototype.writeInt32BE = function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
        }, o.prototype.writeFloatLE = function(t, e, r) {
            return M(this, t, e, !0, r);
        }, o.prototype.writeFloatBE = function(t, e, r) {
            return M(this, t, e, !1, r);
        }, o.prototype.writeDoubleLE = function(t, e, r) {
            return N(this, t, e, !0, r);
        }, o.prototype.writeDoubleBE = function(t, e, r) {
            return N(this, t, e, !1, r);
        }, o.prototype.copy = function(t, e, r, n) {
            if (!o.isBuffer(t)) throw new TypeError("argument should be a Buffer");
            if (r || (r = 0), n || 0 === n || (n = this.length), e >= t.length && (e = t.length), e || (e = 0), n > 0 && n < r && (n = r), n === r) return 0;
            if (0 === t.length || 0 === this.length) return 0;
            if (e < 0) throw new RangeError("targetStart out of bounds");
            if (r < 0 || r >= this.length) throw new RangeError("Index out of range");
            if (n < 0) throw new RangeError("sourceEnd out of bounds");
            n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r);
            var i = n - r;
            return this === t && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(e, r, n) : Uint8Array.prototype.set.call(t, this.subarray(r, n), e), i;
        }, o.prototype.fill = function(t, e, r, n) {
            if ("string" == typeof t) {
                if ("string" == typeof e ? (n = e, e = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw new TypeError("encoding must be a string");
                if ("string" == typeof n && !o.isEncoding(n)) throw new TypeError("Unknown encoding: " + n);
                if (1 === t.length) {
                    var i = t.charCodeAt(0);
                    ("utf8" === n && i < 128 || "latin1" === n) && (t = i);
                }
            } else "number" == typeof t ? t &= 255 : "boolean" == typeof t && (t = Number(t));
            if (e < 0 || this.length < e || this.length < r) throw new RangeError("Out of range index");
            if (r <= e) return this;
            var s;
            if (e >>>= 0, r = void 0 === r ? this.length : r >>> 0, t || (t = 0), "number" == typeof t) for(s = e; s < r; ++s)this[s] = t;
            else {
                var u = o.isBuffer(t) ? t : o.from(t, n), f = u.length;
                if (0 === f) throw new TypeError('The value "' + t + '" is invalid for argument "value"');
                for(s = 0; s < r - e; ++s)this[s + e] = u[s % f];
            }
            return this;
        };
        var j = /[^+/0-9A-Za-z-_]/g;
        function F(t, e) {
            var r;
            e = e || Infinity;
            for(var n = t.length, i = null, o = [], s = 0; s < n; ++s){
                if ((r = t.charCodeAt(s)) > 55295 && r < 57344) {
                    if (!i) {
                        if (r > 56319) {
                            (e -= 3) > -1 && o.push(239, 191, 189);
                            continue;
                        }
                        if (s + 1 === n) {
                            (e -= 3) > -1 && o.push(239, 191, 189);
                            continue;
                        }
                        i = r;
                        continue;
                    }
                    if (r < 56320) {
                        (e -= 3) > -1 && o.push(239, 191, 189), i = r;
                        continue;
                    }
                    r = 65536 + (i - 55296 << 10 | r - 56320);
                } else i && (e -= 3) > -1 && o.push(239, 191, 189);
                if (i = null, r < 128) {
                    if ((e -= 1) < 0) break;
                    o.push(r);
                } else if (r < 2048) {
                    if ((e -= 2) < 0) break;
                    o.push(r >> 6 | 192, 63 & r | 128);
                } else if (r < 65536) {
                    if ((e -= 3) < 0) break;
                    o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
                } else {
                    if (!(r < 1114112)) throw new Error("Invalid code point");
                    if ((e -= 4) < 0) break;
                    o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
                }
            }
            return o;
        }
        function $(t) {
            return l(function(t) {
                if ((t = (t = t.split("=")[0]).trim().replace(j, "")).length < 2) return "";
                for(; t.length % 4 != 0;)t += "=";
                return t;
            }(t));
        }
        function q(t, e, r, n) {
            for(var i = 0; i < n && !(i + r >= e.length || i >= t.length); ++i)e[i + r] = t[i];
            return i;
        }
        function z(t, e) {
            return t instanceof e || null != t && null != t.constructor && null != t.constructor.name && t.constructor.name === e.name;
        }
        function D(t) {
            return t != t;
        }
        var H = function() {
            for(var t = "0123456789abcdef", e = new Array(256), r = 0; r < 16; ++r)for(var n = 16 * r, i = 0; i < 16; ++i)e[n + i] = t[r] + t[i];
            return e;
        }();
    }), ue = new RegExp("^bytes([0-9]+)$"), fe = new RegExp("^(u?int)([0-9]*)$"), ae = new RegExp("^(.*)\\[([0-9]*)\\]$");
    function ce(t, e, r) {
        switch(t){
            case "address":
                return r ? ht(e, 32) : at(e);
            case "string":
                return se.Buffer.from(e);
            case "bytes":
                return at(e);
            case "bool":
                return e = e ? "0x01" : "0x00", r ? ht(e, 32) : at(e);
        }
        var n = t.match(fe);
        if (n) {
            var i = parseInt(n[2] || "256");
            return (n[2] && String(i) !== n[2] || i % 8 != 0 || 0 === i || i > 256) && M.throwArgumentError("invalid number type", "type", t), r && (i = 256), ht(gt(e = Y(e).toTwos(i).toNumber()), i / 8);
        }
        if (n = t.match(ue)) {
            var o = parseInt(n[1]);
            return (String(o) !== n[1] || 0 === o || o > 32) && M.throwArgumentError("invalid bytes type", "type", t), at(e).byteLength !== o && M.throwArgumentError("invalid value for " + t, "value", e), r ? at((e + k).substring(0, 66)) : e;
        }
        if ((n = t.match(ae)) && Array.isArray(e)) {
            var s = n[1];
            parseInt(n[2] || String(e.length)) != e.length && M.throwArgumentError("invalid array length for " + t, "value", e);
            var u = [];
            return e.forEach(function(t) {
                u.push(ce(s, t, !0));
            }), ct(u);
        }
        return M.throwArgumentError("invalid type", "type", t);
    }
    function he(t, e) {
        t.length != e.length && M.throwArgumentError("wrong number of values; expected ${ types.length }", "values", e);
        var r = [];
        return t.forEach(function(t, n) {
            r.push(ce(t, e[n]));
        }), gt(ct(r));
    }
    t.BaseContract = C, t.Contract = L, t.FallthroughProvider = Bt, t.JsonRpcProvider = At, t.TinyBig = J, t.arrayify = at, t.computeAddress = function(t) {
        return t.startsWith("0x04") || t.startsWith("0x03") || t.startsWith("0x02") || (t = ie(t)), tt(yt(xt(yt(t, 1)), 12));
    }, t.computePublicKey = ie, t.concat = ct, t.etherToGwei = function(t) {
        Q(t, [
            "string",
            "number",
            "object"
        ]);
        var e = Y(t).times("1000000000");
        return Y(e);
    }, t.etherToWei = function(t) {
        Q(t, [
            "string",
            "number",
            "object"
        ]);
        var e = Y(t).times("1000000000000000000");
        return Y(e);
    }, t.gweiToEther = function(t) {
        Q(t, [
            "string",
            "number",
            "object"
        ]);
        var e = Y(t).div("1000000000");
        return Y(e);
    }, t.hashMessage = function(t) {
        return "string" == typeof t && (t = oe(t)), xt(ct([
            oe("Ethereum Signed Message:\n"),
            oe(String(t.length)),
            t
        ]));
    }, t.hexConcat = function(t) {
        var e = "0x";
        return t.forEach(function(t) {
            e += gt(t).substring(2);
        }), e;
    }, t.hexDataLength = function(t) {
        if ("string" != typeof t) t = gt(t);
        else if (!lt(t) || t.length % 2) return null;
        return (t.length - 2) / 2;
    }, t.hexDataSlice = yt, t.hexStripZeros = dt, t.hexValue = function(t) {
        var e = dt(gt(t, {
            hexPad: "left"
        }));
        return "0x" === e ? "0x0" : e;
    }, t.hexZeroPad = mt, t.hexlify = gt, t.isAddress = function(t) {
        Q(t, [
            "string"
        ]);
        try {
            return tt(t), !0;
        } catch (t) {
            return !1;
        }
    }, t.isBytes = ft, t.isBytesLike = st, t.isHexString = lt, t.jsonRpcProvider = function(t) {
        return new At(t);
    }, t.keccak256 = xt, t.pack = he, t.solidityKeccak256 = function(t, e) {
        return xt(he(t, e));
    }, t.splitSignature = function(t) {
        var e = {
            r: "0x",
            s: "0x",
            _vs: "0x",
            recoveryParam: 0,
            v: 0,
            yParityAndS: "0x",
            compact: "0x"
        };
        if (st(t)) {
            var r = at(t);
            64 === r.length ? (e.v = 27 + (r[32] >> 7), r[32] &= 127, e.r = gt(r.slice(0, 32)), e.s = gt(r.slice(32, 64))) : 65 === r.length ? (e.r = gt(r.slice(0, 32)), e.s = gt(r.slice(32, 64)), e.v = r[64]) : M.throwArgumentError("invalid signature string", "signature", t), e.v < 27 && (0 === e.v || 1 === e.v ? e.v += 27 : M.throwArgumentError("signature invalid v byte", "signature", t)), e.recoveryParam = 1 - e.v % 2, e.recoveryParam && (r[32] |= 128), e._vs = gt(r.slice(32, 64));
        } else {
            if (e.r = t.r, e.s = t.s, e.v = t.v, e.recoveryParam = t.recoveryParam, e._vs = t._vs, null != e._vs) {
                var n = ht(at(e._vs), 32);
                e._vs = gt(n);
                var i = n[0] >= 128 ? 1 : 0;
                null == e.recoveryParam ? e.recoveryParam = i : e.recoveryParam !== i && M.throwArgumentError("signature recoveryParam mismatch _vs", "signature", t), n[0] &= 127;
                var o = gt(n);
                null == e.s ? e.s = o : e.s !== o && M.throwArgumentError("signature v mismatch _vs", "signature", t);
            }
            null == e.recoveryParam ? null == e.v ? M.throwArgumentError("signature missing v and recoveryParam", "signature", t) : e.recoveryParam = 0 === e.v || 1 === e.v ? e.v : 1 - e.v % 2 : null == e.v ? e.v = 27 + e.recoveryParam : e.recoveryParam !== (0 === e.v || 1 === e.v ? e.v : 1 - e.v % 2) && M.throwArgumentError("signature recoveryParam mismatch v", "signature", t), null != e.r && lt(e.r) ? e.r = mt(e.r, 32) : M.throwArgumentError("signature missing or invalid r", "signature", t), null != e.s && lt(e.s) ? e.s = mt(e.s, 32) : M.throwArgumentError("signature missing or invalid s", "signature", t);
            var s = at(e.s);
            s[0] >= 128 && M.throwArgumentError("signature s out of range", "signature", t), e.recoveryParam && (s[0] |= 128);
            var u = gt(s);
            e._vs && (lt(e._vs) || M.throwArgumentError("signature invalid _vs", "signature", t), e._vs = mt(e._vs, 32)), null == e._vs ? e._vs = u : e._vs !== u && M.throwArgumentError("signature _vs mismatch v and s", "signature", t);
        }
        return e.yParityAndS = e._vs, e.compact = e.r + e.yParityAndS.substring(2), e;
    }, t.stripZeros = function(t) {
        var e = at(t);
        if (0 === e.length) return e;
        for(var r = 0; r < e.length && 0 === e[r];)r++;
        return r && (e = e.slice(r)), e;
    }, t.tinyBig = Y, t.toChecksumAddress = tt, t.toUtf8Bytes = oe, t.weiToEther = function(t) {
        Q(t, [
            "string",
            "number",
            "object"
        ]);
        try {
            var e = t;
            "string" == typeof t && "0x" === t.slice(0, 2) && (e = BigInt(t).toString());
            var r = Y(e).div("1000000000000000000");
            return Y(r);
        } catch (t) {
            throw t;
        }
    }, t.zeroPad = ht;
}); //# sourceMappingURL=index.umd.js.map
}),
]);

//# sourceMappingURL=fc3f3_essential-eth_dist_cjs_index_umd_9ba1b6c9.js.map