(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_send_1e5f93a8.js"
],
    source: "dynamic"
});
