(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-right.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrowRightSvg",
    ()=>arrowRightSvg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$lit$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/Drainer/drain/node_modules/lit/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$lit$2d$html$2f$development$2f$lit$2d$html$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/Drainer/drain/node_modules/lit-html/development/lit-html.js [client] (ecmascript)");
;
const arrowRightSvg = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$lit$2d$html$2f$development$2f$lit$2d$html$2e$js__$5b$client$5d$__$28$ecmascript$29$__["svg"]`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1 7.99a1 1 0 0 1 1-1h7.58L7.12 4.53A1 1 0 1 1 8.54 3.1l4.16 4.17a1 1 0 0 1 0 1.41l-4.16 4.17a1 1 0 1 1-1.42-1.41l2.46-2.46H2a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`; //# sourceMappingURL=arrow-right.js.map
}),
]);

//# sourceMappingURL=fc3f3_%40reown_appkit-ui_dist_esm_src_assets_svg_arrow-right_c8edcfee.js.map