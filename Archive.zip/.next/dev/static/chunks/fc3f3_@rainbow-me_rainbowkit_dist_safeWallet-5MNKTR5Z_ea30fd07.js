(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@rainbow-me_rainbowkit_dist_safeWallet-5MNKTR5Z_f2aa2ab1.js"
],
    source: "dynamic"
});
