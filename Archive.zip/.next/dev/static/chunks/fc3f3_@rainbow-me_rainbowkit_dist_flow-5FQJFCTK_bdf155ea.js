(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Drainer/drain/node_modules/@rainbow-me/rainbowkit/dist/flow-5FQJFCTK.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>flow_default
]);
"use client";
// src/components/RainbowKitProvider/chainIcons/flow.svg
var flow_default = "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20100%20100%22%3E%3Ccircle%20fill%3D%22%2300ef8b%22%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2250%22%2F%3E%3Crect%20fill%3D%22%23fff%22%20x%3D%2257.82%22%20y%3D%2242.18%22%20width%3D%2214.12%22%20height%3D%2214.12%22%2F%3E%3Cpath%20fill%3D%22%23fff%22%20d%3D%22M43.71%2C61.59a5.3%2C5.3%2C0%2C1%2C1-5.3-5.3h5.3V42.18h-5.3A19.41%2C19.41%2C0%2C1%2C0%2C57.82%2C61.59v-5.3H43.71Z%22%2F%3E%3Cpath%20fill%3D%22%23fff%22%20d%3D%22M63.12%2C35.12H79V21H63.12A19.43%2C19.43%2C0%2C0%2C0%2C43.71%2C40.41v1.77H57.82V40.41A5.3%2C5.3%2C0%2C0%2C1%2C63.12%2C35.12Z%22%2F%3E%3Cpolygon%20fill%3D%22%2316ff99%22%20points%3D%2243.71%2056.29%2057.82%2056.29%2057.82%2056.29%2057.82%2042.18%2057.82%2042.18%2043.71%2042.18%2043.71%2056.29%22%2F%3E%3C%2Fsvg%3E";
;
}),
]);

//# sourceMappingURL=fc3f3_%40rainbow-me_rainbowkit_dist_flow-5FQJFCTK_bdf155ea.js.map