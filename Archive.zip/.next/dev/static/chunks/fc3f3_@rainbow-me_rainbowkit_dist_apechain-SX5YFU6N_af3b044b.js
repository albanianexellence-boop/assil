(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Drainer/drain/node_modules/@rainbow-me/rainbowkit/dist/apechain-SX5YFU6N.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>apechain_default
]);
"use client";
// src/components/RainbowKitProvider/chainIcons/apechain.svg
var apechain_default = "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2028%2028%22%3E%3Cg%20transform%3D%22translate(0%2C0)%20scale(0.7)%22%3E%3Cpath%20fill%3D%22url(%23a)%22%20d%3D%22M0%200h40v40H0z%22%2F%3E%3Cpath%20fill%3D%22url(%23b)%22%20fill-opacity%3D%22.6%22%20d%3D%22M0%200h40v40H0z%22%2F%3E%3Cpath%20fill%3D%22%230054FA%22%20d%3D%22M10.158%2012h2.933l1.89%2016h-2.486l-.276-3.481h-1.317L10.625%2028H8.267l1.89-16Zm1.169%207.113-.255%203.287h.977l-.276-3.287-.191-2.767h-.064l-.191%202.767ZM20.193%2028h-2.529V12h3.315c1.806%200%202.911%201.081%202.911%203.027v3.935c0%201.925-1.105%203.006-2.911%203.006h-.786V28Zm.021-7.957h.553c.425%200%20.595-.389.595-1.08v-3.936c0-.713-.17-1.103-.595-1.103h-.553v6.12ZM26.803%2028V12h4.93v2.119h-2.401v4.735h2.146v2.119h-2.146v4.908h2.401V28h-4.93Z%22%2F%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22a%22%20x1%3D%2220%22%20x2%3D%2220%22%20y1%3D%220%22%20y2%3D%2240%22%20gradientUnits%3D%22userSpaceOnUse%22%3E%3Cstop%20stop-color%3D%22%23fff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23F7F7F8%22%2F%3E%3C%2FlinearGradient%3E%3ClinearGradient%20id%3D%22b%22%20x1%3D%2220%22%20x2%3D%2220%22%20y1%3D%220%22%20y2%3D%2240%22%20gradientUnits%3D%22userSpaceOnUse%22%3E%3Cstop%20stop-color%3D%22%23fff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23E6EDFA%22%2F%3E%3C%2FlinearGradient%3E%3C%2Fdefs%3E%3C%2Fg%3E%3C%2Fsvg%3E";
;
}),
]);

//# sourceMappingURL=fc3f3_%40rainbow-me_rainbowkit_dist_apechain-SX5YFU6N_af3b044b.js.map