(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@rainbow-me_rainbowkit_dist_hyperevm-VKPAA4SA_d4ddff40.js"
],
    source: "dynamic"
});
