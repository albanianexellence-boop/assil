(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@rainbow-me_rainbowkit_dist_Windows-PPTHQER6_db9de127.js"
],
    source: "dynamic"
});
