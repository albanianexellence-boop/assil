(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/d4b1c_modules_@reown_appkit-ui_dist_esm_src_assets_svg_recycle-horizontal_02b40d48.js"
],
    source: "dynamic"
});
