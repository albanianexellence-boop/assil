(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/add.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_add_1da5d904.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_add_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/add.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/all-wallets.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_all-wallets_73419bfb.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_all-wallets_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/all-wallets.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-bottom-circle.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-bottom-circle_f23ee07b.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-bottom-circle_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-bottom-circle.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/app-store.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_app-store_446ebb4f.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_app-store_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/app-store.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/apple.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_apple_0bf78122.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_apple_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/apple.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-bottom.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-bottom_b50c1211.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-bottom_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-bottom.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-left.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-left_bd3caf8d.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-left_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-left.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-right.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-right_c8edcfee.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-right_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-right.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-top.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-top_856c7904.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_arrow-top_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/arrow-top.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/bank.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_bank_44d484d3.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_bank_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/bank.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/browser.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_browser_b407a809.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_browser_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/browser.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/card.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_card_b71d0c8e.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_card_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/card.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/checkmark.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_checkmark_5ce5de7b.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_checkmark_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/checkmark.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/checkmark-bold.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_checkmark-bold_976e4026.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_checkmark-bold_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/checkmark-bold.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-bottom.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-bottom_d9fd7f4d.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-bottom_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-bottom.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-left.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-left_c6179273.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-left_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-left.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-right.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-right_923c77fd.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-right_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-right.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-top.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-top_acd543a9.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chevron-top_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chevron-top.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chrome-store.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chrome-store_ce36e430.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_chrome-store_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/chrome-store.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/clock.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_clock_4d4eacfa.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_clock_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/clock.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/close.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_close_e6d5297d.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_close_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/close.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/compass.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_compass_0ba2caf6.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_compass_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/compass.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/coinPlaceholder.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_coinPlaceholder_d4836702.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_coinPlaceholder_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/coinPlaceholder.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/copy.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_copy_cf40905b.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_copy_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/copy.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/cursor.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_cursor_d122db36.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_cursor_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/cursor.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/cursor-transparent.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_cursor-transparent_aa670cb6.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_cursor-transparent_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/cursor-transparent.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/desktop.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_desktop_be70ba25.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_desktop_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/desktop.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/disconnect.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_disconnect_f8d9620c.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_disconnect_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/disconnect.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/discord.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_discord_d42c3a5b.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_discord_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/discord.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/etherscan.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_etherscan_f66244bd.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_etherscan_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/etherscan.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/extension.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_extension_001439c7.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_extension_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/extension.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/external-link.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_external-link_ea06941a.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_external-link_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/external-link.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/facebook.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_facebook_532297d1.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_facebook_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/facebook.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/farcaster.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_farcaster_669e5b5a.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_farcaster_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/farcaster.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/filters.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_filters_0cb5dc4b.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_filters_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/filters.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/github.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_github_d03e3535.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_github_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/github.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/google.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_google_006d417b.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_google_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/google.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/help-circle.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_help-circle_411d5c5e.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_help-circle_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/help-circle.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/image.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_image_e40a5d9a.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_image_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/image.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/id.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_id_8e2dd360.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_id_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/id.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/info-circle.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_info-circle_6cceac25.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_info-circle_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/info-circle.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/lightbulb.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_lightbulb_7d5d7ad5.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_lightbulb_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/lightbulb.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/mail.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_mail_c989a20a.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_mail_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/mail.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/mobile.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_mobile_4f9658be.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_mobile_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/mobile.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/more.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_more_369d666f.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_more_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/more.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/network-placeholder.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_network-placeholder_2d5fbc00.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_network-placeholder_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/network-placeholder.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/nftPlaceholder.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_nftPlaceholder_b96996df.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_nftPlaceholder_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/nftPlaceholder.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/off.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_off_32e67e26.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_off_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/off.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/play-store.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_play-store_85dbf74f.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_play-store_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/play-store.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/plus.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_plus_1fdcd351.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_plus_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/plus.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/qr-code.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_qr-code_6971cab7.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_qr-code_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/qr-code.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/recycle-horizontal.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_recycle-horizontal_2bed8940.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_recycle-horizontal_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/recycle-horizontal.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/refresh.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_refresh_c8b058dd.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_refresh_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/refresh.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/search.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_search_bdf9d941.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_search_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/search.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/send.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_send_1e5f93a8.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_send_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/send.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontal.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontal_7d95ee98.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontal_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontal.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontalMedium.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalMedium_6ca68a8e.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalMedium_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontalMedium.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontalBold.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalBold_622b8aca.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalBold_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontalBold.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontalRoundedBold.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalRoundedBold_7dcb63cd.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalRoundedBold_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapHorizontalRoundedBold.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapVertical.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapVertical_ac0d4ed1.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_swapVertical_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapVertical.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/telegram.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_telegram_d3fea80e.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_telegram_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/telegram.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/three-dots.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_three-dots_1b4a1a14.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_three-dots_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/three-dots.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/twitch.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_twitch_7fb44b57.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_twitch_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/twitch.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/x.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_x_e09e32d2.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_x_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/x.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/twitterIcon.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_twitterIcon_893ff3d1.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_twitterIcon_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/twitterIcon.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/verify.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_verify_690efaa7.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_verify_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/verify.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/verify-filled.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_verify-filled_4fe585ee.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_verify-filled_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/verify-filled.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/wallet.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_wallet_c507d0db.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_wallet_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/wallet.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/walletconnect.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_walletconnect_c2ed15f4.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_walletconnect_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/walletconnect.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/wallet-placeholder.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_wallet-placeholder_03561a9e.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_wallet-placeholder_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/wallet-placeholder.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/warning-circle.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_warning-circle_ca3120da.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_warning-circle_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/warning-circle.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/info.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_info_dc7a8a50.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_info_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/info.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/exclamation-triangle.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_exclamation-triangle_8ae68d31.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_exclamation-triangle_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/exclamation-triangle.js [client] (ecmascript)");
    });
});
}),
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/reown-logo.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_reown-logo_7fb73576.js",
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_reown-logo_62b6ee3f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/reown-logo.js [client] (ecmascript)");
    });
});
}),
]);