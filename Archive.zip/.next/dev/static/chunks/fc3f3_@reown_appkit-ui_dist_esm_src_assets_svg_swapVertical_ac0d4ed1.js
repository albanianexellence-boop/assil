(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Drainer/drain/node_modules/@reown/appkit-ui/dist/esm/src/assets/svg/swapVertical.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "swapVerticalSvg",
    ()=>swapVerticalSvg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$lit$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/Drainer/drain/node_modules/lit/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$lit$2d$html$2f$development$2f$lit$2d$html$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/Drainer/drain/node_modules/lit-html/development/lit-html.js [client] (ecmascript)");
;
const swapVerticalSvg = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$Drainer$2f$drain$2f$node_modules$2f$lit$2d$html$2f$development$2f$lit$2d$html$2e$js__$5b$client$5d$__$28$ecmascript$29$__["svg"]`<svg fill="none" viewBox="0 0 14 14">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.48 2.18a1 1 0 0 1 1.41 0l2.68 2.68a1 1 0 1 1-1.41 1.42l-.98-.98v4.56a1 1 0 0 1-2 0V5.3l-.97.98A1 1 0 0 1 .79 4.86l2.69-2.68Zm6.34 2.93a1 1 0 0 1 1 1v4.56l.97-.98a1 1 0 1 1 1.42 1.42l-2.69 2.68a1 1 0 0 1-1.41 0l-2.68-2.68a1 1 0 0 1 1.41-1.42l.98.98V6.1a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`; //# sourceMappingURL=swapVertical.js.map
}),
]);

//# sourceMappingURL=fc3f3_%40reown_appkit-ui_dist_esm_src_assets_svg_swapVertical_ac0d4ed1.js.map