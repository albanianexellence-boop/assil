(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@rainbow-me_rainbowkit_dist_Edge-XSPUTORV_7d957fec.js"
],
    source: "dynamic"
});
