(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@rainbow-me_rainbowkit_dist_unichain-C5BWO2ZY_9c6c68d3.js"
],
    source: "dynamic"
});
