(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_discord_d42c3a5b.js"
],
    source: "dynamic"
});
