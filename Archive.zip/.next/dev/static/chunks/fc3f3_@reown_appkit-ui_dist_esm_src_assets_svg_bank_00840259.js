(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_@reown_appkit-ui_dist_esm_src_assets_svg_bank_44d484d3.js"
],
    source: "dynamic"
});
