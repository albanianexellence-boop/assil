(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fc3f3_viem__cjs_44018295._.js",
  "static/chunks/fc3f3_ecbf8def._.js",
  "static/chunks/fc3f3_e8fb6b8b._.js",
  "static/chunks/fc3f3_ox__cjs_56b33b69._.js",
  "static/chunks/fc3f3_38a86e2e._.js"
],
    source: "dynamic"
});
