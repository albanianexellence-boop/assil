self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/pages/index.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/admin",
    "/api/chain-info/[chainId]/[evmAddress]",
    "/api/login",
    "/api/saveAccount",
    "/api/users"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()