globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_viem_e8150c95._.js",
      "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_viem__esm_8ca677b7._.js",
      "static/chunks/node_modules_9e939af6._.js",
      "static/chunks/node_modules_ox__esm_65a5a38f._.js",
      "static/chunks/node_modules_142e2d9f._.js",
      "static/chunks/node_modules_essential-eth_dist_cjs_index_umd_b4a0b90f.js",
      "static/chunks/node_modules_311470c8._.js",
      "static/chunks/[root-of-the-server]__78d6d6d6._.js",
      "static/chunks/pages_index_2da965e7._.js",
      "static/chunks/turbopack-pages_index_7974fff3._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_956a8a5e._.js",
      "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
      "static/chunks/node_modules_next_dist_shared_lib_cf5b50a6._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_next_head_6b89d279.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_@geist-ui_core_esm_efe49926._.js",
      "static/chunks/node_modules_@wagmi_core_dist_esm_93139c39._.js",
      "static/chunks/node_modules_@rainbow-me_rainbowkit_dist_d1c1a3c9._.js",
      "static/chunks/node_modules_viem__esm_61dcefaf._.js",
      "static/chunks/node_modules_0c808dca._.js",
      "static/chunks/node_modules_9e939af6._.js",
      "static/chunks/node_modules_ox__esm_88213144._.js",
      "static/chunks/node_modules_@tanstack_query-core_build_modern_603aa737._.js",
      "static/chunks/node_modules_zod_v4_92117688._.js",
      "static/chunks/node_modules_9abb6c9f._.js",
      "static/chunks/[root-of-the-server]__fe4c7414._.js",
      "static/chunks/_bf19d304._.css",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_1a679802._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];