var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/node_modules_next_433d09f3._.js")
R.c("server/chunks/ssr/[root-of-the-server]__84687bd7._.js")
R.c("server/chunks/ssr/[root-of-the-server]__917b5a80._.js")
R.c("server/chunks/ssr/node_modules_next_3be9481d._.js")
R.c("server/chunks/ssr/[root-of-the-server]__fa2b9e34._.js")
R.m(87299)
module.exports=R.m(87299).exports
