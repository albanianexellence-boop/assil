var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/saveAccount.js")
R.c("server/chunks/[root-of-the-server]__8357ed4d._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(6419)
module.exports=R.m(6419).exports
