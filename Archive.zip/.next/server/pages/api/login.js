var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/login.js")
R.c("server/chunks/[root-of-the-server]__57344d95._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(10935)
module.exports=R.m(10935).exports
