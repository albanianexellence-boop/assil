var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/users.js")
R.c("server/chunks/[root-of-the-server]__b09cc2e8._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(23427)
module.exports=R.m(23427).exports
