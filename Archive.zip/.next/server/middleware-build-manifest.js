globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/ec2d417a9bf1b71b.js",
      "static/chunks/54d6203486ba066a.js",
      "static/chunks/d2c70fa6f9a42eeb.js",
      "static/chunks/0bcd4c5350cd5526.js",
      "static/chunks/c51ddab992d175b5.js",
      "static/chunks/136ce825c0e15c0b.js",
      "static/chunks/d8dbe8026c20b3fc.js",
      "static/chunks/e2e9f7dfa7ae7f9f.js",
      "static/chunks/5e87aec0a3abe185.js",
      "static/chunks/39bd26227248b718.js",
      "static/chunks/turbopack-2314606017fe3836.js"
    ],
    "/_app": [
      "static/chunks/54d6203486ba066a.js",
      "static/chunks/c3cd565834e928c3.js",
      "static/chunks/e2e9f7dfa7ae7f9f.js",
      "static/chunks/0bcd4c5350cd5526.js",
      "static/chunks/2ace94f90e7b3b7d.js",
      "static/chunks/8f2efa2e31711f2b.js",
      "static/chunks/136ce825c0e15c0b.js",
      "static/chunks/fcb07cf8c42eaecb.js",
      "static/chunks/d2c70fa6f9a42eeb.js",
      "static/chunks/5e8ee1f6029e2220.js",
      "static/chunks/a750c8e12da28258.css",
      "static/chunks/turbopack-a9b4effb8d4dc93f.js"
    ],
    "/_error": [
      "static/chunks/708640f4346d5e3a.js",
      "static/chunks/136ce825c0e15c0b.js",
      "static/chunks/e2e9f7dfa7ae7f9f.js",
      "static/chunks/turbopack-8416ac59d64d3ae5.js"
    ],
    "/admin": [
      "static/chunks/624d19ba1fc1f8c0.js",
      "static/chunks/136ce825c0e15c0b.js",
      "static/chunks/e2e9f7dfa7ae7f9f.js",
      "static/chunks/turbopack-8e5550ec885dc297.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];