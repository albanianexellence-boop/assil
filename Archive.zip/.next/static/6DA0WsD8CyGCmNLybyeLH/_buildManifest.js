self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/9296be98ecc8fe80.js"
  ],
  "/_error": [
    "static/chunks/f46b2afd529ee415.js"
  ],
  "/admin": [
    "static/chunks/f04fb3280672490f.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/admin",
    "/api/chain-info/[chainId]/[evmAddress]",
    "/api/login",
    "/api/saveAccount",
    "/api/users"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()