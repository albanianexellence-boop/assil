__turbopack_load_page_chunks__("/_error", [
  "static/chunks/708640f4346d5e3a.js",
  "static/chunks/136ce825c0e15c0b.js",
  "static/chunks/e2e9f7dfa7ae7f9f.js",
  "static/chunks/turbopack-8416ac59d64d3ae5.js"
])
