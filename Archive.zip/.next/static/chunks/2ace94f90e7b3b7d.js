(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,89129,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={DecodeError:function(){return w},MiddlewareNotFoundError:function(){return v},MissingStaticPage:function(){return k},NormalizeError:function(){return b},PageNotFoundError:function(){return g},SP:function(){return y},ST:function(){return m},WEB_VITALS:function(){return a},execOnce:function(){return s},getDisplayName:function(){return p},getLocationOrigin:function(){return c},getURL:function(){return u},isAbsoluteUrl:function(){return l},isResSent:function(){return d},loadGetInitialProps:function(){return f},normalizeRepeatedSlashes:function(){return h},stringifyError:function(){return W}};for(var n in o)Object.defineProperty(r,n,{enumerable:!0,get:o[n]});let a=["CLS","FCP","FID","INP","LCP","TTFB"];function s(e){let t,r=!1;return(...o)=>(r||(r=!0,t=e(...o)),t)}let i=/^[a-zA-Z][a-zA-Z\d+\-.]*?:/,l=e=>i.test(e);function c(){let{protocol:e,hostname:t,port:r}=window.location;return`${e}//${t}${r?":"+r:""}`}function u(){let{href:e}=window.location,t=c();return e.substring(t.length)}function p(e){return"string"==typeof e?e:e.displayName||e.name||"Unknown"}function d(e){return e.finished||e.headersSent}function h(e){let t=e.split("?");return t[0].replace(/\\/g,"/").replace(/\/\/+/g,"/")+(t[1]?`?${t.slice(1).join("?")}`:"")}async function f(e,t){let r=t.res||t.ctx&&t.ctx.res;if(!e.getInitialProps)return t.ctx&&t.Component?{pageProps:await f(t.Component,t.ctx)}:{};let o=await e.getInitialProps(t);if(r&&d(r))return o;if(!o)throw Object.defineProperty(Error(`"${p(e)}.getInitialProps()" should resolve to an object. But found "${o}" instead.`),"__NEXT_ERROR_CODE",{value:"E394",enumerable:!1,configurable:!0});return o}let y="undefined"!=typeof performance,m=y&&["mark","measure","getEntriesByName"].every(e=>"function"==typeof performance[e]);class w extends Error{}class b extends Error{}class g extends Error{constructor(e){super(),this.code="ENOENT",this.name="PageNotFoundError",this.message=`Cannot find module for page: ${e}`}}class k extends Error{constructor(e,t){super(),this.message=`Failed to load static file for page: ${e} ${t}`}}class v extends Error{constructor(){super(),this.code="ENOENT",this.message="Cannot find the middleware module"}}function W(e){return JSON.stringify({message:e.message,stack:e.stack})}},94941,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"default",{enumerable:!0,get:function(){return i}});let o=e.r(91788),n="undefined"==typeof window,a=n?()=>{}:o.useLayoutEffect,s=n?()=>{}:o.useEffect;function i(e){let{headManager:t,reduceComponentsToState:r}=e;function i(){if(t&&t.mountedInstances){let e=o.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));t.updateHead(r(e))}}return n&&(t?.mountedInstances?.add(e.children),i()),a(()=>(t?.mountedInstances?.add(e.children),()=>{t?.mountedInstances?.delete(e.children)})),a(()=>(t&&(t._pendingUpdate=i),()=>{t&&(t._pendingUpdate=i)})),s(()=>(t&&t._pendingUpdate&&(t._pendingUpdate(),t._pendingUpdate=null),()=>{t&&t._pendingUpdate&&(t._pendingUpdate(),t._pendingUpdate=null)})),null}},80963,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={default:function(){return y},defaultHead:function(){return p}};for(var n in o)Object.defineProperty(r,n,{enumerable:!0,get:o[n]});let a=e.r(41705),s=e.r(52456),i=e.r(91398),l=s._(e.r(91788)),c=a._(e.r(94941)),u=e.r(13584);function p(){return[(0,i.jsx)("meta",{charSet:"utf-8"},"charset"),(0,i.jsx)("meta",{name:"viewport",content:"width=device-width"},"viewport")]}function d(e,t){return"string"==typeof t||"number"==typeof t?e:t.type===l.default.Fragment?e.concat(l.default.Children.toArray(t.props.children).reduce((e,t)=>"string"==typeof t||"number"==typeof t?e:e.concat(t),[])):e.concat(t)}e.r(94470);let h=["name","httpEquiv","charSet","itemProp"];function f(e){let t,r,o,n;return e.reduce(d,[]).reverse().concat(p().reverse()).filter((t=new Set,r=new Set,o=new Set,n={},e=>{let a=!0,s=!1;if(e.key&&"number"!=typeof e.key&&e.key.indexOf("$")>0){s=!0;let r=e.key.slice(e.key.indexOf("$")+1);t.has(r)?a=!1:t.add(r)}switch(e.type){case"title":case"base":r.has(e.type)?a=!1:r.add(e.type);break;case"meta":for(let t=0,r=h.length;t<r;t++){let r=h[t];if(e.props.hasOwnProperty(r))if("charSet"===r)o.has(r)?a=!1:o.add(r);else{let t=e.props[r],o=n[r]||new Set;("name"!==r||!s)&&o.has(t)?a=!1:(o.add(t),n[r]=o)}}}return a})).reverse().map((e,t)=>{let r=e.key||t;return l.default.cloneElement(e,{key:r})})}let y=function({children:e}){let t=(0,l.useContext)(u.HeadManagerContext);return(0,i.jsx)(c.default,{reduceComponentsToState:f,headManager:t,children:e})};("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},20955,(e,t,r)=>{var o={229:function(e){var t,r,o,n=e.exports={};function a(){throw Error("setTimeout has not been defined")}function s(){throw Error("clearTimeout has not been defined")}try{t="function"==typeof setTimeout?setTimeout:a}catch(e){t=a}try{r="function"==typeof clearTimeout?clearTimeout:s}catch(e){r=s}function i(e){if(t===setTimeout)return setTimeout(e,0);if((t===a||!t)&&setTimeout)return t=setTimeout,setTimeout(e,0);try{return t(e,0)}catch(r){try{return t.call(null,e,0)}catch(r){return t.call(this,e,0)}}}var l=[],c=!1,u=-1;function p(){c&&o&&(c=!1,o.length?l=o.concat(l):u=-1,l.length&&d())}function d(){if(!c){var e=i(p);c=!0;for(var t=l.length;t;){for(o=l,l=[];++u<t;)o&&o[u].run();u=-1,t=l.length}o=null,c=!1,function(e){if(r===clearTimeout)return clearTimeout(e);if((r===s||!r)&&clearTimeout)return r=clearTimeout,clearTimeout(e);try{r(e)}catch(t){try{return r.call(null,e)}catch(t){return r.call(this,e)}}}(e)}}function h(e,t){this.fun=e,this.array=t}function f(){}n.nextTick=function(e){var t=Array(arguments.length-1);if(arguments.length>1)for(var r=1;r<arguments.length;r++)t[r-1]=arguments[r];l.push(new h(e,t)),1!==l.length||c||i(d)},h.prototype.run=function(){this.fun.apply(null,this.array)},n.title="browser",n.browser=!0,n.env={},n.argv=[],n.version="",n.versions={},n.on=f,n.addListener=f,n.once=f,n.off=f,n.removeListener=f,n.removeAllListeners=f,n.emit=f,n.prependListener=f,n.prependOnceListener=f,n.listeners=function(e){return[]},n.binding=function(e){throw Error("process.binding is not supported")},n.cwd=function(){return"/"},n.chdir=function(e){throw Error("process.chdir is not supported")},n.umask=function(){return 0}}},n={};function a(e){var t=n[e];if(void 0!==t)return t.exports;var r=n[e]={exports:{}},s=!0;try{o[e](r,r.exports,a),s=!1}finally{s&&delete n[e]}return r.exports}a.ab="/ROOT/node_modules/next/dist/compiled/process/",t.exports=a(229)},50461,(e,t,r)=>{"use strict";var o,n;t.exports=(null==(o=e.g.process)?void 0:o.env)&&"object"==typeof(null==(n=e.g.process)?void 0:n.env)?e.g.process:e.r(20955)},8481,(e,t,r)=>{"use strict";var o=Symbol.for("react.transitional.element");function n(e,t,r){var n=null;if(void 0!==r&&(n=""+r),void 0!==t.key&&(n=""+t.key),"key"in t)for(var a in r={},t)"key"!==a&&(r[a]=t[a]);else r=t;return{$$typeof:o,type:e,key:n,ref:void 0!==(t=r.ref)?t:null,props:r}}r.Fragment=Symbol.for("react.fragment"),r.jsx=n,r.jsxs=n},91398,(e,t,r)=>{"use strict";t.exports=e.r(8481)},61556,(e,t,r)=>{"use strict";var o=e.i(50461),n=Symbol.for("react.transitional.element"),a=Symbol.for("react.portal"),s=Symbol.for("react.fragment"),i=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),u=Symbol.for("react.context"),p=Symbol.for("react.forward_ref"),d=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),f=Symbol.for("react.lazy"),y=Symbol.for("react.activity"),m=Symbol.iterator,w={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},b=Object.assign,g={};function k(e,t,r){this.props=e,this.context=t,this.refs=g,this.updater=r||w}function v(){}function W(e,t,r){this.props=e,this.context=t,this.refs=g,this.updater=r||w}k.prototype.isReactComponent={},k.prototype.setState=function(e,t){if("object"!=typeof e&&"function"!=typeof e&&null!=e)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},k.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},v.prototype=k.prototype;var _=W.prototype=new v;_.constructor=W,b(_,k.prototype),_.isPureReactComponent=!0;var C=Array.isArray;function x(){}var O={H:null,A:null,T:null,S:null},P=Object.prototype.hasOwnProperty;function I(e,t,r){var o=r.ref;return{$$typeof:n,type:e,key:t,ref:void 0!==o?o:null,props:r}}function j(e){return"object"==typeof e&&null!==e&&e.$$typeof===n}var E=/\/+/g;function S(e,t){var r,o;return"object"==typeof e&&null!==e&&null!=e.key?(r=""+e.key,o={"=":"=0",":":"=2"},"$"+r.replace(/[=:]/g,function(e){return o[e]})):t.toString(36)}function T(e,t,r){if(null==e)return e;var o=[],s=0;return!function e(t,r,o,s,i){var l,c,u,p=typeof t;("undefined"===p||"boolean"===p)&&(t=null);var d=!1;if(null===t)d=!0;else switch(p){case"bigint":case"string":case"number":d=!0;break;case"object":switch(t.$$typeof){case n:case a:d=!0;break;case f:return e((d=t._init)(t._payload),r,o,s,i)}}if(d)return i=i(t),d=""===s?"."+S(t,0):s,C(i)?(o="",null!=d&&(o=d.replace(E,"$&/")+"/"),e(i,r,o,"",function(e){return e})):null!=i&&(j(i)&&(l=i,c=o+(null==i.key||t&&t.key===i.key?"":(""+i.key).replace(E,"$&/")+"/")+d,i=I(l.type,c,l.props)),r.push(i)),1;d=0;var h=""===s?".":s+":";if(C(t))for(var y=0;y<t.length;y++)p=h+S(s=t[y],y),d+=e(s,r,o,p,i);else if("function"==typeof(y=null===(u=t)||"object"!=typeof u?null:"function"==typeof(u=m&&u[m]||u["@@iterator"])?u:null))for(t=y.call(t),y=0;!(s=t.next()).done;)p=h+S(s=s.value,y++),d+=e(s,r,o,p,i);else if("object"===p){if("function"==typeof t.then)return e(function(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch("string"==typeof e.status?e.then(x,x):(e.status="pending",e.then(function(t){"pending"===e.status&&(e.status="fulfilled",e.value=t)},function(t){"pending"===e.status&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}(t),r,o,s,i);throw Error("Objects are not valid as a React child (found: "+("[object Object]"===(r=String(t))?"object with keys {"+Object.keys(t).join(", ")+"}":r)+"). If you meant to render a collection of children, use an array instead.")}return d}(e,o,"","",function(e){return t.call(r,e,s++)}),o}function R(e){if(-1===e._status){var t=e._result;(t=t()).then(function(t){(0===e._status||-1===e._status)&&(e._status=1,e._result=t)},function(t){(0===e._status||-1===e._status)&&(e._status=2,e._result=t)}),-1===e._status&&(e._status=0,e._result=t)}if(1===e._status)return e._result.default;throw e._result}var A="function"==typeof reportError?reportError:function(e){if("object"==typeof window&&"function"==typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"==typeof o.default&&"function"==typeof o.default.emit)return void o.default.emit("uncaughtException",e);console.error(e)};r.Activity=y,r.Children={map:T,forEach:function(e,t,r){T(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return T(e,function(){t++}),t},toArray:function(e){return T(e,function(e){return e})||[]},only:function(e){if(!j(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},r.Component=k,r.Fragment=s,r.Profiler=l,r.PureComponent=W,r.StrictMode=i,r.Suspense=d,r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=O,r.__COMPILER_RUNTIME={__proto__:null,c:function(e){return O.H.useMemoCache(e)}},r.cache=function(e){return function(){return e.apply(null,arguments)}},r.cacheSignal=function(){return null},r.cloneElement=function(e,t,r){if(null==e)throw Error("The argument must be a React element, but you passed "+e+".");var o=b({},e.props),n=e.key;if(null!=t)for(a in void 0!==t.key&&(n=""+t.key),t)P.call(t,a)&&"key"!==a&&"__self"!==a&&"__source"!==a&&("ref"!==a||void 0!==t.ref)&&(o[a]=t[a]);var a=arguments.length-2;if(1===a)o.children=r;else if(1<a){for(var s=Array(a),i=0;i<a;i++)s[i]=arguments[i+2];o.children=s}return I(e.type,n,o)},r.createContext=function(e){return(e={$$typeof:u,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider=e,e.Consumer={$$typeof:c,_context:e},e},r.createElement=function(e,t,r){var o,n={},a=null;if(null!=t)for(o in void 0!==t.key&&(a=""+t.key),t)P.call(t,o)&&"key"!==o&&"__self"!==o&&"__source"!==o&&(n[o]=t[o]);var s=arguments.length-2;if(1===s)n.children=r;else if(1<s){for(var i=Array(s),l=0;l<s;l++)i[l]=arguments[l+2];n.children=i}if(e&&e.defaultProps)for(o in s=e.defaultProps)void 0===n[o]&&(n[o]=s[o]);return I(e,a,n)},r.createRef=function(){return{current:null}},r.forwardRef=function(e){return{$$typeof:p,render:e}},r.isValidElement=j,r.lazy=function(e){return{$$typeof:f,_payload:{_status:-1,_result:e},_init:R}},r.memo=function(e,t){return{$$typeof:h,type:e,compare:void 0===t?null:t}},r.startTransition=function(e){var t=O.T,r={};O.T=r;try{var o=e(),n=O.S;null!==n&&n(r,o),"object"==typeof o&&null!==o&&"function"==typeof o.then&&o.then(x,A)}catch(e){A(e)}finally{null!==t&&null!==r.types&&(t.types=r.types),O.T=t}},r.unstable_useCacheRefresh=function(){return O.H.useCacheRefresh()},r.use=function(e){return O.H.use(e)},r.useActionState=function(e,t,r){return O.H.useActionState(e,t,r)},r.useCallback=function(e,t){return O.H.useCallback(e,t)},r.useContext=function(e){return O.H.useContext(e)},r.useDebugValue=function(){},r.useDeferredValue=function(e,t){return O.H.useDeferredValue(e,t)},r.useEffect=function(e,t){return O.H.useEffect(e,t)},r.useEffectEvent=function(e){return O.H.useEffectEvent(e)},r.useId=function(){return O.H.useId()},r.useImperativeHandle=function(e,t,r){return O.H.useImperativeHandle(e,t,r)},r.useInsertionEffect=function(e,t){return O.H.useInsertionEffect(e,t)},r.useLayoutEffect=function(e,t){return O.H.useLayoutEffect(e,t)},r.useMemo=function(e,t){return O.H.useMemo(e,t)},r.useOptimistic=function(e,t){return O.H.useOptimistic(e,t)},r.useReducer=function(e,t,r){return O.H.useReducer(e,t,r)},r.useRef=function(e){return O.H.useRef(e)},r.useState=function(e){return O.H.useState(e)},r.useSyncExternalStore=function(e,t,r){return O.H.useSyncExternalStore(e,t,r)},r.useTransition=function(){return O.H.useTransition()},r.version="19.2.1"},91788,(e,t,r)=>{"use strict";t.exports=e.r(61556)},41705,(e,t,r)=>{"use strict";r._=function(e){return e&&e.__esModule?e:{default:e}}},13584,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"HeadManagerContext",{enumerable:!0,get:function(){return o}});let o=e.r(41705)._(e.r(91788)).default.createContext({})},94470,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"warnOnce",{enumerable:!0,get:function(){return o}});let o=e=>{}},52456,(e,t,r)=>{"use strict";function o(e){if("function"!=typeof WeakMap)return null;var t=new WeakMap,r=new WeakMap;return(o=function(e){return e?r:t})(e)}r._=function(e,t){if(!t&&e&&e.__esModule)return e;if(null===e||"object"!=typeof e&&"function"!=typeof e)return{default:e};var r=o(t);if(r&&r.has(e))return r.get(e);var n={__proto__:null},a=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var s in e)if("default"!==s&&Object.prototype.hasOwnProperty.call(e,s)){var i=a?Object.getOwnPropertyDescriptor(e,s):null;i&&(i.get||i.set)?Object.defineProperty(n,s,i):n[s]=e[s]}return n.default=e,r&&r.set(e,n),n}},17431,(e,t,r)=>{"use strict";var o=e.r(91788);function n(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(){}var s={d:{f:a,r:function(){throw Error(n(522))},D:a,C:a,L:a,m:a,X:a,S:a,M:a},p:0,findDOMNode:null},i=Symbol.for("react.portal"),l=o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function c(e,t){return"font"===e?"":"string"==typeof t?"use-credentials"===t?t:"":void 0}r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,r.createPortal=function(e,t){var r=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!t||1!==t.nodeType&&9!==t.nodeType&&11!==t.nodeType)throw Error(n(299));return function(e,t,r){var o=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:i,key:null==o?null:""+o,children:e,containerInfo:t,implementation:r}}(e,t,null,r)},r.flushSync=function(e){var t=l.T,r=s.p;try{if(l.T=null,s.p=2,e)return e()}finally{l.T=t,s.p=r,s.d.f()}},r.preconnect=function(e,t){"string"==typeof e&&(t=t?"string"==typeof(t=t.crossOrigin)?"use-credentials"===t?t:"":void 0:null,s.d.C(e,t))},r.prefetchDNS=function(e){"string"==typeof e&&s.d.D(e)},r.preinit=function(e,t){if("string"==typeof e&&t&&"string"==typeof t.as){var r=t.as,o=c(r,t.crossOrigin),n="string"==typeof t.integrity?t.integrity:void 0,a="string"==typeof t.fetchPriority?t.fetchPriority:void 0;"style"===r?s.d.S(e,"string"==typeof t.precedence?t.precedence:void 0,{crossOrigin:o,integrity:n,fetchPriority:a}):"script"===r&&s.d.X(e,{crossOrigin:o,integrity:n,fetchPriority:a,nonce:"string"==typeof t.nonce?t.nonce:void 0})}},r.preinitModule=function(e,t){if("string"==typeof e)if("object"==typeof t&&null!==t){if(null==t.as||"script"===t.as){var r=c(t.as,t.crossOrigin);s.d.M(e,{crossOrigin:r,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0})}}else null==t&&s.d.M(e)},r.preload=function(e,t){if("string"==typeof e&&"object"==typeof t&&null!==t&&"string"==typeof t.as){var r=t.as,o=c(r,t.crossOrigin);s.d.L(e,r,{crossOrigin:o,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0,type:"string"==typeof t.type?t.type:void 0,fetchPriority:"string"==typeof t.fetchPriority?t.fetchPriority:void 0,referrerPolicy:"string"==typeof t.referrerPolicy?t.referrerPolicy:void 0,imageSrcSet:"string"==typeof t.imageSrcSet?t.imageSrcSet:void 0,imageSizes:"string"==typeof t.imageSizes?t.imageSizes:void 0,media:"string"==typeof t.media?t.media:void 0})}},r.preloadModule=function(e,t){if("string"==typeof e)if(t){var r=c(t.as,t.crossOrigin);s.d.m(e,{as:"string"==typeof t.as&&"script"!==t.as?t.as:void 0,crossOrigin:r,integrity:"string"==typeof t.integrity?t.integrity:void 0})}else s.d.m(e)},r.requestFormReset=function(e){s.d.r(e)},r.unstable_batchedUpdates=function(e,t){return e(t)},r.useFormState=function(e,t,r){return l.H.useFormState(e,t,r)},r.useFormStatus=function(){return l.H.useHostTransitionStatus()},r.version="19.2.1"},30943,(e,t,r)=>{"use strict";!function e(){if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(e){console.error(e)}}(),t.exports=e.r(17431)},82374,12459,e=>{"use strict";var t=e.i(91788);let r=0,o={get url(){return`file://${e.P("node_modules/jotai/esm/index.mjs")}`}},n=Symbol(),a=e=>!!e[n],s=e=>!e[n].c,i=e=>{var t;let{b:r,c:o}=e[n];o&&(o(),null==(t=u.get(r))||t())},l=(e,t)=>{let r=e[n].o,o=t[n].o;return r===o||e===o||a(r)&&l(r,t)},c=(e,t)=>{let r={b:e,o:t,c:null},o=new Promise(e=>{r.c=()=>{r.c=null,e()},t.finally(r.c)});return o[n]=r,o},u=new WeakMap,p=e=>"init"in e,d=new Map,h=e=>{var r,u;return d.has(e)||d.set(e,(0,t.createContext)({s:u?u(r).SECRET_INTERNAL_store:(e=>{let t,r,u=new WeakMap,d=new WeakMap,h=new Map;if("production"!==(o.env&&o.env.MODE)&&(t=new Set,r=new Set),e)for(let[t,r]of e){let e={v:r,r:0,y:!0,d:new Map};"production"!==(o.env&&o.env.MODE)&&(Object.freeze(e),p(t)||console.warn("Found initial value for derived atom which can cause unexpected behavior",t)),u.set(t,e)}let f=new WeakMap,y=new WeakMap,m=e=>{let t=y.get(e);return t||(t=new Map,y.set(e,t)),t},w=(e,t)=>{if(e){let r=m(e),o=r.get(t);return!o&&((o=w(e.p,t))&&"p"in o&&s(o.p)&&(o=void 0),o&&r.set(t,o)),o}return u.get(t)},b=(e,t,r)=>{if("production"!==(o.env&&o.env.MODE)&&Object.freeze(r),e)m(e).set(t,r);else{let e=u.get(t);u.set(t,r),h.has(t)||h.set(t,e)}},g=(e,t=new Map,r)=>{if(!r)return t;let o=new Map,n=!1;return(r.forEach(r=>{var a;let s=(null==(a=w(e,r))?void 0:a.r)||0;o.set(r,s),t.get(r)!==s&&(n=!0)}),t.size!==o.size||n)?o:t},k=(e,t,r,o,n)=>{let a=w(e,t);if(a){if(n&&(!("p"in a)||!l(a.p,n)))return a;"p"in a&&i(a.p)}let s={v:r,r:(null==a?void 0:a.r)||0,y:!0,d:g(e,null==a?void 0:a.d,o)},c=!(null==a?void 0:a.y);return(a&&"v"in a&&Object.is(a.v,r)?s.d===a.d||s.d.size===a.d.size&&Array.from(s.d.keys()).every(e=>a.d.has(e))||(c=!0,Promise.resolve().then(()=>{R(e)})):(c=!0,++s.r,s.d.has(t)&&(s.d=new Map(s.d).set(t,s.r))),a&&!c)?a:(b(e,t,s),s)},v=(e,t,r,o,n)=>{let a=w(e,t);if(a){if(n&&(!("p"in a)||!l(a.p,n)))return a;"p"in a&&i(a.p)}let s={e:r,r:((null==a?void 0:a.r)||0)+1,y:!0,d:g(e,null==a?void 0:a.d,o)};return b(e,t,s),s},W=(e,t,r,o)=>{let n,a=w(e,t);if(a&&"p"in a){if(l(a.p,r)&&!s(a.p))return a.y?a:{...a,y:!0};i(a.p)}(n=f.get(t))||(n=new Map,f.set(t,n)),r.then(()=>{n.get(e)===r&&(n.delete(e),n.size||f.delete(t))}),n.set(e,r);let c={p:r,r:((null==a?void 0:a.r)||0)+1,y:!0,d:g(e,null==a?void 0:a.d,o)};return b(e,t,c),c},_=(e,t,r,o)=>{if(r instanceof Promise){let n=c(r,r.then(r=>{k(e,t,r,o,n)}).catch(r=>{if(r instanceof Promise)return a(r)?r.then(()=>{C(e,t,!0)}):r;v(e,t,r,o,n)}));return W(e,t,n,o)}return k(e,t,r,o)},C=(e,t,r)=>{if(!r){let r=w(e,t);if(r){if(r.y&&"p"in r&&!s(r.p))return r;if(r.d.forEach((r,o)=>{if(o!==t)if(d.has(o)){let t=w(e,o);t&&!t.y&&C(e,o)}else C(e,o)}),Array.from(r.d).every(([t,r])=>{let o=w(e,t);return o&&!("p"in o)&&o.r===r}))return r.y?r:{...r,y:!0}}}let o=new Set;try{let r=t.read(r=>{o.add(r);let n=r===t?w(e,r):C(e,r);if(n){if("e"in n)throw n.e;if("p"in n)throw n.p;return n.v}if(p(r))return r.init;throw Error("no atom init")});return _(e,t,r,o)}catch(r){if(r instanceof Promise)return W(e,t,a(r)&&s(r)?c(r[n].b,r[n].o):c(r,r),o);return v(e,t,r,o)}},x=(e,t)=>C(t,e),O=(e,t)=>!t.l.size&&(!t.t.size||1===t.t.size&&t.t.has(e)),P=(e,t)=>{let r=d.get(t);null==r||r.t.forEach(r=>{if(r!==t){let t;(t=w(e,r))?b(e,r,{...t,y:!1}):"production"!==(o.env&&o.env.MODE)&&console.warn("[Bug] could not invalidate non existing atom",r),P(e,r)}})},I=(e,t,r)=>{let n=!0,a=(t,r)=>{let n=C(e,t);if("e"in n)throw n.e;if("p"in n){if(null==r?void 0:r.unstable_promise)return n.p.then(()=>{let o=w(e,t);return o&&"p"in o&&o.p===n.p?new Promise(e=>setTimeout(e)).then(()=>a(t,r)):a(t,r)});throw"production"!==(o.env&&o.env.MODE)&&console.info("Reading pending atom state in write operation. We throw a promise for now.",t),n.p}if("v"in n)return n.v;throw"production"!==(o.env&&o.env.MODE)&&console.warn("[Bug] no value found while reading atom in write operation. This is probably a bug.",t),Error("no value found")},s=t.write(a,(r,o)=>{let a;if(r===t){let t,n;if(!p(r))throw Error("atom not writable");(t=new Set,(n=f.get(r))&&(f.delete(r),n.forEach((e,r)=>{i(e),t.add(r)})),t).forEach(t=>{t!==e&&_(t,r,o)}),w(e,r)!==_(e,r,o)&&P(e,r)}else a=I(e,r,o);return n||R(e),a},r);return n=!1,s},j=(e,t,r)=>{let o=I(r,e,t);return R(r),o},E=(e,t,n)=>{let a={t:new Set(n&&[n]),l:new Set};if(d.set(t,a),"production"!==(o.env&&o.env.MODE)&&r.add(t),C(void 0,t).d.forEach((r,o)=>{let n=d.get(o);n?n.t.add(t):o!==t&&E(e,o,t)}),t.write&&t.onMount){let r=t.onMount(r=>j(t,r,e));e=void 0,r&&(a.u=r)}return a},S=(e,t)=>{var n;let a=null==(n=d.get(t))?void 0:n.u;a&&a(),d.delete(t),"production"!==(o.env&&o.env.MODE)&&r.delete(t);let s=w(e,t);s?("p"in s&&i(s.p),s.d.forEach((r,o)=>{if(o!==t){let r=d.get(o);r&&(r.t.delete(t),O(o,r)&&S(e,o))}})):"production"!==(o.env&&o.env.MODE)&&console.warn("[Bug] could not find atom state to unmount",t)},T=(e,t,r,o)=>{let n=new Set(r.d.keys());null==o||o.forEach((r,o)=>{if(n.has(o))return void n.delete(o);let a=d.get(o);a&&(a.t.delete(t),O(o,a)&&S(e,o))}),n.forEach(r=>{let o=d.get(r);o?o.t.add(t):d.has(t)&&E(e,r,t)})},R=e=>{if(e)return void m(e).forEach((t,r)=>{if(t!==u.get(r)){let t=d.get(r);null==t||t.l.forEach(t=>t(e))}});for(;h.size;){let e=Array.from(h);h.clear(),e.forEach(([e,t])=>{let r=w(void 0,e);if(r&&r.d!==(null==t?void 0:t.d)&&T(void 0,e,r,null==t?void 0:t.d),t&&!t.y&&(null==r?void 0:r.y))return;let o=d.get(e);null==o||o.l.forEach(e=>e())})}"production"!==(o.env&&o.env.MODE)&&t.forEach(e=>e())},A=(e,t)=>{t&&m(t).forEach((e,r)=>{let o=u.get(r);(!o||e.r>o.r||e.y!==o.y||e.r===o.r&&e.d!==o.d)&&(u.set(r,e),e.d!==(null==o?void 0:o.d)&&T(t,r,e,null==o?void 0:o.d))}),R(void 0)},N=(e,t,r)=>{let o,n=(!(o=d.get(e))&&(o=E(r,e)),o).l;return n.add(t),()=>{let o;n.delete(t),(o=d.get(e))&&O(e,o)&&S(r,e)}},q=(e,t)=>{for(let[r,o]of e)p(r)&&(_(t,r,o),P(t,r));R(t)};return"production"!==(o.env&&o.env.MODE)?{r:x,w:j,c:A,s:N,h:q,n:e=>(t.add(e),()=>{t.delete(e)}),l:()=>r.values(),a:e=>u.get(e),m:e=>d.get(e)}:{r:x,w:j,c:A,s:N,h:q}})(r)})),d.get(e)};function f(e,t){let o,n;return o=`atom${++r}`,n={toString:()=>o},"function"==typeof e?n.read=e:(n.init=e,n.read=e=>e(n),n.write=(e,t,r)=>t(n,"function"==typeof r?r(e(n)):r)),t&&(n.write=t),n}function y(e,r){return"scope"in e&&(console.warn("atom.scope is deprecated. Please do useAtom(atom, scope) instead."),r=e.scope),[function(e,r){let n=h(r),a=(0,t.useContext)(n),{s:s,v:i}=a,l=t=>{let r=s.r(e,t);if("production"!==(o.env&&o.env.MODE)&&!r.y)throw Error("should not be invalidated");if("e"in r)throw r.e;if("p"in r)throw r.p;if("v"in r)return r.v;throw Error("no atom value")},[[c,u,p],d]=(0,t.useReducer)((t,r)=>{let o=l(r);return Object.is(t[1],o)&&t[2]===e?t:[r,o,e]},i,t=>{let r=l(t);return[t,r,e]}),f=u;return p!==e&&(d(c),f=l(c)),(0,t.useEffect)(()=>{let{v:t}=a;t&&s.c(e,t);let r=s.s(e,d,t);return d(t),r},[s,e,a]),(0,t.useEffect)(()=>{s.c(e,c)}),(0,t.useDebugValue)(f),f}(e,r),function(e,r){let n=h(r),{s:a,w:s}=(0,t.useContext)(n);return(0,t.useCallback)(t=>{if("production"!==(o.env&&o.env.MODE)&&!("write"in e))throw Error("not writable atom");let r=r=>a.w(e,t,r);return s?s(r):r()},[a,s,e])}(e,r)]}e.s(["atom",()=>f,"useAtom",()=>y],82374);let m=f(!1),w=f(null),b=f(!1),g=f(null);e.s(["accountCreatedAtom",0,b,"claimedPrizeAtom",0,w,"hasSpunWheelAtom",0,m,"loggedInUserAtom",0,g],12459)},93065,e=>{"use strict";var t=`{
  "connect_wallet": {
    "label": "Connect Wallet",
    "wrong_network": {
      "label": "Wrong network"
    }
  },

  "intro": {
    "title": "What is a Wallet?",
    "description": "A wallet is used to send, receive, store, and display digital assets. It's also a new way to log in, without needing to create new accounts and passwords on every website.",
    "digital_asset": {
      "title": "A Home for your Digital Assets",
      "description": "Wallets are used to send, receive, store, and display digital assets like Ethereum and NFTs."
    },
    "login": {
      "title": "A New Way to Log In",
      "description": "Instead of creating new accounts and passwords on every website, just connect your wallet."
    },
    "get": {
      "label": "Get a Wallet"
    },
    "learn_more": {
      "label": "Learn More"
    }
  },

  "sign_in": {
    "label": "Verify your account",
    "description": "To finish connecting, you must sign a message in your wallet to verify that you are the owner of this account.",
    "message": {
      "send": "Sign message",
      "preparing": "Preparing message...",
      "cancel": "Cancel",
      "preparing_error": "Error preparing message, please retry!"
    },
    "signature": {
      "waiting": "Waiting for signature...",
      "verifying": "Verifying signature...",
      "signing_error": "Error signing message, please retry!",
      "verifying_error": "Error verifying signature, please retry!",
      "oops_error": "Oops, something went wrong!"
    }
  },

  "connect": {
    "label": "Connect",
    "title": "Connect a Wallet",
    "new_to_ethereum": {
      "description": "New to Ethereum wallets?",
      "learn_more": {
        "label": "Learn More"
      }
    },
    "learn_more": {
      "label": "Learn more"
    },
    "recent": "Recent",
    "status": {
      "opening": "Opening %{wallet}...",
      "connecting": "Connecting",
      "connect_mobile": "Continue in %{wallet}",
      "not_installed": "%{wallet} is not installed",
      "not_available": "%{wallet} is not available",
      "confirm": "Confirm connection in the extension",
      "confirm_mobile": "Accept connection request in the wallet"
    },
    "secondary_action": {
      "get": {
        "description": "Don't have %{wallet}?",
        "label": "GET"
      },
      "install": {
        "label": "INSTALL"
      },
      "retry": {
        "label": "RETRY"
      }
    },
    "walletconnect": {
      "description": {
        "full": "Need the official WalletConnect modal?",
        "compact": "Need the WalletConnect modal?"
      },
      "open": {
        "label": "OPEN"
      }
    }
  },

  "connect_scan": {
    "title": "Scan with %{wallet}",
    "fallback_title": "Scan with your phone"
  },

  "connector_group": {
    "installed": "Installed",
    "recommended": "Recommended",
    "other": "Other",
    "popular": "Popular",
    "more": "More",
    "others": "Others"
  },

  "get": {
    "title": "Get a Wallet",
    "action": {
      "label": "GET"
    },
    "mobile": {
      "description": "Mobile Wallet"
    },
    "extension": {
      "description": "Browser Extension"
    },
    "mobile_and_extension": {
      "description": "Mobile Wallet and Extension"
    },
    "mobile_and_desktop": {
      "description": "Mobile and Desktop Wallet"
    },
    "looking_for": {
      "title": "Not what you're looking for?",
      "mobile": {
        "description": "Select a wallet on the main screen to get started with a different wallet provider."
      },
      "desktop": {
        "compact_description": "Select a wallet on the main screen to get started with a different wallet provider.",
        "wide_description": "Select a wallet on the left to get started with a different wallet provider."
      }
    }
  },

  "get_options": {
    "title": "Get started with %{wallet}",
    "short_title": "Get %{wallet}",
    "mobile": {
      "title": "%{wallet} for Mobile",
      "description": "Use the mobile wallet to explore the world of Ethereum.",
      "download": {
        "label": "Get the app"
      }
    },
    "extension": {
      "title": "%{wallet} for %{browser}",
      "description": "Access your wallet right from your favorite web browser.",
      "download": {
        "label": "Add to %{browser}"
      }
    },
    "desktop": {
      "title": "%{wallet} for %{platform}",
      "description": "Access your wallet natively from your powerful desktop.",
      "download": {
        "label": "Add to %{platform}"
      }
    }
  },

  "get_mobile": {
    "title": "Install %{wallet}",
    "description": "Scan with your phone to download on iOS or Android",
    "continue": {
      "label": "Continue"
    }
  },

  "get_instructions": {
    "mobile": {
      "connect": {
        "label": "Connect"
      },
      "learn_more": {
        "label": "Learn More"
      }
    },
    "extension": {
      "refresh": {
        "label": "Refresh"
      },
      "learn_more": {
        "label": "Learn More"
      }
    },
    "desktop": {
      "connect": {
        "label": "Connect"
      },
      "learn_more": {
        "label": "Learn More"
      }
    }
  },

  "chains": {
    "title": "Switch Networks",
    "wrong_network": "Wrong network detected, switch or disconnect to continue.",
    "confirm": "Confirm in Wallet",
    "switching_not_supported": "Your wallet does not support switching networks from %{appName}. Try switching networks from within your wallet instead.",
    "switching_not_supported_fallback": "Your wallet does not support switching networks from this app. Try switching networks from within your wallet instead.",
    "disconnect": "Disconnect",
    "connected": "Connected"
  },

  "profile": {
    "disconnect": {
      "label": "Disconnect"
    },
    "copy_address": {
      "label": "Copy Address",
      "copied": "Copied!"
    },
    "explorer": {
      "label": "View more on explorer"
    },
    "transactions": {
      "description": "%{appName} transactions will appear here...",
      "description_fallback": "Your transactions will appear here...",
      "recent": {
        "title": "Recent Transactions"
      },
      "clear": {
        "label": "Clear All"
      }
    }
  },

  "wallet_connectors": {
    "ready": {
      "qr_code": {
        "step1": {
          "description": "Add Ready to your home screen for faster access to your wallet.",
          "title": "Open the Ready app"
        },
        "step2": {
          "description": "Create a wallet and username, or import an existing wallet.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "berasig": {
      "extension": {
        "step1": {
          "title": "Install the BeraSig extension",
          "description": "We recommend pinning BeraSig to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "best": {
      "qr_code": {
        "step1": {
          "title": "Open the Best Wallet app",
          "description": "Add Best Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "bifrost": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bifrost Wallet on your home screen for quicker access.",
          "title": "Open the Bifrost Wallet app"
        },
        "step2": {
          "description": "Create or import a wallet using your recovery phrase.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "bitget": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bitget Wallet on your home screen for quicker access.",
          "title": "Open the Bitget Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Bitget Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Bitget Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "bitski": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Bitski to your taskbar for quicker access to your wallet.",
          "title": "Install the Bitski extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "bitverse": {
      "qr_code": {
        "step1": {
          "title": "Open the Bitverse Wallet app",
          "description": "Add Bitverse Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "bloom": {
      "desktop": {
        "step1": {
          "title": "Open the Bloom Wallet app",
          "description": "We recommend putting Bloom Wallet on your home screen for quicker access."
        },
        "step2": {
          "description": "Create or import a wallet using your recovery phrase.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you have a wallet, click on Connect to connect via Bloom. A connection prompt in the app will appear for you to confirm the connection.",
          "title": "Click on Connect"
        }
      }
    },

    "bybit": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bybit on your home screen for faster access to your wallet.",
          "title": "Open the Bybit app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "Click at the top right of your browser and pin Bybit Wallet for easy access.",
          "title": "Install the Bybit Wallet extension"
        },
        "step2": {
          "description": "Create a new wallet or import an existing one.",
          "title": "Create or Import a wallet"
        },
        "step3": {
          "description": "Once you set up Bybit Wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "binance": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Binance on your home screen for faster access to your wallet.",
          "title": "Open the Binance app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Binance Wallet extension",
          "description": "We recommend pinning Binance Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "coin98": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Coin98 Wallet on your home screen for faster access to your wallet.",
          "title": "Open the Coin98 Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },

      "extension": {
        "step1": {
          "description": "Click at the top right of your browser and pin Coin98 Wallet for easy access.",
          "title": "Install the Coin98 Wallet extension"
        },
        "step2": {
          "description": "Create a new wallet or import an existing one.",
          "title": "Create or Import a wallet"
        },
        "step3": {
          "description": "Once you set up Coin98 Wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "coinbase": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Coinbase Wallet on your home screen for quicker access.",
          "title": "Open the Coinbase Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using the cloud backup feature.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Coinbase Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Coinbase Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "compass": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Compass Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Compass Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "core": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Core on your home screen for faster access to your wallet.",
          "title": "Open the Core app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Core to your taskbar for quicker access to your wallet.",
          "title": "Install the Core extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "fox": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting FoxWallet on your home screen for quicker access.",
          "title": "Open the FoxWallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "frontier": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Frontier Wallet on your home screen for quicker access.",
          "title": "Open the Frontier Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Frontier Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Frontier Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "im_token": {
      "qr_code": {
        "step1": {
          "title": "Open the imToken app",
          "description": "Put imToken app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "iopay": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting ioPay on your home screen for faster access to your wallet.",
          "title": "Open the ioPay app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      }
    },

    "kaikas": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Kaikas to your taskbar for quicker access to your wallet.",
          "title": "Install the Kaikas extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Kaikas app",
          "description": "Put Kaikas app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "kaia": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Kaia to your taskbar for quicker access to your wallet.",
          "title": "Install the Kaia extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Kaia app",
          "description": "Put Kaia app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "kraken": {
      "qr_code": {
        "step1": {
          "title": "Open the Kraken Wallet app",
          "description": "Add Kraken Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "kresus": {
      "qr_code": {
        "step1": {
          "title": "Open the Kresus Wallet app",
          "description": "Add Kresus Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "magicEden": {
      "extension": {
        "step1": {
          "title": "Install the Magic Eden extension",
          "description": "We recommend pinning Magic Eden to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "metamask": {
      "qr_code": {
        "step1": {
          "title": "Open the MetaMask app",
          "description": "We recommend putting MetaMask on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the MetaMask extension",
          "description": "We recommend pinning MetaMask to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "nestwallet": {
      "extension": {
        "step1": {
          "title": "Install the NestWallet extension",
          "description": "We recommend pinning NestWallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "okx": {
      "qr_code": {
        "step1": {
          "title": "Open the OKX Wallet app",
          "description": "We recommend putting OKX Wallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the OKX Wallet extension",
          "description": "We recommend pinning OKX Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "omni": {
      "qr_code": {
        "step1": {
          "title": "Open the Omni app",
          "description": "Add Omni to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your home screen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "1inch": {
      "qr_code": {
        "step1": {
          "description": "Put 1inch Wallet on your home screen for faster access to your wallet.",
          "title": "Open the 1inch Wallet app"
        },
        "step2": {
          "description": "Create a wallet and username, or import an existing wallet.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "token_pocket": {
      "qr_code": {
        "step1": {
          "title": "Open the TokenPocket app",
          "description": "We recommend putting TokenPocket on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the TokenPocket extension",
          "description": "We recommend pinning TokenPocket to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "trust": {
      "qr_code": {
        "step1": {
          "title": "Open the Trust Wallet app",
          "description": "Put Trust Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the Trust Wallet extension",
          "description": "Click at the top right of your browser and pin Trust Wallet for easy access."
        },
        "step2": {
          "title": "Create or Import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up Trust Wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "uniswap": {
      "qr_code": {
        "step1": {
          "title": "Open the Uniswap app",
          "description": "Add Uniswap Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "zerion": {
      "qr_code": {
        "step1": {
          "title": "Open the Zerion app",
          "description": "We recommend putting Zerion on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the Zerion extension",
          "description": "We recommend pinning Zerion to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "rainbow": {
      "qr_code": {
        "step1": {
          "title": "Open the Rainbow app",
          "description": "We recommend putting Rainbow on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "You can easily backup your wallet using our backup feature on your phone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "enkrypt": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Enkrypt Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Enkrypt Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "frame": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Frame to your taskbar for quicker access to your wallet.",
          "title": "Install Frame & the companion extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "one_key": {
      "extension": {
        "step1": {
          "title": "Install the OneKey Wallet extension",
          "description": "We recommend pinning OneKey Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "paraswap": {
      "qr_code": {
        "step1": {
          "title": "Open the ParaSwap app",
          "description": "Add ParaSwap Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "phantom": {
      "extension": {
        "step1": {
          "title": "Install the Phantom extension",
          "description": "We recommend pinning Phantom to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "rabby": {
      "extension": {
        "step1": {
          "title": "Install the Rabby extension",
          "description": "We recommend pinning Rabby to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "ronin": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Ronin Wallet on your home screen for quicker access.",
          "title": "Open the Ronin Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Ronin Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Ronin Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "ramper": {
      "extension": {
        "step1": {
          "title": "Install the Ramper extension",
          "description": "We recommend pinning Ramper to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "safeheron": {
      "extension": {
        "step1": {
          "title": "Install the Core extension",
          "description": "We recommend pinning Safeheron to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "taho": {
      "extension": {
        "step1": {
          "title": "Install the Taho extension",
          "description": "We recommend pinning Taho to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "wigwam": {
      "extension": {
        "step1": {
          "title": "Install the Wigwam extension",
          "description": "We recommend pinning Wigwam to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "talisman": {
      "extension": {
        "step1": {
          "title": "Install the Talisman extension",
          "description": "We recommend pinning Talisman to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import an Ethereum Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "ctrl": {
      "extension": {
        "step1": {
          "title": "Install the CTRL Wallet extension",
          "description": "We recommend pinning CTRL Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "zeal": {
      "qr_code": {
        "step1": {
          "title": "Open the Zeal app",
          "description": "Add Zeal Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Zeal extension",
          "description": "We recommend pinning Zeal to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "safepal": {
      "extension": {
        "step1": {
          "title": "Install the SafePal Wallet extension",
          "description": "Click at the top right of your browser and pin SafePal Wallet for easy access."
        },
        "step2": {
          "title": "Create or Import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up SafePal Wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the SafePal Wallet app",
          "description": "Put SafePal Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "desig": {
      "extension": {
        "step1": {
          "title": "Install the Desig extension",
          "description": "We recommend pinning Desig to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "subwallet": {
      "extension": {
        "step1": {
          "title": "Install the SubWallet extension",
          "description": "We recommend pinning SubWallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the SubWallet app",
          "description": "We recommend putting SubWallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "clv": {
      "extension": {
        "step1": {
          "title": "Install the CLV Wallet extension",
          "description": "We recommend pinning CLV Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the CLV Wallet app",
          "description": "We recommend putting CLV Wallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "okto": {
      "qr_code": {
        "step1": {
          "title": "Open the Okto app",
          "description": "Add Okto to your home screen for quick access"
        },
        "step2": {
          "title": "Create an MPC Wallet",
          "description": "Create an account and generate a wallet"
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Tap the Scan QR icon at the top right and confirm the prompt to connect."
        }
      }
    },

    "ledger": {
      "desktop": {
        "step1": {
          "title": "Open the Ledger Live app",
          "description": "We recommend putting Ledger Live on your home screen for quicker access."
        },
        "step2": {
          "title": "Set up your Ledger",
          "description": "Set up a new Ledger or connect to an existing one."
        },
        "step3": {
          "title": "Connect",
          "description": "A connection prompt will appear for you to connect your wallet."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Ledger Live app",
          "description": "We recommend putting Ledger Live on your home screen for quicker access."
        },
        "step2": {
          "title": "Set up your Ledger",
          "description": "You can either sync with the desktop app or connect your Ledger."
        },
        "step3": {
          "title": "Scan the code",
          "description": "Tap WalletConnect then Switch to Scanner. After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "valora": {
      "qr_code": {
        "step1": {
          "title": "Open the Valora app",
          "description": "We recommend putting Valora on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "gate": {
      "qr_code": {
        "step1": {
          "title": "Open the Gate app",
          "description": "We recommend putting Gate on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Gate extension",
          "description": "We recommend pinning Gate to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "gemini": {
      "qr_code": {
        "step1": {
          "title": "Open keys.gemini.com",
          "description": "Visit keys.gemini.com on your mobile browser - no app download required."
        },
        "step2": {
          "title": "Create Your Wallet Instantly",
          "description": "Set up your smart wallet in seconds using your device's built-in authentication."
        },
        "step3": {
          "title": "Scan to Connect",
          "description": "Scan the QR code to instantly connect your wallet - it just works."
        }
      },
      "extension": {
        "step1": {
          "title": "Go to keys.gemini.com",
          "description": "No extensions or downloads needed - your wallet lives securely in the browser."
        },
        "step2": {
          "title": "One-Click Setup",
          "description": "Create your smart wallet instantly with passkey authentication - easier than any wallet out there."
        },
        "step3": {
          "title": "Connect and Go",
          "description": "Approve the connection and you're ready - the unopinionated wallet that just works."
        }
      }
    },

    "xportal": {
      "qr_code": {
        "step1": {
          "description": "Put xPortal on your home screen for faster access to your wallet.",
          "title": "Open the xPortal app"
        },
        "step2": {
          "description": "Create a wallet or import an existing one.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "mew": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting MEW Wallet on your home screen for quicker access.",
          "title": "Open the MEW Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using the cloud backup feature.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "zilpay": {
      "qr_code": {
        "step1": {
          "title": "Open the ZilPay app",
          "description": "Add ZilPay to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "nova": {
      "qr_code": {
        "step1": {
          "title": "Open the Nova Wallet app",
          "description": "Add Nova Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    }
  }
}
`;e.s(["en_US_default",()=>t])},48761,e=>{e.v(t=>Promise.all(["static/chunks/f4fe8aeb8343dcd3.js"].map(t=>e.l(t))).then(()=>t(93594)))},28805,e=>{e.v(t=>Promise.all(["static/chunks/3dcc93bb4829c1ba.js"].map(t=>e.l(t))).then(()=>t(79466)))},94911,e=>{e.v(t=>Promise.all(["static/chunks/954760753f91f571.js"].map(t=>e.l(t))).then(()=>t(95705)))},6836,e=>{e.v(e=>Promise.resolve().then(()=>e(80062)))},72720,e=>{e.v(t=>Promise.all(["static/chunks/010233d8ca628da2.js","static/chunks/c7c43cab9b04dcbf.js","static/chunks/b135c0b8032dd27d.js"].map(t=>e.l(t))).then(()=>t(97338)))},28073,e=>{e.v(t=>Promise.all(["static/chunks/3c46bccf93cff96c.js","static/chunks/d34caad9599cc0d5.js"].map(t=>e.l(t))).then(()=>t(98231)))},26805,e=>{e.v(t=>Promise.all(["static/chunks/4d2469c1d09c7733.js"].map(t=>e.l(t))).then(()=>t(2914)))},81277,e=>{e.v(t=>Promise.all(["static/chunks/4df77be8b3a38fd3.js"].map(t=>e.l(t))).then(()=>t(94810)))},52674,e=>{e.v(t=>Promise.all(["static/chunks/63d409b6ef52ac18.js","static/chunks/1834d64271f8510c.js"].map(t=>e.l(t))).then(()=>t(72302)))},28249,e=>{e.v(t=>Promise.all(["static/chunks/e84d4f395929869d.js"].map(t=>e.l(t))).then(()=>t(76843)))},8841,e=>{e.v(t=>Promise.all(["static/chunks/da91db98d677ea77.js"].map(t=>e.l(t))).then(()=>t(91853)))},67824,e=>{e.v(t=>Promise.all(["static/chunks/63693f0e509a8d53.js"].map(t=>e.l(t))).then(()=>t(85778)))},24376,e=>{e.v(t=>Promise.all(["static/chunks/1c358547bf04736c.js"].map(t=>e.l(t))).then(()=>t(17093)))},76117,e=>{e.v(t=>Promise.all(["static/chunks/e5e18f63afb3f11c.js"].map(t=>e.l(t))).then(()=>t(85507)))},49063,e=>{e.v(t=>Promise.all(["static/chunks/cfc853efdb3d7ff6.js"].map(t=>e.l(t))).then(()=>t(64193)))},95820,e=>{e.v(t=>Promise.all(["static/chunks/f8a651459bc89691.js"].map(t=>e.l(t))).then(()=>t(60474)))},32702,e=>{e.v(t=>Promise.all(["static/chunks/5d8072890fe17710.js"].map(t=>e.l(t))).then(()=>t(48199)))},86578,e=>{e.v(t=>Promise.all(["static/chunks/2ed71c7c059699fc.js"].map(t=>e.l(t))).then(()=>t(14110)))},74524,e=>{e.v(t=>Promise.all(["static/chunks/014078d1df5f27ca.js"].map(t=>e.l(t))).then(()=>t(43927)))},89391,e=>{e.v(t=>Promise.all(["static/chunks/5439699c942996ee.js"].map(t=>e.l(t))).then(()=>t(21653)))},79545,e=>{e.v(t=>Promise.all(["static/chunks/49fead536fd19305.js"].map(t=>e.l(t))).then(()=>t(70866)))},65595,e=>{e.v(t=>Promise.all(["static/chunks/39f258fc9969a5da.js"].map(t=>e.l(t))).then(()=>t(70597)))},99936,e=>{e.v(t=>Promise.all(["static/chunks/1c62f7ea4a0784b4.js"].map(t=>e.l(t))).then(()=>t(33920)))},40210,e=>{e.v(t=>Promise.all(["static/chunks/9975619c1a7c25ea.js"].map(t=>e.l(t))).then(()=>t(41486)))},78474,e=>{e.v(t=>Promise.all(["static/chunks/d2c743c33bab5d5f.js"].map(t=>e.l(t))).then(()=>t(2478)))},92854,e=>{e.v(t=>Promise.all(["static/chunks/cde10da51b423b03.js"].map(t=>e.l(t))).then(()=>t(68701)))},96967,e=>{e.v(t=>Promise.all(["static/chunks/a868541082537a6e.js"].map(t=>e.l(t))).then(()=>t(54993)))},42844,e=>{e.v(t=>Promise.all(["static/chunks/d663a86f110d8469.js"].map(t=>e.l(t))).then(()=>t(24495)))},10135,e=>{e.v(t=>Promise.all(["static/chunks/c18bc2d67e4b2e8c.js"].map(t=>e.l(t))).then(()=>t(14695)))},90735,e=>{e.v(t=>Promise.all(["static/chunks/a482617404ff1ec0.js"].map(t=>e.l(t))).then(()=>t(74404)))},48643,e=>{e.v(t=>Promise.all(["static/chunks/49504b28214f027d.js"].map(t=>e.l(t))).then(()=>t(94157)))},90783,e=>{e.v(t=>Promise.all(["static/chunks/52b1f704b5988f69.js"].map(t=>e.l(t))).then(()=>t(68397)))},94323,e=>{e.v(t=>Promise.all(["static/chunks/d9bebe106e1cff2d.js"].map(t=>e.l(t))).then(()=>t(86443)))},23207,e=>{e.v(t=>Promise.all(["static/chunks/a96cd83288064916.js"].map(t=>e.l(t))).then(()=>t(86033)))},16753,e=>{e.v(t=>Promise.all(["static/chunks/2a04efe5b5885ba8.js"].map(t=>e.l(t))).then(()=>t(93972)))},29581,e=>{e.v(t=>Promise.all(["static/chunks/d7b5a239ca209922.js"].map(t=>e.l(t))).then(()=>t(14525)))},75279,e=>{e.v(t=>Promise.all(["static/chunks/c0054a82a202531f.js"].map(t=>e.l(t))).then(()=>t(23953)))},55589,e=>{e.v(t=>Promise.all(["static/chunks/47fa1c4b284f2378.js"].map(t=>e.l(t))).then(()=>t(66742)))},5185,e=>{e.v(t=>Promise.all(["static/chunks/47c736d00fde2885.js"].map(t=>e.l(t))).then(()=>t(56427)))},93941,e=>{e.v(t=>Promise.all(["static/chunks/fa80ff2a5bad4318.js"].map(t=>e.l(t))).then(()=>t(19514)))},79388,e=>{e.v(t=>Promise.all(["static/chunks/12b6468e8d63a6ad.js"].map(t=>e.l(t))).then(()=>t(44445)))},19484,e=>{e.v(t=>Promise.all(["static/chunks/4fc17592d80a3f69.js"].map(t=>e.l(t))).then(()=>t(82258)))},64742,e=>{e.v(t=>Promise.all(["static/chunks/562f7d6895bd2600.js"].map(t=>e.l(t))).then(()=>t(97788)))},11210,e=>{e.v(t=>Promise.all(["static/chunks/39762313ed539cdf.js"].map(t=>e.l(t))).then(()=>t(73805)))},265,e=>{e.v(t=>Promise.all(["static/chunks/d4ab1c1103134296.js"].map(t=>e.l(t))).then(()=>t(61029)))},33843,e=>{e.v(t=>Promise.all(["static/chunks/71ff81308ecf0d2b.js"].map(t=>e.l(t))).then(()=>t(17279)))},85096,e=>{e.v(t=>Promise.all(["static/chunks/b8f7a56a575f3af5.js"].map(t=>e.l(t))).then(()=>t(77123)))},5233,e=>{e.v(t=>Promise.all(["static/chunks/3526ef1f54a9f6c6.js"].map(t=>e.l(t))).then(()=>t(79527)))},3045,e=>{e.v(t=>Promise.all(["static/chunks/9175fef5336a80bf.js"].map(t=>e.l(t))).then(()=>t(44919)))},5160,e=>{e.v(t=>Promise.all(["static/chunks/f1a99a8d4e905966.js"].map(t=>e.l(t))).then(()=>t(77415)))},60718,e=>{e.v(t=>Promise.all(["static/chunks/64fa4ac2ce35f5a3.js"].map(t=>e.l(t))).then(()=>t(34204)))},95855,e=>{e.v(t=>Promise.all(["static/chunks/8510daf9badae091.js"].map(t=>e.l(t))).then(()=>t(76605)))},99993,e=>{e.v(t=>Promise.all(["static/chunks/1c4fe71975add53a.js"].map(t=>e.l(t))).then(()=>t(20355)))},65614,e=>{e.v(t=>Promise.all(["static/chunks/5a62c4177628c619.js"].map(t=>e.l(t))).then(()=>t(92836)))},96913,e=>{e.v(t=>Promise.all(["static/chunks/bad05db8aca39f19.js"].map(t=>e.l(t))).then(()=>t(2964)))},52069,e=>{e.v(t=>Promise.all(["static/chunks/1b7f5b22e3c01890.js"].map(t=>e.l(t))).then(()=>t(30728)))},90986,e=>{e.v(t=>Promise.all(["static/chunks/7a17193b45b14460.js"].map(t=>e.l(t))).then(()=>t(937)))},40305,e=>{e.v(t=>Promise.all(["static/chunks/050dd34661df57bc.js"].map(t=>e.l(t))).then(()=>t(62377)))},12825,e=>{e.v(t=>Promise.all(["static/chunks/d9b432bfceafb92a.js"].map(t=>e.l(t))).then(()=>t(9172)))},88069,e=>{e.v(t=>Promise.all(["static/chunks/95653fec2921f5a4.js"].map(t=>e.l(t))).then(()=>t(90064)))},74943,e=>{e.v(t=>Promise.all(["static/chunks/ba7271190de42a59.js"].map(t=>e.l(t))).then(()=>t(49458)))},68015,e=>{e.v(t=>Promise.all(["static/chunks/a026439fb45557fd.js"].map(t=>e.l(t))).then(()=>t(22584)))},91166,e=>{e.v(t=>Promise.all(["static/chunks/293122ef63740769.js"].map(t=>e.l(t))).then(()=>t(21403)))},11706,e=>{e.v(t=>Promise.all(["static/chunks/bd1435a11ccc7604.js"].map(t=>e.l(t))).then(()=>t(40898)))},98423,e=>{e.v(t=>Promise.all(["static/chunks/b2a35a11b1341068.js"].map(t=>e.l(t))).then(()=>t(74141)))},14395,e=>{e.v(t=>Promise.all(["static/chunks/4dd133860fb14862.js"].map(t=>e.l(t))).then(()=>t(28847)))},59752,e=>{e.v(t=>Promise.all(["static/chunks/68b35bc722dfcf00.js"].map(t=>e.l(t))).then(()=>t(27555)))},73916,e=>{e.v(t=>Promise.all(["static/chunks/b9dfd97ec850a353.js"].map(t=>e.l(t))).then(()=>t(65896)))},95388,e=>{e.v(t=>Promise.all(["static/chunks/6be319d534f0c6ed.js"].map(t=>e.l(t))).then(()=>t(72629)))},22529,e=>{e.v(t=>Promise.all(["static/chunks/5030ef03b46d1c87.js"].map(t=>e.l(t))).then(()=>t(86824)))},24578,e=>{e.v(t=>Promise.all(["static/chunks/9c0282f42b19b20f.js"].map(t=>e.l(t))).then(()=>t(42409)))},26611,e=>{e.v(t=>Promise.all(["static/chunks/cbfd63b648692a55.js"].map(t=>e.l(t))).then(()=>t(31693)))},44374,e=>{e.v(t=>Promise.all(["static/chunks/da8ca1d9ad351e84.js"].map(t=>e.l(t))).then(()=>t(75355)))},29720,e=>{e.v(t=>Promise.all(["static/chunks/7771e3efd2330848.js"].map(t=>e.l(t))).then(()=>t(31829)))},97006,e=>{e.v(t=>Promise.all(["static/chunks/5fc0b99f20b809cc.js"].map(t=>e.l(t))).then(()=>t(4280)))},46848,e=>{e.v(t=>Promise.all(["static/chunks/67049753bf828a56.js"].map(t=>e.l(t))).then(()=>t(93773)))},78930,e=>{e.v(t=>Promise.all(["static/chunks/e4475c1af6bc707b.js"].map(t=>e.l(t))).then(()=>t(2306)))},99477,e=>{e.v(t=>Promise.all(["static/chunks/fcf6b1f56513264e.js"].map(t=>e.l(t))).then(()=>t(22031)))},12385,e=>{e.v(t=>Promise.all(["static/chunks/ecb477600c3fccdf.js"].map(t=>e.l(t))).then(()=>t(30211)))},62840,e=>{e.v(t=>Promise.all(["static/chunks/31333a907b0e540d.js"].map(t=>e.l(t))).then(()=>t(17667)))},88241,e=>{e.v(t=>Promise.all(["static/chunks/ad289ce9260e1478.js"].map(t=>e.l(t))).then(()=>t(14258)))},29641,e=>{e.v(t=>Promise.all(["static/chunks/7207b9728db7c3b3.js"].map(t=>e.l(t))).then(()=>t(47387)))},34883,e=>{e.v(t=>Promise.all(["static/chunks/7dc188c244537cf7.js"].map(t=>e.l(t))).then(()=>t(32913)))},30503,e=>{e.v(t=>Promise.all(["static/chunks/b3c789d52ee8b17c.js"].map(t=>e.l(t))).then(()=>t(90232)))}]);