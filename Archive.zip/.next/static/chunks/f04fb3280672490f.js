__turbopack_load_page_chunks__("/admin", [
  "static/chunks/624d19ba1fc1f8c0.js",
  "static/chunks/136ce825c0e15c0b.js",
  "static/chunks/e2e9f7dfa7ae7f9f.js",
  "static/chunks/turbopack-8e5550ec885dc297.js"
])
