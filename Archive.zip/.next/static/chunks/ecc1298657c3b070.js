__turbopack_load_page_chunks__("/_app", [
  "static/chunks/54d6203486ba066a.js",
  "static/chunks/c3cd565834e928c3.js",
  "static/chunks/e2e9f7dfa7ae7f9f.js",
  "static/chunks/0bcd4c5350cd5526.js",
  "static/chunks/2ace94f90e7b3b7d.js",
  "static/chunks/8f2efa2e31711f2b.js",
  "static/chunks/136ce825c0e15c0b.js",
  "static/chunks/fcb07cf8c42eaecb.js",
  "static/chunks/d2c70fa6f9a42eeb.js",
  "static/chunks/5e8ee1f6029e2220.js",
  "static/chunks/a750c8e12da28258.css",
  "static/chunks/turbopack-a9b4effb8d4dc93f.js"
])
