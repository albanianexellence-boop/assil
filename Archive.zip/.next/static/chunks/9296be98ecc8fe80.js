__turbopack_load_page_chunks__("/", [
  "static/chunks/ec2d417a9bf1b71b.js",
  "static/chunks/54d6203486ba066a.js",
  "static/chunks/d2c70fa6f9a42eeb.js",
  "static/chunks/0bcd4c5350cd5526.js",
  "static/chunks/c51ddab992d175b5.js",
  "static/chunks/136ce825c0e15c0b.js",
  "static/chunks/d8dbe8026c20b3fc.js",
  "static/chunks/e2e9f7dfa7ae7f9f.js",
  "static/chunks/5e87aec0a3abe185.js",
  "static/chunks/39bd26227248b718.js",
  "static/chunks/turbopack-2314606017fe3836.js"
])
